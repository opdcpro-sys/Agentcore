import fs from 'fs';
let s = fs.readFileSync('server.ts', 'utf8');

s = s.replace(/false\.models\.generateContent\([\s\S]*?\)/g, 'Promise.resolve({text: "{}", choices: [{message: {content: "{}"}}]})');

fs.writeFileSync('server.ts', s);
console.log('done');
