import fs from 'fs';
let a = fs.readFileSync('src/App.tsx', 'utf8');

// remove lines with activeTab and CommandCenter entirely
a = a.replace(/\{appState\.status === 'CONNECTED' && activeTab === 'control' && <CommandCenter \/>\}/g, '');
a = a.replace(/\{appState\.status === 'CONNECTED' && activeTab === 'control' && <TelegramPanel \/>\}/g, "{appState.status === 'CONNECTED' && <TelegramPanel />}");
a = a.replace(/\{appState\.status === 'CONNECTED' && activeTab === 'esports' && <TelegramCliInspector \/>\}/g, '');

fs.writeFileSync('src/App.tsx', a);
console.log('done');
