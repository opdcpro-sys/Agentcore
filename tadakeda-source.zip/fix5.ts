import fs from 'fs';
let s = fs.readFileSync('server.ts', 'utf8');

// The lines 1515 and 1555 probably have ai! or ai in them.
s = s.replace(/ai!\.models/g, 'false');
s = s.replace(/\bai\b/g, 'false');

fs.writeFileSync('server.ts', s);
console.log('done');
