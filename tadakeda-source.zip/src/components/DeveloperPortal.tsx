import React, { useState, useEffect } from 'react';
import { 
  Terminal as TerminalIcon, 
  RotateCw, 
  FileText, 
  Settings, 
  Play, 
  Save, 
  Check, 
  RefreshCw, 
  Folder, 
  File, 
  AlertTriangle, 
  ChevronRight, 
  ChevronDown 
} from 'lucide-react';

interface FileNode {
  name: string;
  path: string;
  isDirectory: boolean;
  children?: FileNode[];
  size?: number;
}

export function DeveloperPortal() {
  const [activeSubTab, setActiveSubTab] = useState<'logs' | 'terminal' | 'update' | 'editor'>('logs');
  
  // Logs State
  const [pm2Logs, setPm2Logs] = useState<string>('');
  const [diagLogs, setDiagLogs] = useState<string[]>([]);
  const [logsLoading, setLogsLoading] = useState<boolean>(false);
  
  // Terminal State
  const [terminalCmd, setTerminalCmd] = useState<string>('');
  const [terminalOutput, setTerminalOutput] = useState<{ stdout: string; stderr: string; error: string | null } | null>(null);
  const [terminalLoading, setTerminalLoading] = useState<boolean>(false);
  
  // Update State
  const [updateStatus, setUpdateStatus] = useState<string>('');
  const [updateLoading, setUpdateLoading] = useState<boolean>(false);
  
  // Editor State
  const [files, setFiles] = useState<FileNode[]>([]);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({});
  const [selectedFilePath, setSelectedFilePath] = useState<string>('');
  const [fileContent, setFileContent] = useState<string>('');
  const [editorLoading, setEditorLoading] = useState<boolean>(false);
  const [saveLoading, setSaveLoading] = useState<boolean>(false);
  const [saveSuccess, setSaveSuccess] = useState<boolean>(false);

  // Load Logs
  const fetchLogs = async () => {
    setLogsLoading(true);
    try {
      const res = await fetch('/api/developer/logs');
      const data = await res.json();
      if (data.success) {
        setPm2Logs(data.pm2Logs || 'No PM2 logs available.');
        setDiagLogs(data.diagnosticLogs || []);
      }
    } catch (err: any) {
      setPm2Logs(`Failed to fetch logs: ${err.message}`);
    } finally {
      setLogsLoading(false);
    }
  };

  // Load Files
  const fetchFiles = async () => {
    try {
      const res = await fetch('/api/developer/files');
      const data = await res.json();
      if (data.success) {
        setFiles(data.files || []);
      }
    } catch (err) {
      console.error('Failed to load file structure', err);
    }
  };

  // Load File Content
  const fetchFileContent = async (path: string) => {
    setSelectedFilePath(path);
    setEditorLoading(true);
    setSaveSuccess(false);
    try {
      const res = await fetch(`/api/developer/file-content?filePath=${encodeURIComponent(path)}`);
      const data = await res.json();
      if (data.success) {
        setFileContent(data.content);
      } else {
        setFileContent(`Error loading file: ${data.error}`);
      }
    } catch (err: any) {
      setFileContent(`Failed to fetch file content: ${err.message}`);
    } finally {
      setEditorLoading(false);
    }
  };

  // Save File Content
  const saveFileContent = async () => {
    if (!selectedFilePath) return;
    setSaveLoading(true);
    setSaveSuccess(false);
    try {
      const res = await fetch('/api/developer/file-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filePath: selectedFilePath, content: fileContent })
      });
      const data = await res.json();
      if (data.success) {
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
      } else {
        alert(`Save failed: ${data.error}`);
      }
    } catch (err: any) {
      alert(`Error saving file: ${err.message}`);
    } finally {
      setSaveLoading(false);
    }
  };

  // Execute Command
  const runCommand = async (cmd: string) => {
    const commandToRun = cmd || terminalCmd;
    if (!commandToRun) return;
    setTerminalLoading(true);
    try {
      const res = await fetch('/api/developer/terminal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: commandToRun })
      });
      const data = await res.json();
      if (data.success) {
        setTerminalOutput({
          stdout: data.stdout,
          stderr: data.stderr,
          error: data.error
        });
      } else {
        setTerminalOutput({
          stdout: '',
          stderr: data.error || 'Unknown execution error',
          error: 'Execution Failed'
        });
      }
    } catch (err: any) {
      setTerminalOutput({
        stdout: '',
        stderr: err.message,
        error: 'Fetch Failed'
      });
    } finally {
      setTerminalLoading(false);
    }
  };

  // Trigger Git/PM2 Auto Update
  const triggerAutoUpdate = async () => {
    if (!confirm('Are you sure you want to trigger Auto-Update? This runs git pull, rebuilds the code, and restarts PM2.')) {
      return;
    }
    setUpdateLoading(true);
    setUpdateStatus('Initiating update process...');
    try {
      const res = await fetch('/api/developer/update', { method: 'POST' });
      const data = await res.json();
      if (data.success) {
        setUpdateStatus(data.message || 'Update started!');
      } else {
        setUpdateStatus(`Update initiation failed: ${data.error}`);
      }
    } catch (err: any) {
      setUpdateStatus(`Network error: ${err.message}`);
    } finally {
      setUpdateLoading(false);
    }
  };

  useEffect(() => {
    if (activeSubTab === 'logs') {
      fetchLogs();
    } else if (activeSubTab === 'editor') {
      fetchFiles();
    }
  }, [activeSubTab]);

  const toggleFolder = (path: string) => {
    setExpandedFolders(prev => ({ ...prev, [path]: !prev[path] }));
  };

  const renderFileTree = (nodes: FileNode[]) => {
    return nodes.map(node => {
      const isExpanded = expandedFolders[node.path];
      const isSelected = selectedFilePath === node.path;
      
      if (node.isDirectory) {
        return (
          <div key={node.path} className="ml-3 select-none">
            <div 
              onClick={() => toggleFolder(node.path)}
              className="flex items-center space-x-1 py-1 px-1.5 rounded hover:bg-neutral-800/60 cursor-pointer text-neutral-300 transition-colors"
            >
              {isExpanded ? <ChevronDown size={14} className="text-neutral-500" /> : <ChevronRight size={14} className="text-neutral-500" />}
              <Folder size={14} className="text-amber-400 fill-amber-400/20" />
              <span className="text-xs font-medium">{node.name}</span>
            </div>
            {isExpanded && node.children && (
              <div className="border-l border-neutral-800 ml-2.5">
                {renderFileTree(node.children)}
              </div>
            )}
          </div>
        );
      } else {
        return (
          <div 
            key={node.path}
            onClick={() => fetchFileContent(node.path)}
            className={`flex items-center space-x-1.5 py-1 px-2.5 ml-5 rounded cursor-pointer transition-colors text-xs select-none ${
              isSelected ? 'bg-indigo-600/30 text-indigo-200 font-medium' : 'text-neutral-400 hover:bg-neutral-800/40 hover:text-neutral-200'
            }`}
          >
            <File size={13} className="text-neutral-500" />
            <span className="truncate">{node.name}</span>
          </div>
        );
      }
    });
  };

  return (
    <div id="developer-portal-card" className="bg-neutral-900 border border-neutral-800 rounded-xl p-5 shadow-xl space-y-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-neutral-800">
        <div>
          <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
            <Settings className="text-indigo-400 animate-spin-slow" size={20} />
            AI Copilot & Dev Portal
          </h2>
          <p className="text-xs text-neutral-400">
            Securely inspect logs, trigger git auto-updates, run terminal debugs, and modify code on your VPS.
          </p>
        </div>
        
        {/* Sub-tabs selector */}
        <div className="flex bg-neutral-950 p-1 rounded-lg border border-neutral-800 self-start sm:self-center">
          <button
            onClick={() => setActiveSubTab('logs')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              activeSubTab === 'logs' ? 'bg-indigo-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            PM2 Logs
          </button>
          <button
            onClick={() => setActiveSubTab('update')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              activeSubTab === 'update' ? 'bg-indigo-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Auto-Update
          </button>
          <button
            onClick={() => setActiveSubTab('terminal')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              activeSubTab === 'terminal' ? 'bg-indigo-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Terminal
          </button>
          <button
            onClick={() => setActiveSubTab('editor')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-all cursor-pointer ${
              activeSubTab === 'editor' ? 'bg-indigo-600 text-white shadow' : 'text-neutral-400 hover:text-white'
            }`}
          >
            File Editor
          </button>
        </div>
      </div>

      {/* Sub-tab: PM2 Logs */}
      {activeSubTab === 'logs' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-neutral-300">Active PM2 Stdout & Stderr Output</h3>
            <button 
              onClick={fetchLogs} 
              disabled={logsLoading}
              className="flex items-center gap-1.5 px-3 py-1 text-xs font-medium text-neutral-300 hover:text-white bg-neutral-800 hover:bg-neutral-700 disabled:opacity-50 rounded-lg border border-neutral-700 transition-colors cursor-pointer"
            >
              <RefreshCw size={12} className={logsLoading ? 'animate-spin' : ''} />
              {logsLoading ? 'Refreshing...' : 'Refresh Logs'}
            </button>
          </div>

          <div className="bg-neutral-950 rounded-xl border border-neutral-800 p-4 font-mono text-xs overflow-auto max-h-[450px] leading-relaxed text-neutral-300 whitespace-pre shadow-inner">
            {pm2Logs}
          </div>

          <div className="space-y-2">
            <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Internal Diagnostics Chain Log</h4>
            <div className="bg-neutral-950 rounded-xl border border-neutral-800 p-3 font-mono text-xs max-h-[180px] overflow-y-auto space-y-1">
              {diagLogs.length === 0 ? (
                <div className="text-neutral-500 italic">No diagnostics recorded.</div>
              ) : (
                diagLogs.map((log, idx) => (
                  <div key={idx} className="text-neutral-400 border-b border-neutral-900/50 pb-1 last:border-0">{log}</div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Sub-tab: Auto-Update */}
      {activeSubTab === 'update' && (
        <div className="space-y-5 py-4 max-w-2xl mx-auto text-center">
          <div className="bg-amber-950/20 border border-amber-800/40 p-4 rounded-xl text-left flex items-start gap-3">
            <AlertTriangle className="text-amber-500 shrink-0 mt-0.5" size={20} />
            <div>
              <h4 className="text-sm font-semibold text-amber-200">Production Re-deployment Action</h4>
              <p className="text-xs text-amber-300/80 mt-1">
                This triggers a secure local VPS git merge/pull operation, runs client bundling (`npm run build`), and executes a soft graceful reload of the PM2 process. Recommended when changes are made.
              </p>
            </div>
          </div>

          <div className="bg-neutral-950 rounded-2xl p-6 border border-neutral-800 space-y-4">
            <div className="text-neutral-300 text-sm font-medium">
              Ready to synchronize the code with the main Git Repository?
            </div>
            
            <button
              onClick={triggerAutoUpdate}
              disabled={updateLoading}
              className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 disabled:bg-emerald-800 text-white font-bold rounded-xl shadow-lg transition-colors inline-flex items-center gap-2 cursor-pointer"
            >
              <RotateCw size={16} className={updateLoading ? 'animate-spin' : ''} />
              {updateLoading ? 'Synchronizing Repository...' : 'Trigger Git Pull & PM2 Restart'}
            </button>

            {updateStatus && (
              <div className="bg-neutral-900 border border-neutral-800 p-3 rounded-lg text-xs font-mono text-emerald-400 text-left whitespace-pre-wrap">
                {updateStatus}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Sub-tab: Terminal */}
      {activeSubTab === 'terminal' && (
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-bold text-neutral-300">Remote Shell Debugger</h3>
            <p className="text-xs text-neutral-400">Run safe inspection and diagnostic shell commands directly on your AWS node host.</p>
          </div>

          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-neutral-500 self-center">Quick Presets:</span>
            <button onClick={() => runCommand('pm2 status')} className="px-2.5 py-1 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded border border-neutral-700 cursor-pointer">pm2 status</button>
            <button onClick={() => runCommand('git status')} className="px-2.5 py-1 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded border border-neutral-700 cursor-pointer">git status</button>
            <button onClick={() => runCommand('free -m')} className="px-2.5 py-1 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded border border-neutral-700 cursor-pointer">free -m (RAM)</button>
            <button onClick={() => runCommand('df -h')} className="px-2.5 py-1 text-xs bg-neutral-800 hover:bg-neutral-700 text-neutral-300 rounded border border-neutral-700 cursor-pointer">df -h (Disk)</button>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); runCommand(''); }} className="flex gap-2">
            <input
              type="text"
              value={terminalCmd}
              onChange={(e) => setTerminalCmd(e.target.value)}
              placeholder="Enter command (e.g., node -v, ls -la)"
              className="flex-1 bg-neutral-950 border border-neutral-800 rounded-xl px-4 py-2.5 text-xs text-neutral-100 font-mono focus:outline-none focus:border-indigo-500 transition-colors"
            />
            <button
              type="submit"
              disabled={terminalLoading || !terminalCmd}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
            >
              <Play size={13} />
              Run
            </button>
          </form>

          {terminalLoading && (
            <div className="text-xs text-indigo-400 font-mono animate-pulse">Executing command on VPS...</div>
          )}

          {terminalOutput && (
            <div className="bg-neutral-950 rounded-xl border border-neutral-800 p-4 font-mono text-xs overflow-auto max-h-[350px] space-y-3">
              {terminalOutput.stdout && (
                <div>
                  <div className="text-neutral-500 text-[10px] uppercase font-bold tracking-wider mb-1">Standard Output:</div>
                  <div className="text-emerald-400 whitespace-pre">{terminalOutput.stdout}</div>
                </div>
              )}
              {terminalOutput.stderr && (
                <div>
                  <div className="text-rose-500 text-[10px] uppercase font-bold tracking-wider mb-1">Error Stream:</div>
                  <div className="text-rose-400 whitespace-pre">{terminalOutput.stderr}</div>
                </div>
              )}
              {terminalOutput.error && (
                <div className="text-rose-500 text-xs font-bold">Execution Error Code: {terminalOutput.error}</div>
              )}
              {!terminalOutput.stdout && !terminalOutput.stderr && !terminalOutput.error && (
                <div className="text-neutral-500 italic">Command completed with no output stream.</div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Sub-tab: File Editor */}
      {activeSubTab === 'editor' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-[550px]">
          {/* Sidebar file tree */}
          <div className="md:col-span-4 bg-neutral-950 border border-neutral-800 rounded-xl p-3 overflow-y-auto max-h-[550px]">
            <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-3 px-1">File Explorer</h4>
            <div className="space-y-0.5">
              {files.length === 0 ? (
                <div className="text-neutral-600 text-xs italic p-2">Loading explorer structure...</div>
              ) : (
                renderFileTree(files)
              )}
            </div>
          </div>

          {/* Main edit window */}
          <div className="md:col-span-8 flex flex-col bg-neutral-950 border border-neutral-800 rounded-xl overflow-hidden h-[550px]">
            {selectedFilePath ? (
              <>
                <div className="flex items-center justify-between px-4 py-2.5 bg-neutral-900 border-b border-neutral-800">
                  <div className="flex items-center gap-1.5">
                    <File size={14} className="text-indigo-400" />
                    <span className="text-xs font-mono font-medium text-neutral-200">{selectedFilePath}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {saveSuccess && (
                      <span className="text-xs text-emerald-400 flex items-center gap-1">
                        <Check size={14} /> Saved!
                      </span>
                    )}
                    <button
                      onClick={saveFileContent}
                      disabled={saveLoading}
                      className="px-3 py-1 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
                    >
                      <Save size={12} />
                      {saveLoading ? 'Saving...' : 'Save File'}
                    </button>
                  </div>
                </div>

                {editorLoading ? (
                  <div className="flex-1 flex items-center justify-center text-xs text-neutral-500 font-mono">
                    <RotateCw className="animate-spin text-neutral-600 mb-2" size={24} />
                    Loading file contents...
                  </div>
                ) : (
                  <textarea
                    value={fileContent}
                    onChange={(e) => setFileContent(e.target.value)}
                    className="flex-1 w-full bg-neutral-950 p-4 font-mono text-xs text-neutral-200 resize-none focus:outline-none focus:ring-0 leading-relaxed overflow-y-auto"
                  />
                )}
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-neutral-500 space-y-2">
                <FileText size={40} className="text-neutral-700" />
                <div className="text-xs font-medium text-neutral-400">No File Selected</div>
                <div className="text-[11px] text-neutral-500 max-w-xs">
                  Choose any file from the sidebar explorer on the left to read, modify, and update its code on your AWS VPS.
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
