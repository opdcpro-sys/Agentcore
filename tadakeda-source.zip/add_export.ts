import fs from 'fs';

let serverTs = fs.readFileSync('server.ts', 'utf8');

const exportRepoCode = `
app.get('/api/export-repo', (req, res) => {
  try {
    const AdmZip = require('adm-zip');
    const zip = new AdmZip();
    const projectRoot = process.cwd();
    
    const addDirectoryToZip = (currentDir: string, zipPathPrefix = '') => {
      const items = fs.readdirSync(currentDir);
      
      for (const item of items) {
        // Skip dependencies, git folders, and build artifacts
        if (
          item === 'node_modules' || 
          item === '.git' || 
          item === 'dist' || 
          item === '.env'
        ) continue;
        
        const fullPath = path.join(currentDir, item);
        const stat = fs.statSync(fullPath);
        
        if (stat.isDirectory()) {
          addDirectoryToZip(fullPath, \`\${zipPathPrefix}\${item}/\`);
        } else {
          zip.addLocalFile(fullPath, zipPathPrefix);
        }
      }
    };
    
    addDirectoryToZip(projectRoot);
    
    const zipBuffer = zip.toBuffer();
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename=tadakeda-source.zip');
    res.setHeader('Content-Length', zipBuffer.length);
    
    res.send(zipBuffer);
  } catch (err: any) {
    console.error('Failed to export repo:', err);
    res.status(500).json({ error: err.message });
  }
});

`;

serverTs = serverTs.replace('  // Vite middleware for development', exportRepoCode + '  // Vite middleware for development');
fs.writeFileSync('server.ts', serverTs);
console.log('done');
