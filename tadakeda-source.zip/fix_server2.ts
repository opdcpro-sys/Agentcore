import fs from 'fs';

let serverTs = fs.readFileSync('server.ts', 'utf8');

// Remove AI Guard block
serverTs = serverTs.replace(/addDiagLog\('AI Auto-Responder active[\s\S]*?AI auto-reply failed:.*?\n\s*\}/g, '// Auto-responder removed');

// We also have `requestAIContent` inside AFK auto reply? Let's check where it is at 565.
serverTs = serverTs.replace(/const prompt = `.*?AFK.*?`;[\s\S]*?requestAIContent.*?catch.*?\{\s*\}\n\s*\}/g, 'await client!.sendMessage(message.chatId!, { message: `💤 **AFK Auto-Reply:**\\n` + afkState.reason, replyTo: message.id });');

// Remove OTT search block at 1513+
serverTs = serverTs.replace(/if\s*\(process\.env\.GEMINI_API_KEY && ai\) \{[\s\S]*?const aiResponse = JSON\.parse.*?\} catch.*?\{\s*console\.error\('Gemini OTT Search Call failed.*?\}[\s\S]*?\} else \{/g, 'if (false) {');
serverTs = serverTs.replace(/if\s*\(process\.env\.GEMINI_API_KEY && ai\) \{[\s\S]*?const response = await ai\.models\.generateContent[\s\S]*?catch\s*\(err\)\s*\{[\s\S]*?console\.error\('Gemini custom URL parse failed.*?\}\n\s*\}/g, '');

fs.writeFileSync('server.ts', serverTs);
console.log("Fixed server.ts");
