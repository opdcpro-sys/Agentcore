const fs = require('fs');
let s = fs.readFileSync('server.ts', 'utf8');

// just blank out requestAIContent entirely
s = s.replace(/await requestAIContent\([\s\S]*?\)/g, '"AI features are disabled"');

// ai variable usages
s = s.replace(/ai!\.models\.generateContent\([\s\S]*?\)/g, 'Promise.resolve({ text: "{}" })');
s = s.replace(/process\.env\.GEMINI_API_KEY && ai/g, 'false');
s = s.replace(/ai\?/g, 'false');

fs.writeFileSync('server.ts', s);

let a = fs.readFileSync('src/App.tsx', 'utf8');
// remove activeTab checks
a = a.replace(/activeTab === 'control' \?/g, 'true ?');
a = a.replace(/activeTab === 'esports' \?/g, 'false ?');
a = a.replace(/activeTab === 'copilot' \?/g, 'false ?');
a = a.replace(/<SystemHealthMonitor \/>/g, '');
a = a.replace(/<SpeedTestComponent \/>/g, '');

fs.writeFileSync('src/App.tsx', a);
console.log('done');
