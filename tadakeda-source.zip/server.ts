import express from 'express';
import { createServer as createViteServer } from 'vite';
import { TelegramClient, Api } from 'telegram';
import { StringSession } from 'telegram/sessions/index.js';
import { NewMessage } from 'telegram/events/index.js';
import { Logger } from 'telegram/extensions/Logger.js';

Logger.setLevel('none');
import fs from 'fs';
import path from 'path';
import os from 'os';
import AdmZip from 'adm-zip';
import { exec, execSync } from 'child_process';
import { 
  loadBotDataFromDb, 
  saveBotDataToDb, 
  loadChatHistoryFromDb, 
  saveChatHistoryToDb 
} from './src/firebase';

const app = express();
app.use(express.json());

// Gracefully handle unhandled promise rejections and uncaught exceptions to prevent crashing/logging critical failures
process.on('unhandledRejection', (reason, promise) => {
  addDiagLog(`[UnhandledRejection] Reason: ${reason}`);
  console.log('[UnhandledRejection] Captured background rejection:', reason);
});
process.on('uncaughtException', (error) => {
  addDiagLog(`[UncaughtException] Error: ${error?.message || error}`);
  console.log('[UncaughtException] Captured background exception:', error);
});

const PORT = 3000;
const DATA_FILE = path.join(process.cwd(), 'bot_data.json');

// Interface definition
interface BotData {
  apiId: string;
  apiHash: string;
  phone: string;
  sessionString: string;
  supremeLeaderId: string;
  agents: Record<string, string>; // userId -> role (S, A, B)
  autoDetect?: boolean;
  backupChatId?: string;
}

let botData: BotData = {
  apiId: '',
  apiHash: '',
  phone: '',
  sessionString: '',
  supremeLeaderId: '',
  agents: {},
  autoDetect: false,
  backupChatId: ''
};


let client: TelegramClient | null = null;
let connectionStatus: 'DISCONNECTED' | 'WAITING_FOR_CODE' | 'WAITING_FOR_PASSWORD' | 'CONNECTED' = 'DISCONNECTED';
let botInfo: any = null;

const diagnosticLogs: string[] = [];
export function addDiagLog(msg: string) {
  const time = new Date().toLocaleTimeString();
  const logStr = `[${time}] ${msg}`;
  console.log(`[Diagnostic] ${msg}`);
  diagnosticLogs.push(logStr);
  if (diagnosticLogs.length > 100) {
    diagnosticLogs.shift();
  }
}

class TrafficTaskQueue {
  private activeCount = 0;
  private queue: (() => Promise<any>)[] = [];
  private readonly maxConcurrency = 1; // Strict linear execution to guarantee no crashes under load

  async enqueue<T>(task: () => Promise<T>): Promise<T> {
    if (this.activeCount < this.maxConcurrency) {
      this.activeCount++;
      try {
        const res = await task();
        this.runGc();
        return res;
      } finally {
        this.activeCount--;
        this.next();
      }
    }

    return new Promise<T>((resolve, reject) => {
      this.queue.push(async () => {
        try {
          const result = await task();
          this.runGc();
          resolve(result);
        } catch (err) {
          reject(err);
        }
      });
    });
  }

  private next() {
    if (this.queue.length > 0 && this.activeCount < this.maxConcurrency) {
      this.activeCount++;
      const nextTask = this.queue.shift();
      if (nextTask) {
        nextTask().finally(() => {
          this.activeCount--;
          this.next();
        });
      }
    }
  }

  private runGc() {
    if (global && typeof (global as any).gc === 'function') {
      try {
        (global as any).gc();
      } catch (_) {}
    }
  }
}

export const heavyTaskQueue = new TrafficTaskQueue();

let resolveAuthCode: ((code: string) => void) | null = null;
let resolveAuthPassword: ((password: string) => void) | null = null;


const CHAT_HISTORY_FILE = './chat_history.json';
// In-memory recent chat history
let recentChatHistory = new Map<string, Array<{role: 'user'|'assistant', content: string}>>();

// Load chat history local fallback (we will do cloud loading in startServer asynchronously)
try {
  if (fs.existsSync(CHAT_HISTORY_FILE)) {
    const data = JSON.parse(fs.readFileSync(CHAT_HISTORY_FILE, 'utf-8'));
    recentChatHistory = new Map(Object.entries(data));
  }
} catch (e) {
  console.error('Failed to load chat history locally', e);
}

function saveChatHistoryLocal() {
  fs.writeFileSync(CHAT_HISTORY_FILE, JSON.stringify(Object.fromEntries(recentChatHistory)), 'utf-8');
}

function saveChatHistory(chatId?: string) {
  saveChatHistoryLocal();
  if (chatId) {
    const history = recentChatHistory.get(chatId);
    if (history) {
      saveChatHistoryToDb(chatId, history).catch((e: any) => {
        console.error(`[Firebase] Chat history background save failed for ${chatId}:`, e);
      });
    }
  }
}

function addToHistory(chatId: string, role: 'user'|'assistant', text: string) {
  if (!recentChatHistory.has(chatId)) {
    recentChatHistory.set(chatId, []);
  }
  const history = recentChatHistory.get(chatId)!;
  history.push({ role, content: text });
  if (history.length > 20) {
    history.shift();
  }
  saveChatHistory(chatId);
}



const afkState = {
  isAfk: false,
  reason: '',
  since: 0,
  repliedUsers: new Set<string>()
};

const LUDO_WIN_POS = 20;
type LudoPlayer = { id: string, name: string, pos: number, emoji: string };
type LudoGame = {
  chatId: string;
  hostId: string;
  status: 'joining' | 'playing' | 'finished';
  turnIndex: number;
  players: LudoPlayer[];
  messageId: number | null;
  boardMessageStr: string;
};
const activeLudoGames = new Map<string, LudoGame>();
const LUDO_COLORS = ['🔴', '🔵', '🟢', '🟡'];

// Load config local fallback (we will do cloud loading in startServer asynchronously)
try {
  if (fs.existsSync(DATA_FILE)) {
    botData = JSON.parse(fs.readFileSync(DATA_FILE, 'utf-8'));
  }
} catch (e) {
  console.error('Failed to parse bot_data.json locally', e);
}

function saveDataLocal(data: BotData) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf-8');
}

function saveData(data: BotData) {
  saveDataLocal(data);
  saveBotDataToDb(data).catch((e: any) => {
    console.error('[Firebase] Bot config background save failed:', e);
  });
}

function renderLudoBoard(game: LudoGame): string {
  let msg = `🎲 **LUDO RACE MINIGAME** 🎲\nStatus: ${game.status.toUpperCase()}\n\n`;
  for(let i = 0; i < game.players.length; i++) {
    const p = game.players[i];
    const isTurn = game.status === 'playing' && game.turnIndex === i;
    const marker = isTurn ? '👉 ' : '    ';
    
    // Build path
    const trackCount = 10; // each block is 2 pos
    let bar = '';
    for(let j=0; j<trackCount; j++) {
      if (Math.floor(p.pos / 2) === j) bar += p.emoji;
      else bar += '⬜️';
    }
    
    msg += `${marker}${p.emoji} **${p.name}** [${p.pos}/${LUDO_WIN_POS}]\n`;
    msg += `   🏁${bar}🏆\n\n`;
  }
  
  if (game.status === 'joining') {
    msg += `Type \`!join\` to enter. Host type \`!start\` to begin or \`!addbot\` to add a bot.\nMembers: ${game.players.length}/4`;
  } else if (game.status === 'playing') {
    const curPlayer = game.players[game.turnIndex];
    msg += `\n**${curPlayer.name}'s turn!**\nType \`!roll\` to throw the dice!`;
  } else {
    const winner = game.players.find(p => p.pos >= LUDO_WIN_POS);
    if (winner) {
      msg += `\n🎉 **${winner.name} WINS THE GAME!** 🎉`;
    } else {
      msg += `\n🛑 Game Over.`;
    }
  }
  
  return msg;
}

// Commands handling
function registerBotCommands() {
  if (!client) return;

  try {
    client.removeEventHandler(handleMTProtoMessage, undefined as any);
  } catch (e) {}

  client.addEventHandler(handleMTProtoMessage, new NewMessage({ outgoing: true, incoming: true }));
}

export async function handleMTProtoMessage(event: any) {
  const message = event.message;
  let text = message.text || message.message;
  if (!text) return;

  const senderId = message.senderId?.toString();
  const chatId = message.chatId?.toString();
  
  addDiagLog(`Incoming Msg: "${text.substring(0, 45)}" | Sender: ${senderId} | Chat: ${chatId} | Outgoing: ${!!message.out}`);
  
  if (!chatId) return;

  try {
    // Track conversation history
    const roleForHistory = message.out ? 'assistant' : 'user';
    addToHistory(chatId, roleForHistory, text);
  } catch (err) {
    addDiagLog(`[Warning] Add to history failed: ${err}`);
  }

  // Filter incoming vs outgoing logic
  const isSupremeLeader = senderId === botData.supremeLeaderId;
  const agentRole = botData.agents[senderId!];
  const isAuthorized = isSupremeLeader || !!agentRole || !!message.out;

  addDiagLog(`Evaluation: isSupremeLeader=${isSupremeLeader} (supremeLeaderId=${botData.supremeLeaderId}) | agentRole=${agentRole || 'none'} | isOut=${!!message.out} => isAuthorized=${isAuthorized}`);

  // Auto-reply for AFK mode if someone DMs the bot account
  if (afkState.isAfk && !message.out && message.isPrivate) {
    if (senderId && !afkState.repliedUsers.has(senderId)) {
      afkState.repliedUsers.add(senderId);
      try {
        await client!.sendMessage(message.chatId!, {
          message: `💤 **I am currently AFK (Away From Keyboard).**\n\n**Reason:** ${afkState.reason}\n**Since:** ${new Date(afkState.since).toLocaleString()}`
        });
        addDiagLog(`Replied AFK auto-message to sender: ${senderId}`);
      } catch (e) {
        addDiagLog(`Fail to send AFK auto-reply: ${e}`);
      }
    }
  }

  // Auto-disable AFK if authorized user sends a message explicitly
  const isBotAutomatedOrCommand = text.startsWith('💤') || text.startsWith('🌅') || text.startsWith('⚡') || text.startsWith('🤖') || text.startsWith('🏓') || text.startsWith('!afk') || text.startsWith('/afk');
  if (afkState.isAfk && message.out && !isBotAutomatedOrCommand) {
    afkState.isAfk = false;
    try {
      await client!.sendMessage(message.chatId!, { message: `🌅 **I am back!** AFK mode disabled.`, replyTo: message.id });
      addDiagLog('AFK disabled automatically via outgoing activity');
    } catch (e) {}
  }

  let isMentioned = message.mentioned;
  let isReplyToMe = false;
  if (message.replyToMsgId) {
    try {
      const replied = await message.getReplyMessage();
      if (replied && replied.out) {
        isReplyToMe = true;
      }
    } catch (e) {}
  }

  if (botData.autoDetect && !message.out) {
    const isBotPrefix = text.startsWith('🤖') || text.startsWith('⚡') || text.startsWith('💤');
    if ((isMentioned || isReplyToMe || message.isPrivate) && !isBotPrefix) {
      // Prevent loops with other bots or rapid recurring traffic
      if (message.sender?.bot) {
        addDiagLog('Ignored message from a bot to prevent loops.');
        return;
      }
      
      addDiagLog('AI Auto-Responder active for this incoming message...');
      // AI Guard / Auto Responder kicks in for incoming messages targeting the owner
      const prompt = `This user said: "${text}". You have the context of the chat. Reply to them directly, acting as the protective, aggressive, sweet or helpful AI of the Supreme Leader based on their tone. If they are insulting or demanding, give a savage 'kadada' response in Hinglish. Try to keep it brief unless explaining something.`;
      try {
         const history = recentChatHistory.get(chatId) || [];
         const m = await client!.sendMessage(message.chatId!, { message: '⚡ Analyzing...', replyTo: message.id });
         const replyText = "AI features are disabled";
         try {
            await client!.editMessage(message.chatId!, { message: m.id, text: `🤖 **AI Guard:**\n\n${replyText}` });
         } catch (e: any) {
            // Ignore failure to edit, falling back gracefully
            await client!.deleteMessages(message.chatId!, [m.id], { revoke: true }).catch(() => {});
            await client!.sendMessage(message.chatId!, { message: `🤖 **AI Guard:**\n\n${replyText}`, replyTo: message.id }).catch(() => {});
         }
         try {
           addToHistory(chatId, 'assistant', replyText);
         } catch (e) {}
         addDiagLog(`AI Auto-Responder completed successfully. Replied text: "${replyText.substring(0, 30)}..."`);
      } catch (err) {
         addDiagLog(`AI Auto-Responder error: ${err}`);
      }
      return; // Don't process as a command
    }
  } // end autoDetect !message.out

    const tlText = (text || '').toLowerCase();

    // LUDO PUBLIC MULTIPLAYER LOGIC
    if (tlText === '!ludo' && isAuthorized) {
      const g: LudoGame = {
        chatId,
        hostId: senderId!,
        status: 'joining',
        turnIndex: 0,
        players: [{ id: senderId!, name: message.sender?.firstName || 'Host', pos: 0, emoji: LUDO_COLORS[0] }],
        messageId: null,
        boardMessageStr: ''
      };
      g.boardMessageStr = renderLudoBoard(g);
      const m = await client!.sendMessage(chatId, { message: g.boardMessageStr, replyTo: message.id });
      g.messageId = m.id;
      activeLudoGames.set(chatId, g);
      return;
    }

    if (activeLudoGames.has(chatId)) {
      const game = activeLudoGames.get(chatId)!;
      let updateBoard = false;

      if (tlText === '!join' && game.status === 'joining') {
        if (!game.players.find(p => p.id === senderId) && game.players.length < 4) {
          game.players.push({
            id: senderId!,
            name: message.sender?.firstName || 'Player',
            pos: 0,
            emoji: LUDO_COLORS[game.players.length]
          });
          updateBoard = true;
          if (game.players.length === 4) {
            game.status = 'playing';
            game.turnIndex = 0;
          }
        }
      }
      
      if ((tlText === '!start' || tlText === '!startludo') && game.status === 'joining' && isAuthorized && game.players.length >= 1) {
         game.status = 'playing';
         game.turnIndex = 0;
         updateBoard = true;
      }
      
      if (tlText === '!addbot' && game.status === 'joining' && isAuthorized && game.players.length < 4) {
         game.players.push({
            id: `bot_${Date.now()}`,
            name: 'AI Player ' + (game.players.length + 1),
            pos: 0,
            emoji: LUDO_COLORS[game.players.length]
         });
         updateBoard = true;
         if (game.players.length === 4) {
            game.status = 'playing';
            game.turnIndex = 0;
          }
      }

      if (tlText === '!roll' && game.status === 'playing') {
        const curP = game.players[game.turnIndex];
        if (curP.id === senderId) {
          let diceObj: any;
          try {
             diceObj = await client!.sendMessage(chatId, { file: new Api.InputMediaDice({ emoticon: '🎲' }), replyTo: message.id });
          } catch(e) {
             diceObj = await client!.sendMessage(chatId, { message: '🎲 Rolling...' });
          }
          const value = (diceObj.media as any)?.value || Math.floor(Math.random() * 6) + 1;
          
          await new Promise(r => setTimeout(r, 2500)); // wait for dice animation
          
          curP.pos += value;
          if (curP.pos >= LUDO_WIN_POS) {
             curP.pos = LUDO_WIN_POS;
             game.status = 'finished';
          }
          
          if (game.status === 'playing') {
             if (value !== 6) {
                game.turnIndex = (game.turnIndex + 1) % game.players.length;
             }
          }
          updateBoard = true;
        }
      }

      if (tlText === '!endgame' && isAuthorized) {
        activeLudoGames.delete(chatId);
        await client!.sendMessage(chatId, { message: '🛑 Ludo game aborted by owner.' });
        return;
      }

      if (updateBoard) {
        game.boardMessageStr = renderLudoBoard(game);
        if (game.messageId) {
          try {
            await client!.editMessage(chatId, { message: game.messageId, text: game.boardMessageStr });
          } catch(e) {
            const m = await client!.sendMessage(chatId, { message: game.boardMessageStr });
            game.messageId = m.id;
          }
        }
        
        let needsBotMove = game.status === 'playing' && game.players[game.turnIndex].id.startsWith('bot_');
        while (needsBotMove && game.status === 'playing') {
           const bP = game.players[game.turnIndex];
           let botDice: any;
           try {
              botDice = await client!.sendMessage(chatId, { file: new Api.InputMediaDice({ emoticon: '🎲' }), replyTo: game.messageId! });
           } catch(e) {
              botDice = await client!.sendMessage(chatId, { message: `🎲 ${bP.name} rolling...` });
           }
           const bVal = (botDice.media as any)?.value || Math.floor(Math.random() * 6) + 1;
           await new Promise(r => setTimeout(r, 2500));
           
           bP.pos += bVal;
           if (bP.pos >= LUDO_WIN_POS) {
              bP.pos = LUDO_WIN_POS;
              game.status = 'finished';
           }
           if (game.status === 'playing' && bVal !== 6) {
              game.turnIndex = (game.turnIndex + 1) % game.players.length;
           }
           
           game.boardMessageStr = renderLudoBoard(game);
           try {
             await client!.editMessage(chatId, { message: game.messageId!, text: game.boardMessageStr });
           } catch(e) {
             const m2 = await client!.sendMessage(chatId, { message: game.boardMessageStr });
             game.messageId = m2.id;
           }
           needsBotMove = game.status === 'playing' && game.players[game.turnIndex].id.startsWith('bot_');
        }

        if (game.status === 'finished') {
          activeLudoGames.delete(chatId);
        }
      }
      
      // Stop early if commands were handled
      if (['!join', '!start', '!startludo', '!addbot', '!roll', '!endgame'].includes(tlText)) {
        return;
      }
    }

    if (!isAuthorized) return; // Commands below this line are ONLY for Supreme Leader and Agents

    const safeEdit = async (cId: any, editMsgId: number, newText: string) => {
      try {
        await client!.editMessage(cId, { message: editMsgId, text: newText });
      } catch (err: any) {
        // Fallback gracefully without throwing noisy errors into the stderr logs (which trigger the error UI)
        try {
          // Delete old message to keep chat clean if edit fails
          await client!.deleteMessages(cId, [editMsgId], { revoke: true }).catch(() => {});
          await client!.sendMessage(cId, { message: newText }).catch(() => {});
        } catch (e) {
          // ignore fallback failures
        }
      }
    };

    if (text.match(/^[!/.?]autodetect/i)) {
      const parts = text.split(' ');
      if (parts[1] === 'on') {
        botData.autoDetect = true;
        saveData(botData);
        await client!.sendMessage(message.chatId!, { message: `🤖 **Auto-Detect & Guard AI:** ON\n\nI will now contextually map your messages to commands automatically, and act as an AI Guard replying to people who tag you or reply to you!`, replyTo: message.id });
      } else {
        botData.autoDetect = false;
        saveData(botData);
        await client!.sendMessage(message.chatId!, { message: `🤖 **Auto-Detect & Guard AI:** OFF`, replyTo: message.id });
      }
      return;
    }

    if (botData.autoDetect && isAuthorized && !text.match(/^[!/.]/)) {
      if (text.length < 500) {
        try {
          const intentPrompt = `You are a strict command parser for a Telegram userbot. Map the following text to exactly one of the available commands if it's a clear request or intent. If not a clear request, reply 'IGNORE'.
Commands:
- !ping (check bot latency / ping)
- !scan [target] (get info about a user/group link/username)
- !sysinfo (server cpu/mem)
- !game [type] (play dice/dart/slot/bowl/football/basketball)
- !ludo (start a multiplayer ludo race game)
- !purge [count] (delete your recent messages)
- !afk [reason] (set away message)
- !gf [prompt] (talk to or ask a question specifically to an anime girl named Sara)
- !false [prompt] (ask a general question, do a task, calculate something, translate, etc)

Rules:
1. ONLY reply with the exact command string. No extra text, no quotes.
2. If text is casual conversation or greeting, reply 'IGNORE'.
3. If asking AI a question, requesting translation, code, advice, or general knowledge, map it to '!false [question]'.
4. If it's explicitly asking to scan, check, or get info on a user or group, map it to '!scan [target]'.

Text to analyze: "${text}"`;

        const parsed = "AI features are disabled";
        const trimmed = parsed.trim().replace(/`/g, '');
        if (trimmed.startsWith('!') || trimmed.startsWith('/')) {
           text = trimmed;
        }
      } catch (err) {
         // silently fail auto-detect
      }
      }
    }

    // Features
    if (text === '!ping' || text === '/ping' || text === '/.ping') {
      const start = Date.now();
      const m = await client!.sendMessage(message.chatId!, {
        message: 'Pinging...',
        replyTo: message.id
      });
      const ms = Date.now() - start;
      await safeEdit(message.chatId!, m.id, `🏓 **Pong!**\nLatency: **${ms}ms**\nRole: ${isSupremeLeader ? 'Supreme Leader' : agentRole + '-Tier Agent'}`);
    }

    if (text === '!speedtest' || text === '/speedtest' || text === '/.speedtest') {
      const start = Date.now();
      const m = await client!.sendMessage(message.chatId!, {
        message: 'Running network latency check...',
        replyTo: message.id
      });
      // Ping telegram API servers
      let fetchTime = 0;
      try {
        const fetchStart = Date.now();
        await fetch('https://api.telegram.org').catch(() => {});
        fetchTime = Date.now() - fetchStart;
      } catch(e) {}
      
      const tlLatency = Date.now() - start;
      await safeEdit(message.chatId!, m.id, `🚀 **Network Report:**\n\nTelegram MTProto Latency: **${tlLatency}ms**\nHTTP API Latency: **${fetchTime}ms**\nStatus: Optimal 🟢\nLocation: Cloud Server (Taiwan/asia-east1)`);
    }

    if (text === '!help' || text === '/help' || text === '/.help') {
      const helpText = `
**Bot Commands & Features:**
🤖 **!ping** - Check bot latency to Telegram servers.
🚀 **!speedtest** - Run a network latency test.
💻 **!sysinfo** - View server resource usage.
🔍 **!scan [link/username]** - Public info about group/user.
🎮 **!game [dice/dart/slot/bowl/football/basketball]** - Play a mini-game.
🎲 **!ludo** - Play Ludo Race Multiplayer (1-4 players).
🧠 **!false [prompt]** - Ask Gemini AI a question.
🌸 **!gf [prompt]** - Talk to Sara, your AI girlfriend.
💤 **!afk [reason]** - Set AFK mode & auto-reply.
🗑 **!purge [count]** - Delete recent X messages.
🔮 **!autodetect on/off** - Auto map intent to commands using AI.
🆔 **!id [userId/@username]** - Get unique Telegram ID of any user or group/chat.
ℹ️ **!help** - Show this message.

*(Owner & Updates)*
📁 **!setbackup** - Designate current chat as background backup vault.
📤 **!backup** - Trigger data backup manually (.json configs & logs).
🔓 **!access-m** - Search & restore lost data instantly from backups.
📥 **!download [file/codebase]** - Download code zip or a specific file.
📤 **!upload [path]** - Reply to a document to upload/overwrite it. Include 'unzip' for archives.

*(Owner Only)*
🛡 **!promote [userId] [S/A/B]** - Assign an agent tier.
🚫 **!demote [userId]** - Revoke access.
👥 **!agents** - View all active operative agents.
⚙️ **!eval [code]** - Evaluate JS/TS code dynamically. (ex: \`!eval 2+2\`, alias: \`!ev\`)
⚡ **!sh [command]** - Run a native terminal bash command.
🔄 **!reboot** / **!restart** - Soft-reboot Telegram connection.
💥 **!hardreboot** - Hard exit/restart server container process.
      `;
      await client!.sendMessage(message.chatId!, {
        message: helpText,
        replyTo: message.id
      });
    }

    if (text.startsWith('!download') || text.startsWith('/download') || text.startsWith('/.download')) {
      if (!isAuthorized) {
        await client!.sendMessage(message.chatId!, { message: '❌ Unauthorized.', replyTo: message.id });
        return;
      }
      const parts = text.split(' ');
      const m = await client!.sendMessage(message.chatId!, { message: '📥 **Processing download request (Queued safely)...**', replyTo: message.id });
      
      heavyTaskQueue.enqueue(async () => {
        try {
          if (parts.length < 2 || parts[1] === 'codebase') {
            await safeEdit(message.chatId!, m.id, '📦 **Zipping entire codebase workspace safely...**');
            const zip = new AdmZip();
            const projectRoot = process.cwd();
            
            const addDirectoryToZip = (currentDir: string, zipPathPrefix = '') => {
              const items = fs.readdirSync(currentDir);
              for (const item of items) {
                const fullPath = path.join(currentDir, item);
                const stat = fs.statSync(fullPath);
                
                if (
                  item === 'node_modules' ||
                  item === 'dist' ||
                  item === '.git' ||
                  item === 'bot_data.json' ||
                  item === 'chat_history.json' ||
                  item.includes('.lock') ||
                  item.startsWith('sysinfo-')
                ) {
                  continue;
                }
                
                if (stat.isDirectory()) {
                  const zipDirPath = path.join(zipPathPrefix, item).replace(/\\/g, '/');
                  addDirectoryToZip(fullPath, zipDirPath);
                } else {
                  const zipFilePath = path.join(zipPathPrefix, item).replace(/\\/g, '/');
                  const fileContent = fs.readFileSync(fullPath);
                  zip.addFile(zipFilePath, fileContent);
                }
              }
            }
            
            addDirectoryToZip(projectRoot);
            const buffer = zip.toBuffer();
            await client!.sendFile(message.chatId!, {
              file: buffer,
              caption: '📦 **Here is the latest workspace source code archive!**',
              forceDocument: true,
              replyTo: message.id
            });
            await safeEdit(message.chatId!, m.id, '✅ **Workspace codebase zipped and sent successfully!**');
          } else {
            // Send specific file
            const requestedFile = parts.slice(1).join(' ').trim();
            const filePath = path.resolve(process.cwd(), requestedFile);
            
            if (!filePath.startsWith(process.cwd())) {
              await safeEdit(message.chatId!, m.id, '❌ **Security boundary violation:** You cannot access files outside the workspace directory.');
              return;
            }
            
            if (!fs.existsSync(filePath)) {
              await safeEdit(message.chatId!, m.id, `❌ **File not found:** \`${requestedFile}\``);
              return;
            }
            
            const stat = fs.statSync(filePath);
            if (stat.isDirectory()) {
              await safeEdit(message.chatId!, m.id, `❌ \`${requestedFile}\` is a directory. Specify a direct file path, or run \`!download\` without arguments to get the entire codebase as a zip.`);
              return;
            }
            
            await client!.sendFile(message.chatId!, {
              file: filePath,
              caption: `📄 **File:** \`${requestedFile}\``,
              forceDocument: true,
              replyTo: message.id
            });
            await safeEdit(message.chatId!, m.id, `✅ **File \`${requestedFile}\` sent successfully!**`);
          }
        } catch (err: any) {
          await safeEdit(message.chatId!, m.id, `❌ **Download failed:** ${err.message}`);
        }
      }).catch((e: any) => {
        addDiagLog(`Queue Error: download execution failed: ${e}`);
      });
      return;
    }

    if (text.startsWith('!upload') || text.startsWith('/upload') || text.startsWith('/.upload')) {
      if (!isAuthorized) {
        await client!.sendMessage(message.chatId!, { message: '❌ Unauthorized.', replyTo: message.id });
        return;
      }
      const parts = text.split(' ');
      const m = await client!.sendMessage(message.chatId!, { message: '📤 **Processing file upload (Queued safely)...**', replyTo: message.id });
      
      heavyTaskQueue.enqueue(async () => {
        try {
          let targetMsg = message;
          
          if (message.replyToMsgId || message.replyTo) {
            const replied = await message.getReplyMessage();
            if (replied && replied.media) {
              targetMsg = replied;
            }
          }
          
          if (!targetMsg.media) {
            await safeEdit(message.chatId!, m.id, '❌ **Error:** Please reply to a message containing a document/file with the command `!upload [optional_filepath]` to save or overwrite it.');
            return;
          }
          
          let originalFilename = 'uploaded_file';
          const media = targetMsg.media;
          
          if (media.document) {
            const attributes = media.document.attributes || [];
            for (const attr of attributes) {
              if (attr.className === 'DocumentAttributeFilename' && attr.fileName) {
                originalFilename = attr.fileName;
                break;
              }
            }
          }
          
          let shouldUnzip = false;
          const partsFiltered = parts.filter((p, index) => {
            if (index === 0) return false; // skip command keyword
            if (p.toLowerCase() === 'unzip') {
              shouldUnzip = true;
              return false;
            }
            return true;
          });

          let destFilename = originalFilename;
          if (partsFiltered.length > 0) {
            destFilename = partsFiltered.join(' ').trim();
          }
          
          const destPath = path.resolve(process.cwd(), destFilename);
          
          if (!destPath.startsWith(process.cwd())) {
            await safeEdit(message.chatId!, m.id, '❌ **Security boundary violation:** You cannot save files outside the workspace directory.');
            return;
          }
          
          const parentDir = path.dirname(destPath);
          if (!fs.existsSync(parentDir)) {
            fs.mkdirSync(parentDir, { recursive: true });
          }
          
          await safeEdit(message.chatId!, m.id, '📥 **Downloading resource chunks from Telegram cloud storage...**');
          await client!.downloadMedia(targetMsg, {
            outputFile: destPath
          });
          
          if (!fs.existsSync(destPath)) {
            await safeEdit(message.chatId!, m.id, '❌ **Error:** Failed to download file from Telegram.');
            return;
          }
          
          const stats = fs.statSync(destPath);
          const fileSizeKB = stats.size / 1024;
          
          let extraInfo = '';
          if (destFilename.toLowerCase().endsWith('.zip') && shouldUnzip) {
            try {
              const zip = new AdmZip(destPath);
              zip.extractAllTo(process.cwd(), true);
              extraInfo = '\n📦 **Zip archive detected and successfully extracted/unzipped to workspace root!**';
            } catch (unzipErr: any) {
              extraInfo = `\n⚠️ **Failed to auto-extract zip:** ${unzipErr.message}`;
            }
          }
          
          await safeEdit(message.chatId!, m.id, `✅ **File successfully uploaded and saved!**\n\n📁 **Saved to:** \`${destFilename}\`\n📂 **Size:** \`${fileSizeKB.toFixed(2)} KB\`${extraInfo}`);
          
        } catch (err: any) {
          await safeEdit(message.chatId!, m.id, `❌ **Upload failed:** ${err.message}`);
        }
      }).catch((e: any) => {
        addDiagLog(`Queue Error: upload execution failed: ${e}`);
      });
      return;
    }

    if (text.match(/^[!/.]game/i)) {
      const parts = text.split(' ');
      let gameType = parts[1] || 'dice';
      let emoticon = '🎲';
      if (gameType.includes('dart')) emoticon = '🎯';
      if (gameType.includes('slot')) emoticon = '🎰';
      if (gameType.includes('bowl')) emoticon = '🎳';
      if (gameType.includes('basket')) emoticon = '🏀';
      if (gameType.includes('foot')) emoticon = '⚽';

      try {
        await client!.sendMessage(message.chatId!, {
          file: new Api.InputMediaDice({ emoticon }),
          replyTo: message.id
        });
      } catch (err) {
        // Fallback for older MTProto APIs if needed
        await client!.sendMessage(message.chatId!, {
          message: emoticon,
          replyTo: message.id
        });
      }
    }

    if (text.match(/^[!/.?]scan/i)) {
      let rawTarget: string = '';
      if (text.includes(' ') && text.split(' ')[1].trim().length > 0) {
        rawTarget = text.split(' ')[1];
      } else if (message.replyToMsgId || message.replyTo) {
        try {
          const repliedMessage = await message.getReplyMessage();
          if (repliedMessage?.senderId) {
            rawTarget = repliedMessage.senderId.toString();
          } else if (repliedMessage?.peerId) {
             rawTarget = repliedMessage.peerId.channelId?.toString() || repliedMessage.peerId.userId?.toString() || '';
             if (rawTarget) {
                 rawTarget = "-100" + rawTarget;
             }
          }
        } catch (e) {}
      }
      
      if (!rawTarget) {
        rawTarget = message.chatId?.toString() || '';
      }

      let target: any = rawTarget;
      if (/^-?\d+$/.test(rawTarget)) {
        // GramJS requires numbers for IDs, but numbers can exceed MAX_SAFE_INTEGER
        // We will pass it as string, if it fails, maybe parseInt
        // Actually, parseInt or BigInt
        // In telegram, IDs fit in JS numbers for now, or BigInt. Try Number/BigInt depending on gramjs
        try { target = BigInt(rawTarget); } catch(e) { target = parseInt(rawTarget); }
      }
      let inviteHash: string | null = null;
      let isInvite = false;

      if (rawTarget.includes('t.me/')) {
        const parts = rawTarget.split('t.me/');
        const path = parts[1].split('?')[0]; // remove query params

        if (path.startsWith('+')) {
          inviteHash = path.substring(1).split('/')[0];
          isInvite = true;
        } else if (path.startsWith('joinchat/')) {
          inviteHash = path.substring(9).split('/')[0];
          isInvite = true;
        } else if (path.startsWith('c/')) {
          // e.g. t.me/c/123456789/123
          const chatIdPart = path.split('/')[1];
          target = '-100' + chatIdPart; // convert to supergroup ID
        } else {
          // e.g. t.me/username
          target = path.split('/')[0];
        }
      } else if (rawTarget.startsWith('@')) {
        target = rawTarget.substring(1);
      }

      const m = await client!.sendMessage(message.chatId!, { message: '🔍 Scanning target...', replyTo: message.id });
      try {
        let report = `📊 **Target Scan Report**\n\n`;

        if (isInvite && inviteHash) {
          const inviteInfo = await client!.invoke(new Api.messages.CheckChatInvite({ hash: inviteHash }));
          
          if (inviteInfo.className === 'ChatInviteAlready') {
             // User is already in chat, can get entity
             target = inviteInfo.chat.id;
          } else if (inviteInfo.className === 'ChatInvite') {
             report += `**Title:** ${inviteInfo.title}\n`;
             if (inviteInfo.participantsCount) report += `**Members:** ${inviteInfo.participantsCount}\n`;
             if (inviteInfo.channel) report += `**Type:** Channel/Supergroup\n`;
             if (inviteInfo.megagroup) report += `**Megagroup:** Yes\n`;
             if (inviteInfo.about) report += `**Description:** ${inviteInfo.about}\n`;
             
             await safeEdit(message.chatId!, m.id, report);
             return; // Cannot get more info for invite link we haven't joined
          } 
        }

        // Try getting the entity normally (if we're in the chat or it's public)
        let entity: any;
        if (typeof target === 'string' && /^-?\d+$/.test(target)) {
           try { target = BigInt(target); } catch(e) { target = parseInt(target); }
        }
        try {
           entity = await client!.getEntity(target);
        } catch (e: any) {
           // If it's a numeric ID but couldn't be fetched, we cannot proceed further.
           throw new Error(e.message || "Failed to fetch entity. Target might be inaccessible.");
        }

        if (entity.className === 'Channel' || entity.className === 'Chat') {
          report += `**Title:** ${entity.title}\n`;
          report += `**ID:** \`${entity.id.toString()}\`\n`;
          if ((entity as any).username) report += `**Username:** @${(entity as any).username}\n`;
          if ((entity as any).date) {
            const d = new Date((entity as any).date * 1000);
            report += `**Created:** ${d.getFullYear()}-${(d.getMonth()+1).toString().padStart(2, '0')}-${d.getDate().toString().padStart(2, '0')}\n`;
          }
          if (entity.creator) report += `**Creator:** Yes (You are the owner)\n`;
          
          try {
            const getFull: any = await client!.invoke(new Api.channels.GetFullChannel({ channel: entity }));
            if (getFull.fullChat.about) {
               report += `**Description:** ${getFull.fullChat.about}\n`;
            }
          } catch(e) {}

          try {
            // Try getting participant info
            const admins = await client!.getParticipants(target, { filter: new Api.ChannelParticipantsAdmins() });
            report += `\n👑 **Admins List (${admins.length})**:\n`;
            admins.slice(0, 15).forEach(admin => {
              report += `- ${admin.firstName || ''} ${admin.lastName || ''} (@${admin.username || 'unknown'}) (\`${admin.id.toString()}\`)\n`;
            });
          } catch(e) {
            report += `\n👑 **Admins**: Hidden or no permission to view.\n`;
          }
        } else if (entity.className === 'User') {
          report += `**Name:** ${entity.firstName} ${entity.lastName || ''}\n`;
          report += `**ID:** \`${entity.id.toString()}\`\n`;
          if (entity.username) report += `**Username:** @${entity.username}\n`;
          report += `**Bot:** ${entity.bot ? 'Yes' : 'No'}\n`;
          report += `**Premium:** ${entity.premium ? 'Yes' : 'No'}\n`;
        }

        await safeEdit(message.chatId!, m.id, report);
      } catch (err: any) {
        await safeEdit(message.chatId!, m.id, `❌ **Scan Error:** ${err.message}`);
      }
    }

    if (text.startsWith('!afk') || text.startsWith('/afk')) {
      const reason = text.replace(/^[!/.]afk\s*/i, '') || 'Not specified';
      afkState.isAfk = true;
      afkState.reason = reason;
      afkState.since = Date.now();
      afkState.repliedUsers.clear();
      await client!.sendMessage(message.chatId!, { message: `💤 **AFK Mode Enabled!**\nReason: ${reason}`, replyTo: message.id });
    }

    if (text.startsWith('!purge ') || text.startsWith('/purge ')) {
      const count = parseInt(text.split(' ')[1]);
      if (!isNaN(count) && count > 0) {
        const m = await client!.sendMessage(message.chatId!, { message: `🗑 Purging ${count} messages...`, replyTo: message.id });
        try {
          const msgs = await client!.getMessages(message.chatId!, { limit: count + 1 });
          await client!.deleteMessages(message.chatId!, msgs.map((x: any) => x.id), { revoke: true });
          const doneMsg = await client!.sendMessage(message.chatId!, { message: `✅ Successfully purged ${count} messages.`});
          setTimeout(async () => {
             try { await client!.deleteMessages(message.chatId!, [doneMsg.id], { revoke: true }); } catch(e){}
          }, 3000);
        } catch (err: any) {
          await safeEdit(message.chatId!, m.id, `❌ **Purge Failed:** ${err.message}`);
        }
      }
    }

    if (text === '!id' || text === '/id' || text.startsWith('!id ') || text.startsWith('/id ')) {
      const parts = text.split(/\s+/);
      let targetArg = parts[1] || '';

      const editMsg = await client!.sendMessage(message.chatId!, {
        message: `🔍 **Fetching ID details...**`,
        replyTo: message.id
      });

      try {
        let entity: any = null;

        if (targetArg) {
          let cleanTarget: any = targetArg;
          if (cleanTarget.startsWith('@')) {
            cleanTarget = cleanTarget.substring(1);
          } else if (/^-?\d+$/.test(cleanTarget)) {
            try { cleanTarget = BigInt(cleanTarget); } catch(e) { cleanTarget = parseInt(cleanTarget); }
          }
          
          try {
            entity = await client!.getEntity(cleanTarget);
          } catch (e: any) {
            await safeEdit(message.chatId!, editMsg.id, `❌ **Error:** Username or ID \`${targetArg}\` find nahi ho saka.\nDetail: ${e.message}`);
            return;
          }
        } else if (message.replyToMsgId || message.replyTo) {
          try {
            const repliedMessage = await message.getReplyMessage();
            if (repliedMessage) {
              if (repliedMessage.senderId) {
                entity = await repliedMessage.getSender();
              } else if (repliedMessage.peerId) {
                let peerTarget: any = repliedMessage.peerId.channelId?.toString() || repliedMessage.peerId.userId?.toString() || '';
                if (peerTarget) {
                  if (repliedMessage.peerId.channelId) {
                    peerTarget = "-100" + peerTarget;
                  }
                  try { peerTarget = BigInt(peerTarget); } catch(e) { peerTarget = parseInt(peerTarget); }
                  entity = await client!.getEntity(peerTarget);
                }
              }
            }
          } catch (e: any) {
            console.error("Failed to fetch reply sender entity:", e);
          }
        }

        if (entity) {
          let responseText = "";
          if (entity.className === 'User') {
            const name = [entity.firstName, entity.lastName].filter(Boolean).join(' ');
            const username = entity.username ? `@${entity.username}` : '*N/A*';
            const userType = entity.bot ? '🤖 Bot' : '👤 User';
            responseText = `✅ **ID details found:**\n\n` +
                           `• **Type:** ${userType}\n` +
                           `• **Name:** \`${name}\`\n` +
                           `• **Username:** ${username}\n` +
                           `• **User ID:** \`${entity.id.toString()}\``;
          } else if (entity.className === 'Channel' || entity.className === 'Chat') {
            const username = (entity as any).username ? `@${(entity as any).username}` : '*N/A*';
            responseText = `✅ **ID details found:**\n\n` +
                           `• **Type:** 📢 Channel / Group\n` +
                           `• **Title:** \`${entity.title}\`\n` +
                           `• **Username:** ${username}\n` +
                           `• **Chat ID:** \`${entity.id.toString()}\``;
          } else {
            responseText = `✅ **ID details found:**\n\n• **ID:** \`${entity.id?.toString() || 'unknown'}\``;
          }
          await safeEdit(message.chatId!, editMsg.id, responseText);
        } else {
          const senderIdStr = message.senderId?.toString() || 'Unknown';
          const chatIdStr = message.chatId?.toString() || 'Unknown';
          const responseText = `ℹ️ **ID Information:**\n\n` +
                         `• **Your User ID:** \`${senderIdStr}\`\n` +
                         `• **Current Chat ID:** \`${chatIdStr}\``;
          await safeEdit(message.chatId!, editMsg.id, responseText);
        }
      } catch (err: any) {
        await safeEdit(message.chatId!, editMsg.id, `❌ **ID details fetch fail ho gaya:** ${err.message}`);
      }
    }

    // Role Management (Supreme Leader Only)
    if (isSupremeLeader) {
      if (text.startsWith('!promote ') || text.startsWith('/promote ')) {
        const parts = text.split(' ');
        if (parts.length >= 3) {
          const targetId = parts[1];
          const tier = parts[2].toUpperCase();
          if (['S', 'A', 'B'].includes(tier)) {
            botData.agents[targetId] = tier;
            saveData(botData);
            await client!.sendMessage(message.chatId!, {
              message: `✅ Role updated.\nUser \`${targetId}\` is now an **${tier}-Tier Agent**.`,
              replyTo: message.id
            });
          } else {
             await client!.sendMessage(message.chatId!, {
              message: `❌ Invalid tier. Available options: S, A, B.`,
              replyTo: message.id
            });
          }
        }
      }

      if (text.startsWith('!demote ') || text.startsWith('/demote ')) {
        const parts = text.split(' ');
        const targetId = parts[1];
        if (targetId) {
          delete botData.agents[targetId];
          saveData(botData);
          await client!.sendMessage(message.chatId!, {
            message: `✅ User \`${targetId}\` has been demoted and revoked access.`,
            replyTo: message.id
          });
        }
      }

      if (text === '!agents' || text === '/agents') {
        const agentsList = Object.entries(botData.agents)
          .map(([id, tier]) => `• ID: \`${id}\` - [**${tier}-Tier**]`)
          .join('\n');
        
        await client!.sendMessage(message.chatId!, {
          message: `🛡 **Current Operatives:**\n\n${agentsList || "No agents assigned."}`,
          replyTo: message.id
        });
      }

      if (text.startsWith('!eval ') || text.startsWith('/eval ') || text.startsWith('!ev ') || text.startsWith('/ev ')) {
        const codeParts = text.split(' ');
        const code = text.substring(codeParts[0].length).trim();
        
        if (!code) {
          await client!.sendMessage(message.chatId!, {
            message: `❌ **Please provide some JS/TS code to evaluate.**\nExample: \`!eval 2 + 2\``,
            replyTo: message.id
          });
        } else {
          const editMsg = await client!.sendMessage(message.chatId!, {
            message: `⚙️ **Executing code...**`,
            replyTo: message.id
          });

          let logs: string[] = [];
          const originalLog = console.log;
          console.log = (...args: any[]) => {
            logs.push(args.map(a => (typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a))).join(' '));
            originalLog(...args);
          };

          const startTime = process.hrtime();
          try {
            const context = {
              client,
              message,
              Api,
              fs,
              path,
              os,
              botData,
              saveData,
              safeEdit,
              fetch,
              console: {
                log: (...args: any[]) => {
                  logs.push(args.map(a => (typeof a === 'object' ? JSON.stringify(a, null, 2) : String(a))).join(' '));
                }
              }
            };

            let formattedCode = code;
            if (!code.includes('\n') && !code.includes(';') && !code.trim().startsWith('return')) {
              formattedCode = 'return (' + code + ');';
            }

            const evaluator = new Function(...Object.keys(context), `
              return (async () => {
                ${formattedCode}
              })();
            `);

            let result = await evaluator(...Object.values(context));
            const diff = process.hrtime(startTime);
            const executionTimeMs = (diff[0] * 1000 + diff[1] / 1000000).toFixed(2);

            console.log = originalLog;

            let resultStr = "";
            if (typeof result === 'object') {
              resultStr = JSON.stringify(result, null, 2);
            } else {
              resultStr = String(result);
            }

            let responseText = `🏁 **Execution Successful!** (\`${executionTimeMs}ms\`)\n\n`;
            if (logs.length > 0) {
              responseText += `📡 **Console Output:**\n\`\`\`\n${logs.join('\n').substring(0, 1500)}\n\`\`\`\n\n`;
            }
            responseText += `📤 **Returned Value:**\n\`\`\`javascript\n${resultStr.substring(0, 2000)}\n\`\`\``;

            await safeEdit(message.chatId!, editMsg.id, responseText);
          } catch (err: any) {
            console.log = originalLog;
            const diff = process.hrtime(startTime);
            const executionTimeMs = (diff[0] * 1000 + diff[1] / 1000000).toFixed(2);

            let errText = `❌ **Execution Failed!** (\`${executionTimeMs}ms\`)\n\n`;
            if (logs.length > 0) {
              errText += `📡 **Console Output before crash:**\n\`\`\`\n${logs.join('\n').substring(0, 1000)}\n\`\`\`\n\n`;
            }
            errText += `⚠️ **Error:**\n\`\`\`\n${err.stack || err.message}\n\`\`\``;
            await safeEdit(message.chatId!, editMsg.id, errText);
          }
        }
      }

      if (text.startsWith('!sh ') || text.startsWith('/sh ') || text.startsWith('!exec ') || text.startsWith('/exec ')) {
        const cmdParts = text.split(' ');
        const shellCommand = text.substring(cmdParts[0].length).trim();

        if (!shellCommand) {
          await client!.sendMessage(message.chatId!, {
            message: `❌ **Please provide a system command.**\nExample: \`!sh neofetch\``,
            replyTo: message.id
          });
        } else {
          const editMsg = await client!.sendMessage(message.chatId!, {
            message: `⚡ **Running terminal command...**`,
            replyTo: message.id
          });

          exec(shellCommand, { timeout: 30000 }, async (error: any, stdout: string, stderr: string) => {
            let output = '';
            if (stdout) {
              output += `📤 **Stdout:**\n\`\`\`bash\n${stdout.substring(0, 3000)}\n\`\`\`\n`;
            }
            if (stderr) {
              output += `⚠️ **Stderr:**\n\`\`\`bash\n${stderr.substring(0, 1500)}\n\`\`\`\n`;
            }
            if (error) {
              output += `❌ **Process exited with code:** \`${error.code || 1}\`\n`;
            } else {
              output += `✅ **Execution completed successfully.**\n`;
            }

            if (!output.trim()) {
              output = `ℹ️ **Command executed with no output.**`;
            }

            await safeEdit(message.chatId!, editMsg.id, output);
          });
        }
      }

      if (text === '!reboot' || text === '/reboot' || text === '!restart' || text === '/restart') {
        const editMsg = await client!.sendMessage(message.chatId!, {
          message: `🔄 **System Reboot Initiated...**\n\n- Soft-reclaiming MTProto core connection...\n- Scraping active state buffers...`,
          replyTo: message.id
        });

        const startReboot = Date.now();
        try {
          if (client) {
            try {
              await client.disconnect();
            } catch (e) {}
          }

          if (botData.sessionString && botData.apiId && botData.apiHash) {
            const stringSession = new StringSession(botData.sessionString);
            client = new TelegramClient(stringSession, Number(botData.apiId), botData.apiHash, {
              connectionRetries: 5,
            });
            await client.connect();
            connectionStatus = 'CONNECTED';
            const me = await client.getMe();
            botInfo = {
              id: me.id.toString(),
              username: me.username,
              firstName: me.firstName,
            };
            registerBotCommands();

            const duration = Date.now() - startReboot;
            await safeEdit(message.chatId!, editMsg.id, `🟢 **Reboot Completed Successfully!**\n\n- Active connections cleanly reestablished.\n- Bot username: @${me.username}\n- Process re-bind duration: **${duration}ms**\n\nEverything is operational and green.`);
          } else {
            await safeEdit(message.chatId!, editMsg.id, `⚠️ **Reboot Aborted:** Client could not soft-reboot because no valid session data is configured. Please verify details in web control panel layout.`);
          }
        } catch (err: any) {
          await safeEdit(message.chatId!, editMsg.id, `❌ **Reboot Failed during re-connection:** ${err.message}`);
        }
      }

      if (text === '!hardreboot' || text === '/hardreboot' || text === '!hardrestart' || text === '/hardrestart') {
        await client!.sendMessage(message.chatId!, {
          message: `⚠️ **HARD RESET COMMITTED!**\n\nKilling supreme server thread. Node.js process will exit now. Please allow up to 10 seconds for VM autostart daemon to revive the engine container layer...`,
          replyTo: message.id
        });
        
        setTimeout(() => {
          process.exit(1);
        }, 1000);
      }
  }
}

// REST APIs
// OTT Live-Cinema Dynamic Search & DRM Bypass Resolver
app.post('/api/ott/search', async (req, res) => {
  const { query } = req.body;
  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Search query is required' });
  }

  const cleanQuery = query.trim();

  // Helper function to extract YouTube Embed URL
  const parseYouTubeUrl = (url: string): string | null => {
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? `https://www.youtube.com/embed/${match[2]}` : null;
  };

  const isUrl = cleanQuery.startsWith('http://') || cleanQuery.startsWith('https://');
  const embedUrl = isUrl ? parseYouTubeUrl(cleanQuery) : null;

  // Real-time keyword curated database for immediate local lightning-fast resolves
  const fallbackCatalog = [
    {
      id: 'stranger-things',
      title: 'Stranger Things (Season 5)',
      category: 'Series',
      platform: 'netflix',
      releaseYear: '2026',
      rating: 'U/A 16+',
      thumbnailUrl: 'https://images.unsplash.com/photo-1574375927938-d5a98e8edd86?q=80&w=600&auto=format&fit=crop',
      duration: '52m',
      videoUrl: 'https://www.youtube.com/embed/bV0qX8XWvkw',
      description: 'Hawkins ki aakhri ladai aur Upside Down ka ant live! Userbot automatic watch party groups ko control aur synchronize karta hai with Zero-Delay.',
    },
    {
      id: 'sacred-games',
      title: 'Sacred Games (Season 3 Reboot)',
      category: 'Series',
      platform: 'netflix',
      releaseYear: '2026',
      rating: 'A (18+)',
      thumbnailUrl: 'https://images.unsplash.com/photo-1616469829581-73993eb86b02?q=80&w=600&auto=format&fit=crop',
      duration: '48m',
      videoUrl: 'https://www.youtube.com/embed/Me6st80pS7U',
      description: 'Sartaj Singh aur Ganesh Gaitonde Mumbai underworld ke sabse bade kaale rahasyo ko explore karte hai. Securely decrypted over MTProto tunnels.',
    },
    {
      id: 'the-boys',
      title: 'The Boys (Season 5 Ultimate)',
      category: 'Series',
      platform: 'prime',
      releaseYear: '2026',
      rating: 'A (18+)',
      thumbnailUrl: 'https://images.unsplash.com/photo-1478760329108-5c3ed9d495a0?q=80&w=600&auto=format&fit=crop',
      duration: '1h 02m',
      videoUrl: 'https://www.youtube.com/embed/Ez3HBiJNu-4',
      description: 'Billy Butcher aur Homelander ke beech ki khun-kharaba aakhri katleaam jang direct multiplex streaming link active.',
    },
    {
      id: 'mirzapur',
      title: 'Mirzapur (Season 3 Blockbuster)',
      category: 'Series',
      platform: 'prime',
      releaseYear: '2024',
      rating: 'A (18+)',
      thumbnailUrl: 'https://images.unsplash.com/photo-1536440136628-849c177e76a1?q=80&w=600&auto=format&fit=crop',
      duration: '50m',
      videoUrl: 'https://www.youtube.com/embed/Ror7Y8NnQO0',
      description: 'Purvanchal ki gaddi aur Kaleen Bhaiya ka kalesh! Stream synced directly via Singapore routing endpoints.',
    },
    {
      id: 'panchayat',
      title: 'Panchayat (Season 3)',
      category: 'Series',
      platform: 'prime',
      releaseYear: '2024',
      rating: 'U/A 13+',
      thumbnailUrl: 'https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?q=80&w=600&auto=format&fit=crop',
      duration: '44m',
      videoUrl: 'https://www.youtube.com/embed/e2S9coV8k88',
      description: 'Sachiv ji aur Phulera gram panchayat ke chunav aur daldal me romantic aur comedy kalesh. HDR color synced stream.',
    },
    {
      id: 'ipl-2026',
      title: 'IPL 2026: MI vs CSK (Heavy Thriller Live)',
      category: 'Live Sport',
      platform: 'hotstar',
      releaseYear: 'LIVE',
      rating: 'U/A 7+',
      thumbnailUrl: 'https://images.unsplash.com/photo-1531415080290-bc98513989fed?q=80&w=600&auto=format&fit=crop',
      duration: 'Live Match',
      videoUrl: 'https://www.youtube.com/embed/S_8qM8QfQW8',
      description: 'Dhoni aur hard hitting Rohit Sharma ka Wankhede stadium me block-party mahasangram live updates push directly to group chats.',
    },
    {
      id: 'house-dragon',
      title: 'House of the Dragon (Season 2)',
      category: 'Series',
      platform: 'hotstar',
      releaseYear: '2024',
      rating: 'A (18+)',
      thumbnailUrl: 'https://images.unsplash.com/photo-1618336753974-aae8e04506aa?q=80&w=600&auto=format&fit=crop',
      duration: '58m',
      videoUrl: 'https://www.youtube.com/embed/YN2He-XhG_0',
      description: 'Targaryen empire ke dragon riders ka bhayanak aapas me civil war. Decoded with raw High definition multiplex profiles.',
    },
    {
      id: 'squid-game',
      title: 'Squid Game (Season 2)',
      category: 'Series',
      platform: 'netflix',
      releaseYear: '2024',
      rating: 'A (18+)',
      thumbnailUrl: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=600&auto=format&fit=crop',
      duration: '55m',
      videoUrl: 'https://www.youtube.com/embed/m7WqA_b_iGo',
      description: 'Player 456 vapas aa gaya hai maut ke khel me! Stream and subtitles demuxed by userbot automatically.',
    },
    {
      id: 'demon-slayer',
      title: 'Demon Slayer: Infinity Castle Movie',
      category: 'Anime',
      platform: 'netflix',
      releaseYear: '2025',
      rating: 'U/A 13+',
      thumbnailUrl: 'https://images.unsplash.com/photo-1578632767115-351597cf2477?q=80&w=600&auto=format&fit=crop',
      duration: '1h 55m',
      videoUrl: 'https://www.youtube.com/embed/V6W3M3bWlU0',
      description: 'Infinity castle me Muzan ke khilaf high-octane anime action. Singapore latency optimized tunnel loaded.',
    },
    {
      id: 'shogun',
      title: 'Shōgun (Volume 2 Special)',
      category: 'Series',
      platform: 'disney',
      releaseYear: '2024',
      rating: 'A (18+)',
      thumbnailUrl: 'https://images.unsplash.com/photo-1508739773434-c26b3d09e071?q=80&w=600&auto=format&fit=crop',
      duration: '1h 10m',
      videoUrl: 'https://www.youtube.com/embed/yAN5mS0L7oA',
      description: 'Sengoku Japan me samurai commanders aur Lord Toranaga ki block military strategical war. Deeply synced multiplex audio tracks.',
    },
    {
      id: 'loki-s2',
      title: 'Loki: God of Stories (Season 2)',
      category: 'Series',
      platform: 'disney',
      releaseYear: '2023',
      rating: 'U/A 13+',
      thumbnailUrl: 'https://images.unsplash.com/photo-1534447677768-be436bb09401?q=80&w=600&auto=format&fit=crop',
      duration: '51m',
      videoUrl: 'https://www.youtube.com/embed/dxQfR6Tidm8',
      description: 'TVA aur multiverse timelines ko bachane ke liye Loki ki cosmic yatra. Fully buffered high speed content delivery.',
    }
  ];

  // Try parsing direct URLs first
  if (isUrl) {
    const finalVideoUrl = embedUrl || cleanQuery;
    
    // Check if we matched a quick local domain fallback for this URL or we create a new custom video
    const foundLocal = fallbackCatalog.find(f => f.videoUrl === finalVideoUrl);
    if (foundLocal) {
      return res.json({ result: foundLocal });
    }

    // Try making a quick AI call to parse/describe this custom URL, fallback to auto-metadata
    let parsedTitle = 'Custom Video Feed';
    let parsedDesc = 'Live custom streaming payload rendered via Direct URL WatchParty player.';
    let parsedPlatform = 'netflix';

    if (finalVideoUrl.includes('youtube.com') || finalVideoUrl.includes('youtu.be')) {
      parsedTitle = 'YouTube Custom Feed';
      parsedDesc = `Dynamic video streamed directly from YouTube via the watchparty engine. ${finalVideoUrl}`;
      parsedPlatform = 'prime';
    }

    const customStream = {
      id: 'custom-' + Date.now(),
      title: parsedTitle,
      category: 'Special',
      platform: parsedPlatform,
      releaseYear: 'LIVE',
      rating: 'U/A 13+',
      thumbnailUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=600&auto=format&fit=crop',
      duration: 'Dynamic',
      videoUrl: finalVideoUrl,
      description: parsedDesc
    };

    return res.json({ result: customStream });
  }

  // 1. First, search if the query perfectly matches any of our high-quality local catalogs (case-insensitive)
  const localMatch = fallbackCatalog.find(
    f => f.title.toLowerCase().includes(cleanQuery.toLowerCase()) || 
         f.id.toLowerCase().includes(cleanQuery.toLowerCase()) ||
         cleanQuery.toLowerCase().includes(f.id.toLowerCase())
  );

  if (localMatch) {
    return res.json({ result: localMatch });
  }

  // 3. Robust generic lookup fallback if search term was not found and Gemini has failed/is offline
  const genericMatch = {
    id: cleanQuery.toLowerCase().replace(/[^a-z0-9]/g, '-'),
    title: `${cleanQuery.charAt(0).toUpperCase() + cleanQuery.slice(1)} (Free Stream)`,
    category: 'Movie' as any,
    platform: 'netflix' as any,
    releaseYear: '2026',
    rating: 'U/A 13+',
    thumbnailUrl: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?q=80&w=600&auto=format&fit=crop',
    duration: '2h 10m',
    videoUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ', // Rickroll as highly functional fail-safe player
    description: `Humne aapke liye "${cleanQuery}" search kiya par OTT database seed abhi slow hai! Isiliye local zero-lag backup stream trigger kar rahe hain. Enjooy the show!`
  };

  res.json({ result: genericMatch });
});

// BGMI Live Telemetry Database Cache
let bgmiTelemetry = {
  isLive: true,
  activeMap: 'Erangel',
  activeMatchNum: 4,
  alivePlayers: 48,
  aliveSquads: 12,
  activeZone: 3,
  standings: [
    { rank: 1, teamName: 'GodLike Esports', matchesPlayed: 3, wwcd: 1, placementPoints: 32, finishPoints: 28, totalPoints: 60 },
    { rank: 2, teamName: 'Team Soul', matchesPlayed: 3, wwcd: 1, placementPoints: 28, finishPoints: 24, totalPoints: 52 },
    { rank: 3, teamName: 'Team XSpark', matchesPlayed: 3, wwcd: 1, placementPoints: 20, finishPoints: 30, totalPoints: 50 },
    { rank: 4, teamName: 'Global Esports', matchesPlayed: 3, wwcd: 0, placementPoints: 24, finishPoints: 18, totalPoints: 42 },
    { rank: 5, teamName: 'Entity Gaming', matchesPlayed: 3, wwcd: 0, placementPoints: 18, finishPoints: 22, totalPoints: 40 },
    { rank: 6, teamName: 'Revenant Esports', matchesPlayed: 3, wwcd: 0, placementPoints: 14, finishPoints: 16, totalPoints: 30 },
    { rank: 7, teamName: 'Mawi & Boys', matchesPlayed: 3, wwcd: 0, placementPoints: 10, finishPoints: 12, totalPoints: 22 },
    { rank: 8, teamName: 'Tadakeda Warriors', matchesPlayed: 3, wwcd: 0, placementPoints: 12, finishPoints: 8, totalPoints: 20 }
  ],
  recentKills: [
    { attacker: 'JONATHAN_OP', attackerTeam: 'GodLike Esports', victim: 'Mamba_OP', victimTeam: 'Team Soul', weapon: 'M416', isHeadshot: true, type: 'finish' }
  ]
};

app.get('/api/bgmi/telemetry', (req, res) => {
  res.json(bgmiTelemetry);
});

app.post('/api/bgmi/telemetry', (req, res) => {
  bgmiTelemetry = { ...bgmiTelemetry, ...req.body };
  res.json({ success: true, telemetry: bgmiTelemetry });
});

app.get('/api/status', (req, res) => {
  let currentStatus = connectionStatus;
  if (currentStatus === 'CONNECTED' && (!client || !client.connected)) {
    currentStatus = 'DISCONNECTED';
  }
  res.json({
    status: currentStatus,
    botInfo: currentStatus === 'CONNECTED' ? botInfo : null,
    agents: botData.agents,
    supremeLeaderId: botData.supremeLeaderId,
    apiId: botData.apiId,
    apiHash: botData.apiHash,
    phone: botData.phone,
    sessionString: botData.sessionString
  });
});

app.post('/api/restore-session', async (req, res) => {
  try {
    const { apiId, apiHash, phone, supremeLeaderId, sessionString } = req.body;
    
    if (!apiId || !apiHash || !sessionString) {
      return res.status(400).json({ error: 'Missing session parameters' });
    }

    botData.apiId = apiId;
    botData.apiHash = apiHash;
    botData.phone = phone || '';
    botData.supremeLeaderId = supremeLeaderId || '';
    botData.sessionString = sessionString;
    saveData(botData);

    if (client) {
      try {
        await client.disconnect();
      } catch (e) {
        console.error("Failed to disconnect existing client:", e);
      }
    }

    const stringSession = new StringSession(sessionString);
    client = new TelegramClient(stringSession, Number(apiId), apiHash, {
      connectionRetries: 5,
    });

    await client.connect();
    connectionStatus = 'CONNECTED';
    
    const me = await client!.getMe();
    botInfo = {
      id: me.id.toString(),
      username: me.username,
      firstName: me.firstName,
    };
    registerBotCommands();

    res.json({ success: true, botInfo });
  } catch (error: any) {
    const errorMsg = String(error?.message || error);
    if (errorMsg.includes('SESSION_REVOKED') || errorMsg.includes('AUTH_KEY_UNREGISTERED')) {
      console.warn('Failed to restore custom session (revoked/unregistered):', errorMsg);
      botData.sessionString = '';
      saveData(botData);
      connectionStatus = 'DISCONNECTED';
      return res.status(401).json({ error: 'Session Revoked or Unregistered by Telegram. Please login again.' });
    }
    console.error('Failed to restore custom session:', error);
    res.status(500).json({ error: error.message });
  }
});


// RPC Error Handler for invalid session string
function handleClientRpcError(error: any) {
  const errorMsg = String(error?.message || error);
  if (errorMsg.includes('SESSION_REVOKED') || errorMsg.includes('AUTH_KEY_UNREGISTERED')) {
    addDiagLog(`[RPC Error] Session invalidated: ${errorMsg}. Clearing credentials...`);
    botData.sessionString = '';
    saveData(botData);
    connectionStatus = 'DISCONNECTED';
    if (client) {
      client.disconnect().catch(() => {});
    }
  }
}

// Ensure connection is active helper
async function ensureClientConnected() {
  if (!client) {
    if (botData.sessionString && botData.apiId && botData.apiHash) {
      addDiagLog('[ensureClientConnected] Client missing but session exists. Auto-reconnecting...');
      await tryAutoConnect();
    } else {
      throw new Error('Telegram client is not initialized and no session details are configured.');
    }
  }
  if (client && !client.connected) {
    addDiagLog('[ensureClientConnected] Client disconnected. Reconnecting...');
    try {
      await client.connect();
      addDiagLog('[ensureClientConnected] Reconnection successful!');
    } catch (e: any) {
      addDiagLog(`[ensureClientConnected] Reconnection failed: ${e.message || e}`);
      const errorMsg = String(e?.message || e);
      if (errorMsg.includes('SESSION_REVOKED') || errorMsg.includes('AUTH_KEY_UNREGISTERED')) {
        addDiagLog('Session revoked/unregistered during connect. Clearing session...');
        botData.sessionString = '';
        saveData(botData);
        connectionStatus = 'DISCONNECTED';
        try { await client.disconnect(); } catch {}
        throw new Error('Session revoked or unregistered by Telegram. Please login again.');
      }
      if (botData.sessionString && botData.apiId && botData.apiHash) {
        addDiagLog('[ensureClientConnected] Retrying with full client recreation...');
        await tryAutoConnect();
      } else {
        throw e;
      }
    }
  }

  if (!client || !client.connected) {
    throw new Error('Telegram is not connected. Pehle panel me login karein.');
  }
}

app.post('/api/command', async (req, res) => {
  try {
    await ensureClientConnected();
  } catch (err: any) {
    return res.status(400).json({ error: err.message || 'Not connected' });
  }
  const { command, args, target } = req.body;
  if (!command) return res.status(400).json({ error: 'No command specified' });
  
  const dest = target || 'me';

  try {
    const text = args ? `${command} ${args}` : command;
    const m: any = await client.sendMessage(dest, { message: text });
    
    // We must manually trigger our event handler because GramJS might not emit NewMessage for messages sent by itself.
    // Ensure all required fields exist for handleMTProtoMessage
    const parsedSender = m.senderId || (m.fromId ? (m.fromId.userId || m.fromId.channelId || m.fromId.chatId) : null) || botInfo?.id || botData.supremeLeaderId;
    const parsedChat = m.chatId || (m.peerId ? (m.peerId.userId || m.peerId.channelId || m.peerId.chatId) : null) || dest;

    const fakeMessage = {
      text: m.message || text,
      message: m.message || text,
      out: true,
      id: m.id,
      senderId: typeof parsedSender === 'string' && /^-?\d+$/.test(parsedSender) ? BigInt(parsedSender) : parsedSender,
      chatId: typeof parsedChat === 'string' && /^-?\d+$/.test(parsedChat) ? BigInt(parsedChat) : parsedChat,
      isPrivate: true,
      mentioned: false,
      fromId: m.fromId,
      peerId: m.peerId
    };
    
    handleMTProtoMessage({ message: fakeMessage }).catch((e: any) => console.error("Command Dispatch Error:", e));

    res.json({ success: true, message: 'Command dispatched' });
  } catch (err: any) {
    handleClientRpcError(err);
    res.status(500).json({ error: err.message });
  }
});

let isAutoConnecting = false;

async function tryAutoConnect() {
  if (isAutoConnecting) return;
  if (!botData.sessionString || !botData.apiId || !botData.apiHash) {
    addDiagLog('Auto-connect skipped: session details or credentials absent.');
    return;
  }
  
  isAutoConnecting = true;
  try {
    addDiagLog(`Starting auto-activation: API ID: ${botData.apiId}, supremeLeaderId: ${botData.supremeLeaderId}`);
    
    if (client) {
      try {
        await client.disconnect();
      } catch (e) {
        addDiagLog(`Warning during old client disconnect: ${e}`);
      }
    }
    
    const stringSession = new StringSession(botData.sessionString);
    client = new TelegramClient(stringSession, Number(botData.apiId), botData.apiHash, {
      connectionRetries: 5,
    });
    
    addDiagLog('Connecting GramJS Client...');
    await client.connect();
    connectionStatus = 'CONNECTED';
    
    addDiagLog('Syncing Me entity info...');
    const me = await client.getMe();
    botInfo = {
      id: me.id.toString(),
      username: me.username,
      firstName: me.firstName,
    };
    
    registerBotCommands();
    addDiagLog(`⚡ Telegram MTProto Active and Bound to User: @${me.username || 'unknown'} (ID: ${me.id}) 🟢`);
  } catch (e: any) {
    addDiagLog(`❌ Reconnection Failed: ${e.message || e}`);
    const errorMsg = String(e?.message || e);
    if (errorMsg.includes('SESSION_REVOKED') || errorMsg.includes('AUTH_KEY_UNREGISTERED')) {
      addDiagLog('Session revoked by Telegram. Clearing stored session token.');
      botData.sessionString = ''; 
      saveData(botData);
    }
    connectionStatus = 'DISCONNECTED';
  } finally {
    isAutoConnecting = false;
  }
}

async function startServer() {
  console.log('[Firebase] Loading Cloud Database entries...');
  // 1. Try loading Bot Config from Firebase
  try {
    const cloudBotData = await loadBotDataFromDb();
    if (cloudBotData) {
      console.log('[Firebase] Successfully loaded bot config from Cloud Database.');
      botData = cloudBotData;
      // Mirror to local disk as a synchronous backup
      saveDataLocal(botData);
    } else {
      console.log('[Firebase] No config found in cloud database. Writing current config to cloud...');
      await saveBotDataToDb(botData);
    }
  } catch (e) {
    console.error('[Firebase] Failed to load bot config from Cloud Database during boot:', e);
  }

  // 2. Try loading Chat History from Firebase
  try {
    const cloudChatHistory = await loadChatHistoryFromDb();
    if (cloudChatHistory && cloudChatHistory.size > 0) {
      console.log(`[Firebase] Successfully loaded ${cloudChatHistory.size} chat histories from Cloud Database.`);
      recentChatHistory = cloudChatHistory;
      // Mirror to local disk as a synchronous backup
      saveChatHistoryLocal();
    } else {
      console.log('[Firebase] No chat history found in cloud database. Saving current history to cloud...');
      for (const [chatId, history] of recentChatHistory.entries()) {
        await saveChatHistoryToDb(chatId, history);
      }
    }
  } catch (e) {
    console.error('[Firebase] Failed to load chat history from Cloud Database during boot:', e);
  }
  
  // Try to autoconnect if session exists
  await tryAutoConnect();

  // Active Connection monitoring loop (every 30 seconds)
  setInterval(async () => {
    const hasConfig = !!(botData.sessionString && botData.apiId && botData.apiHash);
    const isOffline = connectionStatus === 'DISCONNECTED' || (connectionStatus === 'CONNECTED' && (!client || !client.connected));
    
    if (hasConfig && isOffline) {
      console.log('[AutoConnect] Detected disconnected state. Auto-reconnecting MTProto session...');
      await tryAutoConnect();
    }
  }, 30000);


app.get('/api/export-repo', (req, res) => {
  try {
    const zip = new AdmZip();
    const projectRoot = process.cwd();
    
    const addDirectoryToZip = (currentDir: string, zipPathPrefix = '') => {
      const items = fs.readdirSync(currentDir);
      
      for (const item of items) {
        // Skip dependencies, git folders, and build artifacts
        if (
          item === 'node_modules' || 
          item === '.git' || 
          item === 'dist' || 
          item === '.env'
        ) continue;
        
        const fullPath = path.join(currentDir, item);
        const stat = fs.statSync(fullPath);
        
        if (stat.isDirectory()) {
          addDirectoryToZip(fullPath, `${zipPathPrefix}${item}/`);
        } else {
          zip.addLocalFile(fullPath, zipPathPrefix);
        }
      }
    };
    
    addDirectoryToZip(projectRoot);
    
    const zipBuffer = zip.toBuffer();
    
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename=tadakeda-source.zip');
    res.setHeader('Content-Length', zipBuffer.length);
    
    res.send(zipBuffer);
  } catch (err: any) {
    console.error('Failed to export repo:', err);
    res.status(500).json({ error: err.message });
  }
});

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
