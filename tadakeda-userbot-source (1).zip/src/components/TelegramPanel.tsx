import React, { useState, useEffect, useRef } from 'react';
import { MessageSquare, Send, RefreshCcw, Search, ShieldAlert, Cpu, FolderOpen, Terminal, X } from 'lucide-react';

interface Chat {
  id: string;
  title: string;
  unreadCount: number;
  message: string;
  username?: string;
  firstName?: string;
  lastName?: string;
  type: string;
  date?: number;
}

interface Message {
  id: number;
  senderId: string;
  senderName: string;
  message: string;
  date: number;
  out: boolean;
  media: boolean;
}

type FolderType = 'all' | 'personal' | 'bot' | 'group' | 'channel';

export function TelegramPanel() {
  const [chats, setChats] = useState<Chat[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [loadingChats, setLoadingChats] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [sending, setSending] = useState(false);
  const [newMessage, setNewMessage] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  
  // Folders category tab state
  const [currentFolder, setCurrentFolder] = useState<FolderType>('all');
  
  const [errorChats, setErrorChats] = useState<string | null>(null);
  const [errorMessages, setErrorMessages] = useState<string | null>(null);

  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [diagnosticsData, setDiagnosticsData] = useState<any>(null);
  const [loadingDiag, setLoadingDiag] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  const loadDiagnostics = async () => {
    setLoadingDiag(true);
    try {
      const res = await fetch('/api/telegram/diagnostics');
      if (res.ok) {
        const data = await res.json();
        setDiagnosticsData(data);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingDiag(false);
    }
  };

  useEffect(() => {
    if (!showDiagnostics) return;
    loadDiagnostics();
    const interval = setInterval(loadDiagnostics, 3000);
    return () => clearInterval(interval);
  }, [showDiagnostics]);

  const loadChats = async () => {
    setLoadingChats(true);
    setErrorChats(null);
    try {
      const res = await fetch('/api/telegram/chats');
      if (res.ok) {
        const data = await res.json();
        setChats(data.chats || []);
      } else {
        const errData = await res.json().catch(() => ({ error: 'Error loading chats. Make sure Telegram is connected on the main dashboard!' }));
        setErrorChats(errData.error);
      }
    } catch (e: any) {
      setErrorChats(e.message || 'Connection error. Please try again.');
    } finally {
      setLoadingChats(false);
    }
  };

  const loadMessages = async (chat: Chat, silent = false) => {
    if (!silent) setLoadingMessages(true);
    setErrorMessages(null);
    try {
      const res = await fetch(`/api/telegram/messages?chatId=${chat.id}`);
      if (res.ok) {
        const data = await res.json();
        
        let shouldScroll = false;
        if (timelineRef.current) {
          const { scrollTop, scrollHeight, clientHeight } = timelineRef.current;
          // If silent is false (manual action or chat switch), always scroll to bottom
          // If silent is true (auto polling), only scroll if the user was already near the bottom (within 150px)
          const isAtBottom = scrollHeight - scrollTop - clientHeight < 150;
          if (!silent || isAtBottom) {
            shouldScroll = true;
          }
        } else {
          shouldScroll = true;
        }

        setMessages(data.messages || []);

        if (shouldScroll) {
          setTimeout(() => {
            if (timelineRef.current) {
              timelineRef.current.scrollTop = timelineRef.current.scrollHeight;
            }
          }, 30);
        }
      } else {
        const errData = await res.json().catch(() => ({ error: 'Failed to sync latest history' }));
        setErrorMessages(errData.error);
      }
    } catch (e: any) {
      setErrorMessages(e.message || 'Network delay');
    } finally {
      if (!silent) setLoadingMessages(false);
    }
  };

  // Initial load
  useEffect(() => {
    loadChats();
  }, []);

  // Poll active chat messages every 4 seconds for realtime messaging feel
  useEffect(() => {
    if (!selectedChat) return;
    loadMessages(selectedChat);
    
    const interval = setInterval(() => {
      loadMessages(selectedChat, true);
    }, 4000);

    return () => clearInterval(interval);
  }, [selectedChat]);

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!selectedChat || !newMessage.trim() || sending) return;

    setSending(true);
    const msgToSend = newMessage;
    setNewMessage('');

    try {
      const res = await fetch('/api/telegram/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chatId: selectedChat.id, message: msgToSend })
      });

      if (res.ok) {
        loadMessages(selectedChat);
      } else {
        const errData = await res.json().catch(() => ({ error: 'Failed' }));
        alert(`Bhai message deliver nahi ho paya: ${errData.error}`);
      }
    } catch (e: any) {
      alert(`Network Error: ${e.message}`);
    } finally {
      setSending(false);
    }
  };

  // Filter based on Tab selector & Search term
  const getFilteredChats = () => {
    // 1. First apply search query filter
    let rawList = chats.filter(c =>
      c.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
      (c.username && c.username.toLowerCase().includes(searchTerm.toLowerCase()))
    );

    // 2. Then separate into selected category tabs
    if (currentFolder === 'personal') {
      return rawList.filter(c => c.type === 'user');
    }
    if (currentFolder === 'bot') {
      return rawList.filter(c => c.type === 'bot');
    }
    if (currentFolder === 'group') {
      return rawList.filter(c => c.type === 'group');
    }
    if (currentFolder === 'channel') {
      return rawList.filter(c => c.type === 'channel');
    }
    return rawList; // 'all' folder
  };

  const filteredChats = getFilteredChats();

  // Helper counters for each folder
  const getFolderCount = (type: FolderType) => {
    if (type === 'all') return chats.length;
    if (type === 'personal') return chats.filter(c => c.type === 'user').length;
    if (type === 'bot') return chats.filter(c => c.type === 'bot').length;
    if (type === 'group') return chats.filter(c => c.type === 'group').length;
    if (type === 'channel') return chats.filter(c => c.type === 'channel').length;
    return 0;
  };

  return (
    <div className="bg-white border border-slate-200 rounded-2xl shadow-xl overflow-hidden font-sans">
      
      {/* Header Panel with Classic Telegram Logo & Interactive Layout in Light Mode */}
      <div className="bg-[#2481cc] text-white p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-md">
        <div className="flex items-center space-x-3">
          <div className="p-2 bg-white/10 rounded-full border border-white/15">
            <Cpu className="w-5 h-5 text-white animate-pulse" />
          </div>
          <div>
            <h3 className="text-base font-bold uppercase tracking-wider flex items-center gap-1.5">
              <span>✈️ Telegram Messenger Web Console</span>
            </h3>
            <p className="text-xs text-blue-100 font-medium">Bina Telegram open kiye direct chats, channels, groups aur bots ko load aur control karein.</p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center shrink-0">
          <button
            type="button"
            onClick={() => setShowDiagnostics(!showDiagnostics)}
            className={`px-3 py-1.5 text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all font-bold cursor-pointer ${
              showDiagnostics 
                ? 'bg-amber-500 hover:bg-amber-600 text-white shadow-brand-glow' 
                : 'border border-white/30 text-white hover:bg-white/10 bg-white/5'
            }`}
          >
            <Terminal className="w-3.5 h-3.5" />
            {showDiagnostics ? 'Close Logs ❌' : 'Developer Logs 🛠️'}
          </button>

          <button
            type="button"
            onClick={loadChats}
            disabled={loadingChats}
            className="px-3 border border-white/30 text-white hover:bg-white/10 py-1.5 bg-white/5 text-xs rounded-xl flex items-center justify-center gap-1.5 transition-all font-bold cursor-pointer"
          >
            <RefreshCcw className={`w-3.5 h-3.5 ${loadingChats ? 'animate-spin' : ''}`} />
            Sync All Data
          </button>
        </div>
      </div>

      {/* Classic TG Folders Filter Bar (Horizontal Navigation Layer) */}
      <div className="bg-[#f4f4f7] border-b border-slate-200 px-4 pt-2 flex gap-1.5 overflow-x-auto scrollbar-none scroll-smooth">
        {(['all', 'personal', 'bot', 'group', 'channel'] as FolderType[]).map((folder) => {
          const isActive = currentFolder === folder;
          const count = getFolderCount(folder);
          return (
            <button
              key={folder}
              onClick={() => setCurrentFolder(folder)}
              className={`pb-2.5 pt-2 px-4 text-xs font-bold transition-all relative shrink-0 flex items-center gap-1.5 border-b-2 ${
                isActive 
                  ? 'border-[#2481cc] text-[#2481cc] scale-[1.03]' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <span className="capitalize">{folder === 'all' ? 'All Chats' : folder === 'bot' ? 'Bots 🤖' : folder === 'personal' ? 'Personal' : folder === 'group' ? 'Groups' : 'Channels'}</span>
              <span className={`px-1.5 py-0.5 text-[9px] rounded-full font-extrabold ${
                isActive ? 'bg-blue-100 text-[#2481cc]' : 'bg-slate-200 text-slate-600'
              }`}>
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {showDiagnostics ? (
        <div className="p-5 h-[560px] overflow-y-auto bg-slate-900 border-t border-slate-700 text-slate-100 font-mono text-[11px] flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between border-b border-slate-700 pb-3 mb-4">
              <span className="text-sm font-bold text-amber-400 flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-amber-500" />
                Live MTProto Node & Command Diagnostics
              </span>
              <div className="flex items-center gap-2">
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${
                  diagnosticsData?.connected 
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                    : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                }`}>
                  Status: {diagnosticsData?.connectionStatus || 'DISCONNECTED'} {diagnosticsData?.connected ? '(Connected)' : '(Offline)'}
                </span>
                <button
                  type="button"
                  onClick={() => setShowDiagnostics(false)}
                  className="p-1 hover:bg-slate-800 text-slate-400 hover:text-slate-200 rounded transition cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Config metadata summary */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4 bg-slate-950 p-3.5 rounded-xl border border-slate-800">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider mb-0.5">Supreme Leader ID</span>
                <span className="text-[#2481cc] font-bold text-xs">{diagnosticsData?.supremeLeaderId || 'None'}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider mb-0.5">API Client Keys</span>
                <span className="text-slate-300 font-bold text-xs">
                  ID: {diagnosticsData?.apiId || 'Missing'} | Hash: {diagnosticsData?.apiHash || 'Missing'}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold tracking-wider mb-0.5">Session String</span>
                <span className="text-emerald-400 font-bold text-xs truncate block max-w-[200px]">
                  {diagnosticsData?.sessionString || 'Missing'}
                </span>
              </div>
            </div>

            {/* Realtime Action Logs */}
            <h5 className="text-[10px] text-slate-400 uppercase tracking-widest font-extrabold mb-2 flex items-center gap-1.5">
              <span>📋 Console Event Output Stream:</span>
              {loadingDiag && <span className="w-1.5 h-1.5 bg-amber-400 rounded-full animate-ping"></span>}
            </h5>
            <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 h-[300px] overflow-y-auto font-mono text-[11px] leading-relaxed space-y-1.5 scrollbar-thin">
              {diagnosticsData?.logs && diagnosticsData.logs.length > 0 ? (
                // Render reversed or direct logs
                [...diagnosticsData.logs].reverse().map((log: string, idx: number) => {
                  let logColor = 'text-slate-300';
                  if (log.includes('Incoming Msg') || log.includes('Received Message')) logColor = 'text-sky-300 font-medium';
                  else if (log.includes('Evaluation') || log.includes('Auth')) logColor = 'text-amber-400/90';
                  else if (log.includes('Bound to User') || log.includes('successful')) logColor = 'text-emerald-400 font-bold';
                  else if (log.includes('❌') || log.includes('Failed') || log.includes('Warning')) logColor = 'text-rose-400';
                  else if (log.includes('AI Auto') || log.includes('Responder')) logColor = 'text-purple-300';

                  return (
                    <div key={idx} className={`${logColor} whitespace-pre-wrap border-b border-slate-800/40 pb-1.5`}>
                      {log}
                    </div>
                  );
                })
              ) : (
                <div className="text-slate-500 text-center py-24 italic">
                  Abhi koi diagnostic event registered nahi h. Type any command in Telegram of this userbot account and see logs refresh here live!
                </div>
              )}
            </div>
          </div>
          
          <div className="text-[9.5px] mt-2 text-slate-500 text-right font-semibold">
            Auto-refreshing log stream every 3.5 seconds • Proactive Diagnostics Engine v1.0
          </div>
        </div>
      ) : (
      <div className="grid grid-cols-1 md:grid-cols-12 md:divide-x md:divide-slate-200 h-[560px] overflow-hidden bg-white">
        
        {/* Chats List Sidebar Block */}
        <div className="md:col-span-4 flex flex-col bg-[#fcfdfe] overflow-hidden">
          
          {/* Realtime Search Bar in light mode */}
          <div className="p-3 border-b border-slate-100 flex items-center gap-2 bg-[#f0f2f5]">
            <Search className="w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search chat list or Username..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-transparent text-sm focus:outline-none placeholder-slate-500 text-slate-800 font-medium"
            />
          </div>

          {/* List items component */}
          <div className="flex-1 overflow-y-auto divide-y divide-slate-100/60 scrollbar-thin">
            {loadingChats && chats.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-28 space-y-3">
                <RefreshCcw className="w-7 h-7 animate-spin text-[#2481cc]" />
                <span className="text-xs text-slate-400 font-medium">Bhai, Telegram channels & dialogues load ho rahe hain...</span>
              </div>
            ) : errorChats ? (
              <div className="p-4 text-xs text-rose-500 text-center flex flex-col items-center gap-2 py-24 bg-rose-50/20">
                <ShieldAlert className="w-6 h-6 text-rose-500" />
                <div className="font-bold">{errorChats}</div>
                <div className="text-[10px] text-slate-400 max-w-[200px] mx-auto mt-1">Make sure you are connected to TG!</div>
              </div>
            ) : filteredChats.length === 0 ? (
              <div className="p-6 text-xs text-slate-400 text-center py-24 font-medium">
                Is folder segment me abhi koi chat nahi h.
              </div>
            ) : (
              filteredChats.map((c) => {
                const isSelected = selectedChat?.id === c.id;
                const initials = c.title.trim().substring(0, 2).toUpperCase() || 'TG';
                
                // Color mapping for classic TG looks
                let avatarClass = 'bg-[#4092ff] text-white';
                if (c.type === 'channel') avatarClass = 'bg-[#a352fc] text-white';
                if (c.type === 'group') avatarClass = 'bg-[#1bc47c] text-white';
                if (c.type === 'bot') avatarClass = 'bg-[#e7534f] text-white';

                return (
                  <button
                    type="button"
                    key={c.id}
                    onClick={() => setSelectedChat(c)}
                    className={`w-full text-left p-3.5 flex items-center gap-3.5 transition-all border-b border-slate-100 ${
                      isSelected 
                        ? 'bg-[#2481cc]/10 border-l-4 border-[#2481cc]' 
                        : 'hover:bg-slate-50'
                    }`}
                  >
                    {/* Circle Avatar */}
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm tracking-wider shrink-0 ${avatarClass}`}>
                      {initials}
                    </div>

                    {/* Metadata & Message Preview */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-0.5">
                        <span className="font-bold text-xs text-slate-800 truncate max-w-[130px]">{c.title}</span>
                        {c.unreadCount > 0 && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-[#2481cc] text-white min-w-[20px] text-center shadow-sm">
                            {c.unreadCount}
                          </span>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate font-normal leading-relaxed">
                        {c.message ? c.message : <span className="text-slate-400 italic">Click to load messages</span>}
                      </p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Telegram Classical Wallpaper chat view */}
        <div className="md:col-span-8 flex flex-col overflow-hidden bg-[#eef2f5]">
          {selectedChat ? (
            <>
              {/* Message block header panel */}
              <div className="px-4 py-3 border-b border-slate-200 bg-white flex items-center justify-between shadow-sm z-10">
                <div>
                  <h4 className="font-bold text-sm text-slate-800 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
                    {selectedChat.title}
                  </h4>
                  <p className="text-[10px] text-slate-500 font-medium mt-0.5">
                    Peer ID: <span className="font-mono text-slate-600">{selectedChat.id}</span> • Type: <span className="uppercase text-blue-500 font-semibold">{selectedChat.type}</span>
                    {selectedChat.username && ` • @${selectedChat.username}`}
                  </p>
                </div>
                {loadingMessages && (
                  <span className="text-[10px] text-blue-600 bg-blue-50 px-2 py-1 rounded-lg border border-blue-100 flex items-center gap-1.5 font-bold animate-pulse">
                    <RefreshCcw className="w-3 h-3 animate-spin" />
                    LIVE
                  </span>
                )}
              </div>

              {/* Chat Timeline (Telegram light-blue design) */}
              <div ref={timelineRef} className="flex-1 overflow-y-auto p-4 space-y-3.5 scrollbar-thin bg-[#eef2f5]">
                {loadingMessages && messages.length === 0 ? (
                  <div className="flex-grow flex flex-col items-center justify-center py-20 space-y-3">
                    <RefreshCcw className="w-8 h-8 animate-spin text-[#2481cc]" />
                    <span className="text-xs text-slate-500 font-bold">Telethon database syncing chats...</span>
                  </div>
                ) : errorMessages ? (
                  <div className="flex-grow flex flex-col items-center justify-center p-4 text-xs text-rose-500 gap-1.5 py-20">
                    <ShieldAlert className="w-6 h-6 text-rose-500" />
                    <span className="font-bold">Sync Error: {errorMessages}</span>
                  </div>
                ) : messages.length === 0 ? (
                  <div className="flex-grow flex items-center justify-center text-xs text-slate-400 py-20 font-bold bg-white/50 backdrop-blur-sm rounded-xl max-w-sm mx-auto my-12 p-6 text-center border border-slate-200/50">
                    Is chat ki temporary host state empty h. Type below to send the first message!
                  </div>
                ) : (
                  messages.map((m) => (
                    <div
                      key={m.id}
                      className={`max-w-[80%] rounded-2xl p-3 text-xs leading-relaxed transition-all shadow-sm border ${
                        m.out 
                          ? 'ml-auto bg-[#e2f7cb] text-slate-800 border-[#d3ecc0] rounded-tr-none' 
                          : 'mr-auto bg-white border-slate-200/80 text-slate-800 rounded-tl-none'
                      }`}
                    >
                      {/* Name badge */}
                      {!m.out && (
                        <div className="font-bold text-[10px] text-blue-600 mb-1 select-none">
                          {m.senderName || 'Sender'}
                        </div>
                      )}
                      
                      {/* Message string content */}
                      <p className="whitespace-pre-wrap text-slate-800 font-normal selection:bg-blue-200">{m.message}</p>
                      
                      {/* Media support annotation */}
                      {m.media && (
                        <span className="inline-block mt-1 px-2 py-0.5 text-[8.5px] font-bold tracking-wider uppercase bg-[#2481cc]/15 text-blue-700 rounded-md select-none">
                          📂 Media / File Received
                        </span>
                      )}

                      {/* Display readable time stamp */}
                      <div className="text-[9px] text-slate-400 text-right mt-1.5 font-bold">
                        {new Date(m.date * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  ))
                )}
                <div ref={messagesEndRef} />
              </div>

              {/* Message Typing Form */}
              <form onSubmit={handleSendMessage} className="p-3 bg-white border-t border-slate-200 flex items-center gap-2 z-10 shadow-sm">
                <input
                  type="text"
                  placeholder={`Send secure telegram message to ${selectedChat.title}...`}
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-1 focus:ring-[#2481cc] text-slate-800 placeholder-slate-400 font-medium"
                  disabled={sending}
                />
                <button
                  type="submit"
                  disabled={sending || !newMessage.trim()}
                  className="p-3 bg-[#2481cc] hover:bg-[#1c71b4] disabled:bg-slate-100 disabled:text-slate-400 text-white rounded-xl transition-all shadow-md active:scale-95 shrink-0 flex items-center justify-center"
                >
                  <Send className={`w-3.5 h-3.5 ${sending ? 'animate-pulse' : ''}`} />
                </button>
              </form>
            </>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-6 text-center text-slate-500 space-y-4">
              <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center shadow-md border border-slate-100 animate-bounce">
                <MessageSquare className="w-7 h-7 text-[#2481cc]" />
              </div>
              <div>
                <p className="text-sm font-bold text-slate-800">No Chat Selected</p>
                <p className="text-xs text-slate-400 max-w-[280px] mx-auto mt-1.5 leading-relaxed font-semibold">
                  Bhai, click on any chat in the list or use the tabs ("All", "Personal", "Bots" etc) to fetch messages and start live chat synchronization loop!
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
      )}
    </div>
  );
}
