import React, { useState, useEffect, useRef } from 'react';
import { 
  Terminal, ShieldCheck, Play, Radio, Send, Users, Cpu, Eye, Layers, 
  AlertCircle, CpuIcon, Database, RefreshCw, Key, Shield, Network, 
  Fingerprint, Activity, Clock, Globe, ArrowRight, Zap, Minimize2 
} from 'lucide-react';

interface TelegramMessagePacket {
  id: number;
  msgIdStr: string;
  sender: string;
  senderId: number;
  chatTitle: string;
  chatId: number;
  dc: number; // 1 to 5
  dcName: string;
  text: string;
  timestamp: string;
  sizeBytes: number;
  gzipRatio: string;
  authLayer: string;
  securityRating: 'SECURED' | 'HIGH_CONFIDENCE' | 'PRIVACY_SHIELD' | 'ALERT';
  trustScore: number; // 0 to 100%
  pingMs: number;
  routingPath: string;
  isInspected: boolean;
}

export function TelegramCliInspector() {
  const [inspectedMessageId, setInspectedMessageId] = useState<number | null>(1);
  const [terminalInput, setTerminalInput] = useState('');
  const [cliActive, setCliActive] = useState(true);
  const [liveStreamActive, setLiveStreamActive] = useState(true);
  const [telemetryPing, setTelemetryPing] = useState(24);
  const [packetsAnalyzed, setPacketsAnalyzed] = useState(14820);
  
  const [terminalLogs, setTerminalLogs] = useState<string[]>([
    '⚙️ INITIALIZING MTPROTO TELEMETRY BRIDGE...',
    '🛰️ CONNECTED: HOST PORT 3000 -> TG-API DECK GATEWAY',
    '🔑 SECURITY PROTOCOL: SHA-256 SENDER AUTHENTIFICATION SET',
    '📡 LISTENING LIVE TELEGRY-STREAM ON ALL REGISTERED HUBS...',
    '💡 CLICK ANY INCOMING PACKET BELOW TO UNLOCK 3D METADATA INSPECTOR VIEW.'
  ]);

  const [packets, setPackets] = useState<TelegramMessagePacket[]>([
    {
      id: 1,
      msgIdStr: '19746352410842',
      sender: 'Karan_OP_99',
      senderId: 648392019,
      chatTitle: 'DDC BGMI Clan Official Chat',
      chatId: -100149302919,
      dc: 5,
      dcName: 'DC-5 Singapore (APAC Standard Gateway)',
      text: 'Bhai match kab shuru hoga? Ek bar dynamic schedule check kar lo!',
      timestamp: new Date().toLocaleTimeString(),
      sizeBytes: 248,
      gzipRatio: '38.4%',
      authLayer: 'Layer 158 AES-256',
      securityRating: 'HIGH_CONFIDENCE',
      trustScore: 98,
      pingMs: 18,
      routingPath: 'IND-MUM-EDGE -> SG5-CORE -> TG-API-DB',
      isInspected: true
    },
    {
      id: 2,
      msgIdStr: '19746352419021',
      sender: 'TG_Agent_Specter',
      senderId: 772910384,
      chatTitle: 'Secret Admin HQ',
      chatId: -1001859302194,
      dc: 4,
      dcName: 'DC-4 Amsterdam (Euro-Direct Backbone)',
      text: 'Deploying updated stealth automated commands bypass layer.',
      timestamp: new Date(Date.now() - 3000).toLocaleTimeString(),
      sizeBytes: 512,
      gzipRatio: '46.1%',
      authLayer: 'Layer 158 RSA-2048 E2EE',
      securityRating: 'PRIVACY_SHIELD',
      trustScore: 100,
      pingMs: 42,
      routingPath: 'GER-FRA-EDGE -> AMS4-CORE -> HYDRATOR-V2',
      isInspected: false
    },
    {
      id: 3,
      msgIdStr: '19746352422055',
      sender: 'NoobPro_99',
      senderId: 588201948,
      chatTitle: 'Tadakeda Sandbox Dev Lobby',
      chatId: -100192837492,
      dc: 1,
      dcName: 'DC-1 Miami (Americas Edge Hub)',
      text: 'Aura bypass protocol synced. Can we run automated webhook tests now?',
      timestamp: new Date(Date.now() - 8000).toLocaleTimeString(),
      sizeBytes: 310,
      gzipRatio: '32.1%',
      authLayer: 'Layer 158 AES-IGGE-128',
      securityRating: 'SECURED',
      trustScore: 85,
      pingMs: 144,
      routingPath: 'USA-NYC-EDGE -> MIA1-CORE -> TARGET-TUNNEL',
      isInspected: false
    },
    {
      id: 4,
      msgIdStr: '19746352423910',
      sender: 'Salty_SpamBot_Detector',
      senderId: 902831448,
      chatTitle: 'Unknown Global Hub',
      chatId: -100111222333,
      dc: 2,
      dcName: 'DC-2 London (UK Access Multiplexer)',
      text: '🤖 system alert: unknown telemetry sync detected [SUSPICIOUS FLAGS]',
      timestamp: new Date(Date.now() - 15000).toLocaleTimeString(),
      sizeBytes: 1200,
      gzipRatio: '58.2%',
      authLayer: 'Un-Encrypted Plaintext Tunnel',
      securityRating: 'ALERT',
      trustScore: 32,
      pingMs: 98,
      routingPath: 'UNKNOWN-NODE -> LDN2-CORE -> ALERT-BUFFER',
      isInspected: false
    }
  ]);

  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Simulated live signal drift and automatic message stream
  useEffect(() => {
    if (!liveStreamActive) return;

    const interval = setInterval(() => {
      // Periodic ping updates
      setTelemetryPing(prev => Math.max(12, Math.min(180, prev + (Math.random() - 0.5) * 8)));
      setPacketsAnalyzed(prev => prev + 1);

      // 15% chance of rolling in an absolutely fresh, live inspected message
      if (Math.random() < 0.25) {
        const firstNames = ['Aditya', 'Rohan', 'Sneha', 'Tadakeda_Master', 'Phantom_TG', 'Hacker_X', 'Kabir', 'Aman_OP', 'Bot_V5'];
        const contentSamples = [
          'Ping test reply. Status payload is fully encrypted.',
          'Naya bot updates loaded live! Performance looking extreme.',
          'Database check completed. Syncing 512 secret channels.',
          'TG Anti-Cheat Bypass: OK! Telemetry reports zero warning logs.',
          'Bhai background server perfect chal raha hai, speed benchmark tested.',
          'API Command Trigger executed from remote console terminal'
        ];
        const randomName = firstNames[Math.floor(Math.random() * firstNames.length)];
        const randomContent = contentSamples[Math.floor(Math.random() * contentSamples.length)];
        const randomId = Date.now();
        const dcs = [1, 2, 4, 5];
        const dcNames = [
          'DC-1 Miami (Americas Edge Hub)',
          'DC-2 London (UK Access Multiplexer)',
          'DC-4 Amsterdam (Euro-Direct Backbone)',
          'DC-5 Singapore (APAC Standard Gateway)'
        ];
        const dcIdx = Math.floor(Math.random() * dcs.length);
        const ratings: ('SECURED' | 'HIGH_CONFIDENCE' | 'PRIVACY_SHIELD' | 'ALERT')[] = ['SECURED', 'HIGH_CONFIDENCE', 'PRIVACY_SHIELD'];
        const randomRating = ratings[Math.floor(Math.random() * ratings.length)];

        const newPacket: TelegramMessagePacket = {
          id: randomId,
          msgIdStr: (BigInt(19746352000000) + BigInt(Math.floor(Math.random() * 500000))).toString(),
          sender: randomName,
          senderId: Math.floor(100000000 + Math.random() * 800000000),
          chatTitle: 'Tadakeda Ultra-Secure Tunnel',
          chatId: -1001555666777,
          dc: dcs[dcIdx],
          dcName: dcNames[dcIdx],
          text: randomContent,
          timestamp: new Date().toLocaleTimeString(),
          sizeBytes: Math.floor(120 + Math.random() * 800),
          gzipRatio: `${(25 + Math.random() * 30).toFixed(1)}%`,
          authLayer: `Layer 158 AES-ECDH-${Math.random() > 0.5 ? '256' : '128'}`,
          securityRating: randomRating,
          trustScore: Math.floor(75 + Math.random() * 25),
          pingMs: Math.floor(15 + Math.random() * 110),
          routingPath: `IND-MUM-EDGE -> DC${dcs[dcIdx]}-CORE -> TADAKEDA-BYPASS`,
          isInspected: false
        };

        setPackets(prev => [newPacket, ...prev.slice(0, 5)]);
        setTerminalLogs(prev => [
          ...prev,
          `📥 [NEW PACKET] Message incoming from ${randomName} | Size: ${newPacket.sizeBytes}B | Security: ${randomRating}`
        ]);
      }
    }, 4500);

    return () => clearInterval(interval);
  }, [liveStreamActive]);

  // Terminal scroll handler
  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [terminalLogs]);

  const currentlyInspected = packets.find(p => p.id === inspectedMessageId) || packets[0];

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = terminalInput.trim();
    if (!cmd) return;

    setTerminalLogs(prev => [...prev, `> ${cmd}`]);
    const normalized = cmd.toLowerCase();

    if (normalized === 'help') {
      setTerminalLogs(prev => [
        ...prev,
        '🛠️ UNLIMITED TELEGRAM CLI DIAGNOSTICS DECK:',
        '  - help                  : View active command references.',
        '  - clear                 : Clear memory terminal stdout logs.',
        '  - inspect-raw           : Print full JSON stream of current packet.',
        '  - trace-route           : Visualize DC routing nodes dynamic payload.',
        '  - bypass-audit          : Enforce automated anti-spam rating checks.',
        '  - status                : Query current system transport variables.'
      ]);
    } else if (normalized === 'clear') {
      setTerminalLogs([]);
    } else if (normalized.startsWith('inspect-raw')) {
      if (currentlyInspected) {
        setTerminalLogs(prev => [
          ...prev,
          `📄 RAW INTERPRETED JSON PACKET FOR MSG [${currentlyInspected.msgIdStr}]:`,
          JSON.stringify(currentlyInspected, null, 2)
        ]);
      } else {
        setTerminalLogs(prev => [...prev, '❌ ERROR: No active inspected message loaded.']);
      }
    } else if (normalized === 'trace-route') {
      if (currentlyInspected) {
        setTerminalLogs(prev => [
          ...prev,
          `🛰️ TELEGRAM PACKET TRACE:`,
          `  ORIGIN: Cloud-Edge (Mumbai Gateway)`,
          `  ROUTE: ${currentlyInspected.routingPath}`,
          `  MTPROTO TRANSPORT: TCP-Obfuscated-Secure`,
          `  DECRYPTED STATUS: Successfully decrypted in ${(currentlyInspected.pingMs / 2).toFixed(0)}ms`
        ]);
      }
    } else if (normalized === 'bypass-audit') {
      setTerminalLogs(prev => [
        ...prev,
        `🔒 BYPASS AUDIT DIAGNOSTICS: RUNNING...`,
        `👉 DC Connection: STABLE`,
        `👉 Anti-Spam Mitigation Rules: BYPASSED`,
        `👉 Message Delay: 0.1ms (Direct UDP Injection)`
      ]);
    } else if (normalized === 'status') {
      setTerminalLogs(prev => [
        ...prev,
        `⚡ HEALTH: EXTREME | PING: ${telemetryPing.toFixed(1)}ms`,
        `⚡ API BRIDGE: Webhook operational on container Port 3000`
      ]);
    } else {
      setTerminalLogs(prev => [...prev, `❓ Command unrecognized: "${cmd}". Type "help" for dynamic CLI options.`]);
    }

    setTerminalInput('');
  };

  return (
    <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-6 shadow-2xl space-y-6">
      
      {/* Dynamic 3D Header design with Glow effect */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-neutral-800 pb-5 gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="p-3 bg-teal-500/10 border border-teal-500/30 rounded-2xl text-teal-400 drop-shadow-[0_0_10px_rgba(20,184,166,0.3)]">
              <Network className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="font-extrabold text-white text-lg tracking-wide flex items-center gap-2">
                Telegram CLI Server <span className="text-[10px] bg-teal-400/10 text-teal-400 border border-teal-400/20 px-2 py-0.5 rounded font-mono font-bold tracking-widest uppercase">Stealth Deck v4.0</span>
              </h3>
              <p className="text-xs text-neutral-400 font-mono mt-0.5">Exposing Real-time Hidden Metadata, Encryption Salts & IP Pathways</p>
            </div>
          </div>
        </div>

        {/* Live system parameters */}
        <div className="flex flex-wrap items-center gap-3 font-mono text-[11px]">
          <span 
            onClick={() => setLiveStreamActive(!liveStreamActive)}
            className={`px-3 py-1.5 rounded-xl border flex items-center gap-1.5 cursor-pointer select-none transition-all ${
              liveStreamActive 
                ? 'bg-teal-500/10 border-teal-500/30 text-teal-400 drop-shadow-[0_0_8px_rgba(20,184,166,0.2)]'
                : 'bg-neutral-950/40 border-neutral-800 text-neutral-500'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${liveStreamActive ? 'bg-teal-400 animate-ping' : 'bg-neutral-600'}`}></span>
            {liveStreamActive ? 'LIVE CONSOLE' : 'STREAM STALLED'}
          </span>
          <span className="bg-neutral-950 border border-neutral-800/80 px-2.5 py-1.5 rounded-xl text-neutral-400 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-indigo-400" />
            PING: <strong className="text-teal-400">{telemetryPing.toFixed(0)} ms</strong>
          </span>
          <span className="bg-neutral-950 border border-neutral-800/80 px-2.5 py-1.5 rounded-xl text-neutral-400 hidden sm:flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-amber-500 animate-spin" style={{ animationDuration: '10s' }} />
            SESSION ACTIVE
          </span>
        </div>
      </div>

      {/* Main interactive 3D perspective dashboard layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        
        {/* Left Hand: Stream layout with pseudo 3D depth cards (5 Cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex justify-between items-center px-1">
            <span className="text-xs font-bold text-neutral-400 font-mono tracking-wider flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-teal-400" />
              INCOMING PACKET STREAM
            </span>
            <span className="text-[10px] font-mono text-neutral-500 bg-neutral-950 border border-neutral-850 px-2 py-0.5 rounded">
              TOTAL: {packetsAnalyzed.toLocaleString()}
            </span>
          </div>

          <div className="space-y-3 max-h-[460px] overflow-y-auto pr-1 scrollbar-thin">
            {packets.map((p) => {
              const isSelected = p.id === inspectedMessageId;
              let badgeColor = 'bg-teal-500/10 border-teal-500/30 text-teal-400';
              if (p.securityRating === 'PRIVACY_SHIELD') badgeColor = 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400';
              else if (p.securityRating === 'ALERT') badgeColor = 'bg-rose-500/10 border-rose-500/30 text-rose-400 animate-pulse';

              return (
                <div
                  key={p.id}
                  onClick={() => {
                    setInspectedMessageId(p.id);
                    setTerminalLogs(prev => [...prev, `🔍 EXPOSING: Unveiled secure metadata for message ID [${p.msgIdStr}] sent by {${p.sender}}`]);
                  }}
                  className={`relative p-4 rounded-2xl border transition-all duration-300 cursor-pointer text-left select-none overflow-hidden group ${
                    isSelected 
                      ? 'bg-gradient-to-r from-neutral-900 to-[#112224] border-teal-500/60 shadow-[0_4px_25px_rgba(20,184,166,0.15)] scale-[1.02] -translate-x-1' 
                      : 'bg-neutral-900/60 hover:bg-neutral-900 border-neutral-800 hover:border-neutral-700 hover:shadow-lg'
                  }`}
                  style={{
                    perspective: '1000px'
                  }}
                >
                  {/* Subtle 3D Depth back reflection */}
                  <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-teal-500/5 to-transparent rounded-bl-full pointer-events-none group-hover:opacity-100 opacity-60"></div>

                  <div className="flex justify-between items-start mb-2">
                    <div className="flex items-center gap-1.5">
                      <Fingerprint className={`w-3.5 h-3.5 ${isSelected ? 'text-teal-400 animate-pulse' : 'text-neutral-500'}`} />
                      <span className="font-mono text-[10px] text-neutral-400 font-bold">{p.sender}</span>
                    </div>
                    <span className="font-mono text-[9px] text-neutral-500">{p.timestamp}</span>
                  </div>

                  <p className="text-xs text-neutral-200 line-clamp-1 group-hover:text-white font-mono transition-colors">
                    "{p.text}"
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-2 mt-3.5 pt-2.5 border-t border-neutral-800/80 font-mono text-[9px]">
                    <span className={`px-1.5 py-0.5 rounded border uppercase text-[8px] font-bold ${badgeColor}`}>
                      {p.securityRating}
                    </span>
                    <span className="text-neutral-500 flex items-center gap-1">
                      DC: <strong className="text-neutral-300 font-bold">{p.dc}</strong>
                    </span>
                    <span className="text-neutral-500">
                      SIZE: <strong className="text-neutral-300 font-bold">{p.sizeBytes} B</strong>
                    </span>
                  </div>

                  {/* Dynamic 3D indicators at the side */}
                  {isSelected && (
                    <div className="absolute right-0 top-0 bottom-0 w-1 bg-teal-400 glow-effect rounded-r-2xl"></div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Hand: Deep Metadata Inspector (Isometric 3D Card HUD layout) (7 Cols) */}
        <div className="lg:col-span-7 flex flex-col justify-between space-y-5">
          
          {/* Main 3D Inspector Screen Box */}
          <div className="bg-neutral-950 border border-neutral-850 rounded-2xl p-5 relative overflow-hidden flex-grow flex flex-col justify-between shadow-2xl min-h-[360px]">
            
            {/* Top scanning bar effect */}
            <div className="absolute top-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-teal-400 to-transparent animate-pulse pointer-events-none opacity-40"></div>
            
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-neutral-900 pb-3">
                <span className="text-xs font-bold text-white tracking-widest uppercase font-mono flex items-center gap-2">
                  <Fingerprint className="w-4 h-4 text-teal-400" />
                  3D TELEMETRY DECODER VIEWPORT
                </span>
                <span className="text-[9px] bg-teal-500/10 border border-teal-500/20 text-teal-400 px-2 py-0.5 rounded font-mono font-bold uppercase animate-pulse">
                  ESTABLISHED
                </span>
              </div>

              {/* Isometric representation / UI element styling - Look like real 3D layered components */}
              <div className="relative group transition-transform duration-700 hover:scale-[1.01] bg-[#0c141c]/40 border border-teal-500/10 p-5 rounded-2xl">
                
                {/* Visual perspective layer outline stack */}
                <div className="absolute inset-0 bg-gradient-to-br from-teal-500/5 via-transparent to-transparent pointer-events-none"></div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Left Layer: User identification block */}
                  <div className="space-y-3 font-mono text-[11px] border-r border-neutral-900 pr-2">
                    <div>
                      <span className="text-neutral-500 block text-[9px] uppercase">ORIGINAL SENDER HANDLE</span>
                      <strong className="text-white text-sm">@{currentlyInspected.sender}</strong>
                    </div>

                    <div>
                      <span className="text-neutral-500 block text-[9px] uppercase">SENDER INTEGER ID</span>
                      <span className="text-teal-400 font-extrabold">{currentlyInspected.senderId}</span>
                    </div>

                    <div>
                      <span className="text-neutral-500 block text-[9px] uppercase">CHAT PEER SOURCE</span>
                      <span className="text-neutral-300 block text-[10px] truncate">{currentlyInspected.chatTitle}</span>
                      <span className="text-neutral-500 text-[9px]">{currentlyInspected.chatId}</span>
                    </div>

                    <div>
                      <span className="text-neutral-500 block text-[9px] uppercase">AUTHORIZED PROTOCOL</span>
                      <strong className="text-indigo-400 flex items-center gap-1 text-[10px]">
                        <Shield className="w-3.5 h-3.5 text-indigo-400" />
                        {currentlyInspected.authLayer}
                      </strong>
                    </div>
                  </div>

                  {/* Right Layer: Deep structural package bytes details */}
                  <div className="space-y-3 font-mono text-[11px] flex flex-col justify-between">
                    <div>
                      <span className="text-neutral-500 block text-[9px] uppercase">ROUTING HIGH-GRADE PATHWAY</span>
                      <span className="text-neutral-300 text-[10px] break-all">{currentlyInspected.routingPath}</span>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <span className="text-neutral-500 block text-[9px] uppercase">GZIP RATIO</span>
                        <strong className="text-emerald-400">{currentlyInspected.gzipRatio}</strong>
                      </div>
                      <div>
                        <span className="text-neutral-500 block text-[9px] uppercase">RESPONSE</span>
                        <strong className="text-rose-400">{currentlyInspected.pingMs} ms</strong>
                      </div>
                    </div>

                    <div>
                      <span className="text-neutral-500 block text-[9px] uppercase">SECURED MTPROTO DATACENTER</span>
                      <span className="text-teal-400 text-[10px] font-bold flex items-center gap-1">
                        <Globe className="w-3.5 h-3.5" />
                        {currentlyInspected.dcName}
                      </span>
                    </div>

                    {/* Performance trust metric meter */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-[9px]">
                        <span className="text-neutral-500">ANTI-SPAM TRUST RATING:</span>
                        <strong className="text-teal-400">{currentlyInspected.trustScore}%</strong>
                      </div>
                      <div className="w-full h-1.5 bg-neutral-900 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-teal-400" 
                          style={{ width: `${currentlyInspected.trustScore}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Sub message preview box inside deep inspector representing 3D holographic text */}
                <div className="mt-4 p-3 bg-neutral-950 border border-neutral-900 rounded-xl relative overflow-hidden">
                  <div className="absolute right-3 top-3 text-[10px] text-neutral-600 font-mono">
                    PLAIN-TXT PAYLOAD
                  </div>
                  <p className="text-[11px] font-mono text-neutral-300 leading-relaxed italic pr-12">
                    "{currentlyInspected.text}"
                  </p>
                </div>

              </div>
            </div>

            {/* Simulated 3D nodes visualization block underneath inspector */}
            <div className="border-t border-neutral-900 pt-4 mt-4">
              <span className="text-[10px] font-bold text-neutral-400 font-mono block uppercase mb-2.5 tracking-wider">
                📡 CORE SENDER NODE NETWORK TELEMETRY ROUTER:
              </span>
              
              {/* Custom styled CSS interactive coordinate nodes map representing real connections */}
              <div className="h-20 bg-neutral-950/60 border border-neutral-900 rounded-2xl flex items-center justify-between px-6 relative overflow-hidden">
                
                {/* Horizontal data wave signal line */}
                <div className="absolute left-10 right-10 top-1/2 -translate-y-1/2 h-[1px] bg-dashed border-t border-teal-500/25 z-0 pointer-events-none"></div>
                
                {/* Current node animations */}
                <div className="flex flex-col items-center z-10 relative">
                  <div className="w-7 h-7 rounded-full bg-indigo-500/10 border border-indigo-400/50 flex items-center justify-center text-[10px] text-indigo-400 animate-pulse">
                    🇮🇳
                  </div>
                  <span className="text-[8px] font-mono text-neutral-400 mt-1">MUMBAI</span>
                </div>

                <div className="flex items-center gap-1 z-10 text-neutral-700 animate-pulse">
                  <ArrowRight className="w-4 h-4 text-teal-400" />
                </div>

                <div className="flex flex-col items-center z-10 relative">
                  <div className="w-7 h-7 rounded-full bg-teal-500/10 border border-teal-400/80 flex items-center justify-center text-[10px] text-teal-400 font-extrabold shadow-[0_0_12px_rgba(20,184,166,0.5)]">
                    DC
                  </div>
                  <span className="text-[8px] font-mono text-teal-400 mt-1 uppercase font-bold">DC {currentlyInspected.dc} Hub</span>
                </div>

                <div className="flex items-center gap-1 z-10 text-neutral-700 animate-pulse">
                  <ArrowRight className="w-4 h-4 text-teal-400" />
                </div>

                <div className="flex flex-col items-center z-10">
                  <div className="w-7 h-7 rounded-full bg-neutral-900 border border-neutral-800 flex items-center justify-center text-[10px] text-neutral-300">
                    💻
                  </div>
                  <span className="text-[8px] font-mono text-neutral-400 mt-1">CONTAINER</span>
                </div>

              </div>
            </div>

          </div>

          {/* Fully Interactive CLI terminal panel to execute custom parameters */}
          <div className="bg-black border border-neutral-900 rounded-2xl p-4 flex flex-col font-mono text-xs text-teal-400">
            <div className="flex justify-between items-center pb-2 border-b border-neutral-900 mb-2">
              <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest flex items-center gap-1">
                <Terminal className="w-3.5 h-3.5" />
                SYSTEM LIVE BRIDGE STDOUT
              </span>
              <button 
                type="button" 
                onClick={() => setTerminalLogs([])}
                className="text-[9px] text-neutral-500 hover:text-white transition-colors cursor-pointer"
              >
                [CLEAR BUFFER]
              </button>
            </div>

            {/* Logs box */}
            <div className="h-32 overflow-y-auto space-y-1 scrollbar-thin select-text text-[11px] mb-2 pr-1">
              {terminalLogs.map((log, idx) => (
                <div key={idx} className="whitespace-pre-wrap leading-relaxed">
                  {log}
                </div>
              ))}
              <div ref={terminalEndRef}></div>
            </div>

            {/* Submit commands form */}
            <form onSubmit={handleCommandSubmit} className="flex gap-2">
              <span className="text-teal-400 animate-pulse font-extrabold">&gt;_</span>
              <input
                type="text"
                value={terminalInput}
                onChange={(e) => setTerminalInput(e.target.value)}
                placeholder="Type 'help' to unlock secure telemetry commands..."
                className="bg-transparent text-white placeholder-neutral-800 focus:outline-none w-full text-[11px] font-mono"
              />
              <button 
                type="submit"
                className="bg-teal-500/10 hover:bg-teal-500/20 text-teal-400 border border-teal-500/30 rounded px-3 py-1 text-[10px] font-bold cursor-pointer uppercase transition-all"
              >
                EXEC
              </button>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
}
