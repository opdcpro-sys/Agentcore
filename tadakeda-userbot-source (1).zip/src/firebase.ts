import { initializeApp } from 'firebase/app';
import { getFirestore, doc, getDoc, setDoc, collection, getDocs, deleteDoc } from 'firebase/firestore';
import fs from 'fs';
import path from 'path';

let firebaseApp: any = null;
let db: any = null;

// Read config file synchronously
try {
  const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
  if (fs.existsSync(configPath)) {
    const configRaw = fs.readFileSync(configPath, 'utf-8');
    const config = JSON.parse(configRaw);
    
    firebaseApp = initializeApp({
      apiKey: config.apiKey,
      authDomain: config.authDomain,
      projectId: config.projectId,
      storageBucket: config.storageBucket,
      messagingSenderId: config.messagingSenderId,
      appId: config.appId
    });

    // Handle custom Firestore database ID
    const databaseId = config.firestoreDatabaseId || '(default)';
    db = getFirestore(firebaseApp, databaseId);
    
    console.log(`[Firebase] Initialized Firestore client with project: ${config.projectId} and database ID: ${databaseId}`);
  } else {
    console.error('[Firebase] Config file firebase-applet-config.json not found!');
  }
} catch (e) {
  console.error('[Firebase] Initialization error:', e);
}

export interface BotData {
  apiId: string;
  apiHash: string;
  phone: string;
  sessionString: string;
  supremeLeaderId: string;
  agents: Record<string, string>; // userId -> role (S, A, B)
  autoDetect?: boolean;
  backupChatId?: string;
}

/**
 * Loads Bot Config from Firestore database or returns null if not found
 */
export async function loadBotDataFromDb(): Promise<BotData | null> {
  if (!db) return null;
  try {
    const docRef = doc(db, 'settings', 'bot_config');
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      return docSnap.data() as BotData;
    }
  } catch (e) {
    console.error('[Firebase] Failed to load bot config:', e);
  }
  return null;
}

/**
 * Saves Bot Config to Firestore database
 */
export async function saveBotDataToDb(data: BotData): Promise<void> {
  if (!db) return;
  try {
    const docRef = doc(db, 'settings', 'bot_config');
    // Ensure nested fields are clean for Firebase
    const cleanData = {
      apiId: data.apiId || '',
      apiHash: data.apiHash || '',
      phone: data.phone || '',
      sessionString: data.sessionString || '',
      supremeLeaderId: data.supremeLeaderId || '',
      agents: data.agents || {},
      autoDetect: !!data.autoDetect,
      backupChatId: data.backupChatId || ''
    };
    await setDoc(docRef, cleanData);
    console.log('[Firebase] Bot config updated in cloud database');
  } catch (e) {
    console.error('[Firebase] Failed to save bot config:', e);
  }
}

/**
 * Loads recent Chat History maps from Firestore database
 */
export async function loadChatHistoryFromDb(): Promise<Map<string, Array<{role: 'user'|'assistant', content: string}>>> {
  const historyMap = new Map<string, Array<{role: 'user'|'assistant', content: string}>>();
  if (!db) return historyMap;
  try {
    const colRef = collection(db, 'chat_history');
    const querySnap = await getDocs(colRef);
    querySnap.forEach((docSnap: any) => {
      const data = docSnap.data();
      if (data.chatId && Array.isArray(data.history)) {
        historyMap.set(data.chatId, data.history);
      }
    });
    console.log(`[Firebase] Loaded ${historyMap.size} chat histories from cloud database`);
  } catch (e) {
    console.error('[Firebase] Failed to load chat history:', e);
  }
  return historyMap;
}

/**
 * Saves specific Chat History to Firestore database
 */
export async function saveChatHistoryToDb(chatId: string, history: Array<{role: 'user'|'assistant', content: string}>): Promise<void> {
  if (!db) return;
  try {
    const docRef = doc(db, 'chat_history', chatId);
    await setDoc(docRef, {
      chatId,
      history,
      updatedAt: new Date()
    });
  } catch (e) {
    console.error(`[Firebase] Failed to save chat history for chat ${chatId}:`, e);
  }
}
