import fs from 'fs';
fetch('http://localhost:3000/api/command', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ command: '!ping', target: 'me' })
}).then(r => r.json()).then(console.log);
