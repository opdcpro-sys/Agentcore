import { useState, useEffect, useRef } from "react";

const BASE = import.meta.env.BASE_URL.replace(/\/$/, "");
const API = `${BASE}/api/bot`;

interface BotStatus {
  connected: boolean;
  me?: { id: string; username?: string; firstName?: string; phone?: string };
  uptimeSeconds: number;
  cpuPercent: number;
  memPercent: number;
  diskPercent: number;
  startTime: number;
}

interface SysInfo {
  cpuPercent: number;
  memUsedGB: string;
  memTotalGB: string;
  memPercent: number;
  diskUsedGB: string;
  diskTotalGB: string;
  diskPercent: number;
  uptimeSeconds: number;
  nodeVersion: string;
  platform: string;
}

interface Chat {
  id: string;
  title: string;
  type: string;
  unreadCount: number;
  lastMessage?: string;
  lastMessageDate?: number;
}

interface Message {
  id: number;
  text: string;
  date: number;
  fromId?: string;
  mediaType?: string;
}

function fmtUptime(s: number) {
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  return `${h}h ${m}m ${sec}s`;
}

function fmtDate(ts: number) {
  return new Date(ts * 1000).toLocaleString();
}

function GaugeBar({ value, color }: { value: number; color: string }) {
  return (
    <div className="gauge-wrap">
      <div className="gauge-bar">
        <div className="gauge-fill" style={{ width: `${value}%`, background: color }} />
      </div>
      <span className="gauge-label">{value}%</span>
    </div>
  );
}

export default function App() {
  const [status, setStatus] = useState<BotStatus | null>(null);
  const [sysinfo, setSysinfo] = useState<SysInfo | null>(null);
  const [chats, setChats] = useState<Chat[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [sendText, setSendText] = useState("");
  const [sending, setSending] = useState(false);
  const [activeTab, setActiveTab] = useState<"dashboard" | "chats" | "terminal">("dashboard");
  const [termOutput, setTermOutput] = useState<string[]>([
    "Tadakedar Dashboard v2.0 — Real VPS metrics, no simulation.",
    'Type a Telegram message command or browse chats in the Chats tab.',
  ]);
  const termRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const load = async () => {
      const [s, si] = await Promise.all([
        fetch(`${API}/status`).then(r => r.ok ? r.json() : null).catch(() => null),
        fetch(`${API}/sysinfo`).then(r => r.ok ? r.json() : null).catch(() => null),
      ]);
      setStatus(s);
      setSysinfo(si);
    };
    load();
    const t = setInterval(load, 8000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (activeTab === "chats") {
      fetch(`${API}/chats`).then(r => r.ok ? r.json() : []).then(setChats).catch(() => {});
    }
  }, [activeTab]);

  useEffect(() => {
    if (!selectedChat) return;
    const load = () => {
      fetch(`${API}/chats/${selectedChat.id}/messages`).then(r => r.ok ? r.json() : []).then(setMessages).catch(() => {});
    };
    load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, [selectedChat]);

  useEffect(() => {
    if (termRef.current) termRef.current.scrollTop = termRef.current.scrollHeight;
  }, [termOutput]);

  const handleSend = async () => {
    if (!selectedChat || !sendText.trim() || sending) return;
    setSending(true);
    try {
      await fetch(`${API}/chats/${selectedChat.id}/send`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: sendText }),
      });
      setSendText("");
    } catch (_) {}
    setSending(false);
  };

  const user = status?.me;
  const connected = status?.connected ?? false;

  return (
    <div className="app">
      <header className="header">
        <div className="header-logo">
          <span className="logo-icon">⚡</span>
          <span className="logo-text">TADAKEDAR</span>
          <span className="logo-sub">BOT DASHBOARD</span>
        </div>
        <div className="header-status">
          <span className={`status-dot ${connected ? "online" : "offline"}`} />
          <span>{connected ? "CONNECTED" : "OFFLINE"}</span>
          {user && <span className="user-badge">@{user.username ?? user.id}</span>}
        </div>
        <nav className="header-nav">
          {(["dashboard", "chats", "terminal"] as const).map(tab => (
            <button key={tab} className={`nav-btn ${activeTab === tab ? "active" : ""}`} onClick={() => setActiveTab(tab)}>
              {tab === "dashboard" ? "📊 Dashboard" : tab === "chats" ? "💬 Chats" : "🖥️ System"}
            </button>
          ))}
        </nav>
      </header>

      <main className="main">
        {activeTab === "dashboard" && (
          <div className="dashboard-grid">
            <div className="card card-wide">
              <div className="card-title">🤖 Bot Status</div>
              <div className="stat-row">
                <div className="stat">
                  <div className="stat-val" style={{ color: connected ? "#00ffb2" : "#ff2f76" }}>
                    {connected ? "● ONLINE" : "● OFFLINE"}
                  </div>
                  <div className="stat-sub">Connection</div>
                </div>
                <div className="stat">
                  <div className="stat-val">{user?.firstName ?? user?.username ?? "—"}</div>
                  <div className="stat-sub">Account Name</div>
                </div>
                <div className="stat">
                  <div className="stat-val">{user?.phone ?? "—"}</div>
                  <div className="stat-sub">Phone</div>
                </div>
                <div className="stat">
                  <div className="stat-val">{status ? fmtUptime(status.uptimeSeconds) : "—"}</div>
                  <div className="stat-sub">Bot Uptime</div>
                </div>
              </div>
            </div>

            <div className="card">
              <div className="card-title">🖥️ CPU Usage</div>
              <div className="big-metric">{sysinfo?.cpuPercent ?? "—"}<span>%</span></div>
              <GaugeBar value={sysinfo?.cpuPercent ?? 0} color="linear-gradient(90deg,#00ffb2,#00d4ff)" />
            </div>

            <div className="card">
              <div className="card-title">🧠 Memory</div>
              <div className="big-metric">{sysinfo?.memPercent ?? "—"}<span>%</span></div>
              <GaugeBar value={sysinfo?.memPercent ?? 0} color="linear-gradient(90deg,#00d4ff,#7b61ff)" />
              <div className="metric-sub">{sysinfo ? `${sysinfo.memUsedGB} / ${sysinfo.memTotalGB} GB` : "—"}</div>
            </div>

            <div className="card">
              <div className="card-title">📁 Disk</div>
              <div className="big-metric">{sysinfo?.diskPercent ?? "—"}<span>%</span></div>
              <GaugeBar value={sysinfo?.diskPercent ?? 0} color="linear-gradient(90deg,#ff2f76,#ff8c00)" />
              <div className="metric-sub">{sysinfo ? `${sysinfo.diskUsedGB} / ${sysinfo.diskTotalGB} GB` : "—"}</div>
            </div>

            <div className="card card-wide">
              <div className="card-title">🖥️ System Details</div>
              <div className="details-grid">
                <div className="detail-item"><span>Platform</span><span>{sysinfo?.platform ?? "—"}</span></div>
                <div className="detail-item"><span>Node.js</span><span>{sysinfo?.nodeVersion ?? "—"}</span></div>
                <div className="detail-item"><span>System Uptime</span><span>{sysinfo ? fmtUptime(sysinfo.uptimeSeconds) : "—"}</span></div>
                <div className="detail-item"><span>Data Source</span><span style={{ color: "#00ffb2" }}>Live /proc/stat — no simulation</span></div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "chats" && (
          <div className="chats-layout">
            <div className="chat-list">
              <div className="section-title">💬 Dialogs</div>
              {chats.length === 0 && <div className="empty">No chats loaded</div>}
              {chats.map(c => (
                <div
                  key={c.id}
                  className={`chat-item ${selectedChat?.id === c.id ? "selected" : ""}`}
                  onClick={() => setSelectedChat(c)}
                >
                  <div className="chat-avatar">{c.title[0] ?? "?"}</div>
                  <div className="chat-info">
                    <div className="chat-name">{c.title}</div>
                    <div className="chat-last">{c.lastMessage?.substring(0, 40) ?? "—"}</div>
                  </div>
                  <div className="chat-meta">
                    <span className={`chat-type-badge chat-type-${c.type}`}>{c.type}</span>
                    {c.unreadCount > 0 && <span className="unread-badge">{c.unreadCount}</span>}
                  </div>
                </div>
              ))}
            </div>

            <div className="chat-window">
              {!selectedChat ? (
                <div className="empty-chat">Select a chat to view messages</div>
              ) : (
                <>
                  <div className="chat-header">
                    <strong>{selectedChat.title}</strong>
                    <span className="chat-id">ID: {selectedChat.id}</span>
                  </div>
                  <div className="messages">
                    {[...messages].reverse().map(m => (
                      <div key={m.id} className="message">
                        <div className="msg-text">{m.text || (m.mediaType ? `[${m.mediaType}]` : "[empty]")}</div>
                        <div className="msg-meta">{fmtDate(m.date)}</div>
                      </div>
                    ))}
                  </div>
                  <div className="send-bar">
                    <input
                      className="send-input"
                      placeholder="Type a message..."
                      value={sendText}
                      onChange={e => setSendText(e.target.value)}
                      onKeyDown={e => e.key === "Enter" && handleSend()}
                    />
                    <button className="send-btn" onClick={handleSend} disabled={sending}>
                      {sending ? "..." : "Send"}
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        )}

        {activeTab === "terminal" && (
          <div className="terminal-view">
            <div className="card card-full">
              <div className="card-title">🖥️ Live System Telemetry</div>
              <div className="term-grid">
                <div className="term-block">
                  <div className="term-label">CPU</div>
                  <div className="term-value" style={{ color: "#00ffb2" }}>{sysinfo?.cpuPercent ?? "—"}%</div>
                  <GaugeBar value={sysinfo?.cpuPercent ?? 0} color="#00ffb2" />
                </div>
                <div className="term-block">
                  <div className="term-label">RAM</div>
                  <div className="term-value" style={{ color: "#00d4ff" }}>{sysinfo?.memPercent ?? "—"}%</div>
                  <GaugeBar value={sysinfo?.memPercent ?? 0} color="#00d4ff" />
                  <div className="term-sub">{sysinfo ? `${sysinfo.memUsedGB}/${sysinfo.memTotalGB} GB` : ""}</div>
                </div>
                <div className="term-block">
                  <div className="term-label">DISK</div>
                  <div className="term-value" style={{ color: "#ff2f76" }}>{sysinfo?.diskPercent ?? "—"}%</div>
                  <GaugeBar value={sysinfo?.diskPercent ?? 0} color="#ff2f76" />
                  <div className="term-sub">{sysinfo ? `${sysinfo.diskUsedGB}/${sysinfo.diskTotalGB} GB` : ""}</div>
                </div>
                <div className="term-block">
                  <div className="term-label">UPTIME</div>
                  <div className="term-value" style={{ color: "#e5ff00", fontSize: "16px" }}>
                    {sysinfo ? fmtUptime(sysinfo.uptimeSeconds) : "—"}
                  </div>
                </div>
              </div>
              <div className="term-neo" ref={termRef}>
                {termOutput.map((line, i) => (
                  <div key={i} className="term-line">{line}</div>
                ))}
              </div>
              <div className="term-note">
                ✅ All metrics sourced from <code>/proc/stat</code>, <code>os.totalmem()</code>, and <code>df</code> — real VPS data, zero simulation.
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
