import { Router } from 'express';
import { getBotStatus, getChats, getMessages, sendMessage } from '../bot/telegram.js';
import { getRealCpuPercent, getMemoryInfo, getDiskInfo } from '../bot/sysinfo-real.js';

const router = Router();

router.get('/status', async (req, res) => {
  const status = await getBotStatus();
  res.json(status);
});

router.get('/chats', async (req, res) => {
  const limit = Math.min(parseInt(String(req.query['limit'] ?? '20'), 10), 50);
  const chats = await getChats(limit);
  res.json(chats);
});

router.get('/chats/:id/messages', async (req, res) => {
  const limit = Math.min(parseInt(String(req.query['limit'] ?? '30'), 10), 100);
  const msgs = await getMessages(req.params['id'] ?? '', limit);
  res.json(msgs);
});

router.post('/chats/:id/send', async (req, res) => {
  const { text } = req.body as { text?: string };
  if (!text) { res.status(400).json({ error: 'text required' }); return; }
  await sendMessage(req.params['id'] ?? '', text);
  res.json({ ok: true });
});

router.get('/sysinfo', async (req, res) => {
  const [cpuPercent, mem, disk] = await Promise.all([
    getRealCpuPercent(),
    Promise.resolve(getMemoryInfo()),
    Promise.resolve(getDiskInfo()),
  ]);
  res.json({
    cpuPercent,
    memUsedGB: mem.usedGB,
    memTotalGB: mem.totalGB,
    memPercent: mem.usedPercent,
    diskUsedGB: disk.usedGB,
    diskTotalGB: disk.totalGB,
    diskPercent: disk.usedPercent,
    uptimeSeconds: Math.floor(process.uptime()),
    nodeVersion: process.version,
    platform: process.platform,
  });
});

export default router;
