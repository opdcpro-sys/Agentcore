import { initializeApp, getApps, cert, App } from 'firebase-admin/app';
import { getDatabase } from 'firebase-admin/database';

let adminApp: App | null = null;

function getAdminApp(): App {
  if (adminApp) return adminApp;
  const existing = getApps().find(a => a.name === '[admin]');
  if (existing) { adminApp = existing; return existing; }

  const projectId = process.env['FIREBASE_PROJECT_ID'];
  const clientEmail = process.env['FIREBASE_CLIENT_EMAIL'];
  const privateKey = process.env['FIREBASE_PRIVATE_KEY']?.replace(/\\n/g, '\n');
  const databaseURL = process.env['FIREBASE_DATABASE_URL'];

  if (!projectId || !clientEmail || !privateKey || !databaseURL) {
    throw new Error('Missing Firebase admin credentials. Set FIREBASE_PROJECT_ID, FIREBASE_CLIENT_EMAIL, FIREBASE_PRIVATE_KEY, FIREBASE_DATABASE_URL.');
  }

  adminApp = initializeApp({
    credential: cert({ projectId, clientEmail, privateKey }),
    databaseURL,
  });
  return adminApp;
}

export async function dbGet<T>(path: string): Promise<T | null> {
  const db = getDatabase(getAdminApp());
  const snap = await db.ref(path).get();
  return snap.exists() ? (snap.val() as T) : null;
}

export async function dbSet(path: string, data: unknown): Promise<void> {
  const db = getDatabase(getAdminApp());
  await db.ref(path).set(data);
}

export async function dbPush(path: string, data: unknown): Promise<string> {
  const db = getDatabase(getAdminApp());
  const ref = await db.ref(path).push(data);
  return ref.key ?? '';
}

export async function dbUpdate(path: string, data: Record<string, unknown>): Promise<void> {
  const db = getDatabase(getAdminApp());
  await db.ref(path).update(data);
}

export async function dbRemove(path: string): Promise<void> {
  const db = getDatabase(getAdminApp());
  await db.ref(path).remove();
}

export async function dbList<T>(path: string): Promise<T[]> {
  const db = getDatabase(getAdminApp());
  const snap = await db.ref(path).get();
  if (!snap.exists()) return [];
  const val = snap.val() as Record<string, T>;
  return Object.values(val);
}

export function isFirebaseConfigured(): boolean {
  return !!(
    process.env['FIREBASE_PROJECT_ID'] &&
    process.env['FIREBASE_CLIENT_EMAIL'] &&
    process.env['FIREBASE_PRIVATE_KEY'] &&
    process.env['FIREBASE_DATABASE_URL']
  );
}
