import { createCanvas } from '@napi-rs/canvas';
import { getOsName, getCpuModel, getCpuCores, getCpuSpeedFormatted, getRealCpuPercent, getMemoryInfo, getDiskInfo } from './sysinfo-real.js';
import { execSync } from 'child_process';

export async function generateSysinfoImage(uptimeSeconds: number): Promise<Buffer> {
  const width = 960;
  const height = 580;
  const canvas = createCanvas(width, height);
  const ctx = canvas.getContext('2d');

  const bg = ctx.createLinearGradient(0, 0, width, height);
  bg.addColorStop(0, '#060814');
  bg.addColorStop(0.5, '#0d1124');
  bg.addColorStop(1, '#050711');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, width, height);

  ctx.strokeStyle = 'rgba(0,255,178,0.03)';
  ctx.lineWidth = 1;
  for (let x = 0; x < width; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, height); ctx.stroke(); }
  for (let y = 0; y < height; y += 30) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(width, y); ctx.stroke(); }

  ctx.strokeStyle = '#00ffb2'; ctx.lineWidth = 3;
  ctx.strokeRect(15, 15, width - 30, height - 30);
  ctx.strokeStyle = 'rgba(0,212,255,0.4)'; ctx.lineWidth = 1;
  ctx.strokeRect(18, 18, width - 36, height - 36);

  ctx.fillStyle = '#00ffb2';
  ctx.fillRect(12, 12, 40, 5); ctx.fillRect(12, 12, 5, 40);
  ctx.fillRect(width - 52, 12, 40, 5); ctx.fillRect(width - 17, 12, 5, 40);
  ctx.fillRect(12, height - 17, 40, 5); ctx.fillRect(12, height - 52, 5, 40);
  ctx.fillRect(width - 52, height - 17, 40, 5); ctx.fillRect(width - 17, height - 52, 5, 40);

  ctx.fillStyle = 'rgba(0,255,178,0.08)'; ctx.fillRect(20, 20, width - 40, 60);
  ctx.strokeStyle = 'rgba(0,255,178,0.2)'; ctx.strokeRect(20, 20, width - 40, 60);

  ctx.fillStyle = '#00ffb2'; ctx.beginPath(); ctx.arc(45, 50, 8, 0, Math.PI * 2); ctx.fill();
  ctx.strokeStyle = 'rgba(0,255,178,0.5)'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(45, 50, 14, 0, Math.PI * 2); ctx.stroke();

  ctx.fillStyle = '#00ffb2'; ctx.font = 'bold 11px sans-serif';
  ctx.fillText('⚡ OWNER: DEBJYOTI CHAKRABORTY (@IM_HINDU)', 70, 52);
  ctx.fillStyle = '#ffffff'; ctx.font = 'bold 20px sans-serif'; ctx.textAlign = 'center';
  ctx.fillText('TADAKEDAR ADVANCED SYSTEM MONITOR', width / 2, 58);
  ctx.textAlign = 'left';
  ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.font = '10px monospace';
  ctx.fillText(`NODE: ${process.version}`, width - 180, 45);
  ctx.fillText(`PID: ${process.pid}`, width - 180, 60);

  const hrs = Math.floor(uptimeSeconds / 3600);
  const mins = Math.floor((uptimeSeconds % 3600) / 60);
  const secs = uptimeSeconds % 60;
  const osName = getOsName();
  const cpuModel = getCpuModel();
  const cpuCores = getCpuCores();
  const cpuSpeed = getCpuSpeedFormatted();
  const cpuPercent = await getRealCpuPercent();
  const mem = getMemoryInfo();
  const disk = getDiskInfo();

  let gpuName = 'None Detected';
  try { execSync('nvidia-smi --query-gpu=name --format=csv,noheader', { encoding: 'utf8', timeout: 2000 }).trim(); gpuName = execSync('nvidia-smi --query-gpu=name --format=csv,noheader', { encoding: 'utf8', timeout: 2000 }).trim(); } catch (_) {}

  const telemetryData = [
    { title: '🖥️ PROCESSOR / CPU', value: `${cpuModel.substring(0, 52)} (${cpuCores} Cores @ ${cpuSpeed})`, percent: cpuPercent, color: '#00ffb2', details: `Load: ${cpuPercent}% | Cores: ${cpuCores} logical threads` },
    { title: '🧠 SYSTEM RAM', value: `${mem.totalGB} GB Physical RAM`, percent: mem.usedPercent, color: '#00d4ff', details: `Used: ${mem.usedGB} GB  |  Free: ${mem.freeGB} GB  |  Total: ${mem.totalGB} GB` },
    { title: '🎮 GPU / ACCELERATOR', value: gpuName !== 'None Detected' ? gpuName : 'No dedicated GPU detected', percent: 0, color: '#e5ff00', details: gpuName !== 'None Detected' ? 'NVIDIA GPU Active' : 'Shared CPU rendering' },
    { title: '📁 STORAGE (/ filesystem)', value: `${disk.totalGB} GB Total`, percent: disk.usedPercent, color: '#ff2f76', details: `Used: ${disk.usedGB} GB  |  Free: ${disk.freeGB} GB  |  Total: ${disk.totalGB} GB` },
  ];

  const leftX = 25, leftY = 95, leftW = 320, leftH = 460;
  ctx.fillStyle = 'rgba(10,15,30,0.7)'; ctx.fillRect(leftX, leftY, leftW, leftH);
  ctx.strokeStyle = 'rgba(0,212,255,0.15)'; ctx.strokeRect(leftX, leftY, leftW, leftH);
  ctx.fillStyle = 'rgba(0,212,255,0.1)'; ctx.fillRect(leftX, leftY, leftW, 30);
  ctx.fillStyle = '#00d4ff'; ctx.font = 'bold 12px sans-serif';
  ctx.fillText('🖥️ LIVE TERMINAL TELEMETRY', leftX + 15, leftY + 20);

  const termY = leftY + 40;
  ctx.fillStyle = '#02040a'; ctx.fillRect(leftX + 10, termY, leftW - 20, leftH - 50);
  ctx.strokeStyle = 'rgba(0,255,178,0.2)'; ctx.strokeRect(leftX + 10, termY, leftW - 20, leftH - 50);

  const lines: [string, string][] = [
    ['#3bc400', `user@tadakeda:~# neofetch --live`],
    ['rgba(255,255,255,0.8)', `OS:       ${osName.substring(0, 38)}`],
    ['rgba(255,255,255,0.8)', `CPU:      ${cpuModel.substring(0, 38)}`],
    ['rgba(255,255,255,0.8)', `Cores:    ${cpuCores} logical threads`],
    ['rgba(255,255,255,0.8)', `Speed:    ${cpuSpeed}`],
    ['rgba(255,255,255,0.8)', `RAM:      ${mem.usedGB} GB / ${mem.totalGB} GB (${mem.usedPercent}%)`],
    ['rgba(255,255,255,0.8)', `Disk:     ${disk.usedGB} GB / ${disk.totalGB} GB (${disk.usedPercent}%)`],
    ['rgba(255,255,255,0.8)', `GPU:      ${gpuName.substring(0, 38)}`],
    ['rgba(255,255,255,0.8)', `Uptime:   ${hrs}h ${mins}m ${secs}s`],
    ['rgba(255,255,255,0.8)', `Node.js:  ${process.version}`],
    ['rgba(255,255,255,0.8)', `PID:      ${process.pid}`],
    ['#00ffb2', `[OK]  System health: EXCELLENT`],
    ['#00ffb2', `[OK]  Telegram MTProto: CONNECTED`],
    ['#00d4ff', `>>> All metrics are REAL and LIVE`],
  ];
  ctx.font = '10px monospace';
  lines.forEach(([color, text], i) => {
    ctx.fillStyle = color;
    ctx.fillText(text, leftX + 20, termY + 20 + i * 17);
  });

  const rightX = 365, rightY = 95, rightW = 570, rightH = 460;
  ctx.fillStyle = 'rgba(10,15,30,0.6)'; ctx.fillRect(rightX, rightY, rightW, rightH);
  ctx.strokeStyle = 'rgba(0,255,178,0.1)'; ctx.strokeRect(rightX, rightY, rightW, rightH);
  ctx.fillStyle = 'rgba(0,255,178,0.08)'; ctx.fillRect(rightX, rightY, rightW, 30);
  ctx.fillStyle = '#00ffb2'; ctx.font = 'bold 12px sans-serif';
  ctx.fillText('⚙️ REAL-TIME HARDWARE TELEMETRY (LIVE)', rightX + 15, rightY + 20);

  let cardY = rightY + 45;
  for (const item of telemetryData) {
    ctx.fillStyle = 'rgba(20,30,55,0.5)'; ctx.fillRect(rightX + 15, cardY, rightW - 30, 90);
    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.strokeRect(rightX + 15, cardY, rightW - 30, 90);
    ctx.fillStyle = item.color; ctx.fillRect(rightX + 15, cardY, 4, 90);

    ctx.fillStyle = 'rgba(255,255,255,0.5)'; ctx.font = 'bold 9px monospace';
    ctx.fillText(item.title, rightX + 30, cardY + 18);

    ctx.fillStyle = '#ffffff'; ctx.font = 'bold 11px sans-serif';
    ctx.fillText(item.value.substring(0, 65), rightX + 30, cardY + 35);

    ctx.fillStyle = 'rgba(255,255,255,0.08)'; ctx.fillRect(rightX + 30, cardY + 48, rightW - 75, 11);
    if (item.percent > 0) {
      const grad = ctx.createLinearGradient(rightX + 30, 0, rightX + 30 + (rightW - 75) * (item.percent / 100), 0);
      grad.addColorStop(0, item.color); grad.addColorStop(1, '#ffffff');
      ctx.fillStyle = grad; ctx.fillRect(rightX + 30, cardY + 48, (rightW - 75) * (item.percent / 100), 11);
    }

    ctx.fillStyle = '#ffffff'; ctx.font = 'bold 10px monospace';
    ctx.fillText(`${item.percent}%`, rightX + rightW - 65, cardY + 18);

    ctx.fillStyle = 'rgba(255,255,255,0.7)'; ctx.font = '10px sans-serif';
    ctx.fillText(item.details, rightX + 30, cardY + 75);
    cardY += 100;
  }

  const footerY = rightY + 425;
  ctx.fillStyle = 'rgba(0,255,178,0.04)'; ctx.fillRect(rightX + 15, footerY, rightW - 30, 30);
  ctx.strokeStyle = 'rgba(0,255,178,0.2)'; ctx.strokeRect(rightX + 15, footerY, rightW - 30, 30);
  ctx.fillStyle = '#00ffb2'; ctx.font = '11px monospace';
  ctx.fillText('UPTIME:', rightX + 30, footerY + 20);
  ctx.fillStyle = '#ffffff';
  ctx.fillText(`${hrs} Hours, ${mins} Minutes, ${secs} Seconds  |  HEALTH: EXCELLENT 🟢`, rightX + 90, footerY + 20);

  return canvas.toBuffer('image/png');
}
