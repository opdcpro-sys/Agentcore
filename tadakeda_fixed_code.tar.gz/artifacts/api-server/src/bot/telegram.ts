import { TelegramClient } from 'telegram';
import { Api } from 'telegram';
import { NewMessage, NewMessageEvent } from 'telegram/events/index.js';
import { StringSession } from 'telegram/sessions/index.js';
import os from 'os';
import path from 'path';
import fs from 'fs';
import { exec } from 'child_process';
import { promisify } from 'util';
import { logger } from '../lib/logger.js';
import { askGroq, askGemini, analyzeImageWithGemini, GF_SYSTEM_PROMPT } from './ai.js';
import { getRealCpuPercent, getMemoryInfo, getDiskInfo, getServerLocation, getCpuModel, getCpuCores, getCpuSpeedFormatted, getOsName } from './sysinfo-real.js';
import { generateSysinfoImage } from './sysinfo-image.js';
import { dbGet, dbSet, isFirebaseConfigured } from './firebase-db.js';

const execAsync = promisify(exec);

const API_ID = parseInt(process.env['TELEGRAM_API_ID'] ?? '0', 10);
const API_HASH = process.env['TELEGRAM_API_HASH'] ?? '';
const SESSION_STRING = process.env['TELEGRAM_SESSION_STRING'] ?? '';
const SUPREME_LEADER_ID = parseInt(process.env['SUPREME_LEADER_ID'] ?? '0', 10);

export interface ChatInfo {
  id: string;
  title: string;
  type: string;
  unreadCount: number;
  lastMessage?: string;
  lastMessageDate?: number;
}

export interface MessageInfo {
  id: number;
  text: string;
  date: number;
  fromId?: string;
  fromName?: string;
  mediaType?: string;
}

export interface BotStatus {
  connected: boolean;
  me?: { id: string; username?: string; firstName?: string; phone?: string };
  uptimeSeconds: number;
  cpuPercent: number;
  memPercent: number;
  diskPercent: number;
  startTime: number;
}

let _client: TelegramClient | null = null;
let _startTime = Date.now();
let _afkMode = false;
let _afkReason = '';
let _afkFrom: string | undefined;

export function getClient(): TelegramClient | null {
  return _client;
}

export async function initBot(): Promise<void> {
  if (!API_ID || !API_HASH || !SESSION_STRING) {
    logger.warn('Telegram credentials not set — bot disabled. Set TELEGRAM_API_ID, TELEGRAM_API_HASH, TELEGRAM_SESSION_STRING.');
    return;
  }

  const session = new StringSession(SESSION_STRING);
  _client = new TelegramClient(session, API_ID, API_HASH, {
    connectionRetries: 5,
    useWSS: false,
    autoReconnect: true,
  });

  await _client.connect();
  _startTime = Date.now();
  logger.info('Telegram bot connected');

  _client.addEventHandler(handleMessage, new NewMessage({}));
}

export async function getBotStatus(): Promise<BotStatus> {
  const connected = _client?.connected ?? false;
  const uptimeSeconds = Math.floor((Date.now() - _startTime) / 1000);
  const cpuPercent = await getRealCpuPercent();
  const mem = getMemoryInfo();
  const disk = getDiskInfo();

  let me: BotStatus['me'] | undefined;
  if (connected && _client) {
    try {
      const result = await _client.invoke(new Api.users.GetUsers({ id: [new Api.InputUserSelf()] }));
      const u = result[0] as Api.User;
      if (u) {
        me = {
          id: u.id?.toString() ?? '',
          username: typeof u.username === 'string' ? u.username : undefined,
          firstName: typeof u.firstName === 'string' ? u.firstName : undefined,
          phone: typeof u.phone === 'string' ? u.phone : undefined,
        };
      }
    } catch (_) {}
  }

  return {
    connected,
    me,
    uptimeSeconds,
    cpuPercent,
    memPercent: mem.usedPercent,
    diskPercent: disk.usedPercent,
    startTime: _startTime,
  };
}

export async function getChats(limit = 20): Promise<ChatInfo[]> {
  if (!_client?.connected) return [];
  const dialogs = await _client.getDialogs({ limit });
  return dialogs.map(d => ({
    id: d.id?.toString() ?? '',
    title: d.title ?? '',
    type: d.isGroup ? 'group' : d.isChannel ? 'channel' : 'user',
    unreadCount: d.unreadCount ?? 0,
    lastMessage: d.message?.message?.substring(0, 100),
    lastMessageDate: d.message?.date,
  }));
}

export async function getMessages(chatId: string, limit = 30): Promise<MessageInfo[]> {
  if (!_client?.connected) return [];
  const msgs = await _client.getMessages(chatId, { limit });
  return msgs.map(m => ({
    id: m.id,
    text: m.message ?? '',
    date: m.date ?? 0,
    fromId: m.fromId?.toString(),
    mediaType: m.media ? m.media.className : undefined,
  }));
}

export async function sendMessage(chatId: string, text: string): Promise<void> {
  if (!_client?.connected) throw new Error('Bot not connected');
  await _client.sendMessage(chatId, { message: text });
}

async function handleMessage(event: NewMessageEvent): Promise<void> {
  const msg = event.message;
  const text = msg.message?.trim() ?? '';

  if (!text.startsWith('!')) {
    if (_afkMode && _afkFrom && msg.fromId?.toString() !== _afkFrom) {
      await msg.reply({ message: `🌙 I'm AFK${_afkReason ? ': ' + _afkReason : ''}. BRB!` });
    }
    return;
  }

  const senderId = (msg.fromId as Api.PeerUser)?.userId?.toString();
  if (String(senderId) !== String(SUPREME_LEADER_ID)) return;

  const parts = text.slice(1).split(/\s+/);
  const cmd = parts[0]?.toLowerCase() ?? '';
  const args = parts.slice(1);
  const rest = args.join(' ');

  try {
    switch (cmd) {
      case 'ping': await handlePing(msg); break;
      case 'speedtest': await handleSpeedtest(msg); break;
      case 'sysinfo': await handleSysinfo(msg); break;
      case 'help': await handleHelp(msg); break;
      case 'ai': await handleAi(msg, rest); break;
      case 'gf': case 'sara': await handleGf(msg, rest); break;
      case 'afk': await handleAfk(msg, args); break;
      case 'purge': await handlePurge(msg, args); break;
      case 'id': await handleId(msg); break;
      case 'scan': await handleScan(msg, rest); break;
      case 'eval': await handleEval(msg, rest); break;
      case 'sh': await handleSh(msg, rest); break;
      case 'reboot': await handleReboot(msg, false); break;
      case 'hardreboot': await handleReboot(msg, true); break;
      case 'promote': await handlePromoteDemote(msg, args, true); break;
      case 'demote': await handlePromoteDemote(msg, args, false); break;
      case 'agents': await handleAgents(msg); break;
      case 'backup': await handleBackup(msg); break;
      case 'setbackup': await handleSetBackup(msg, rest); break;
      case 'download': await handleDownload(msg, rest); break;
      case 'upload': await handleUpload(msg, args); break;
    }
  } catch (err) {
    logger.error({ err }, `Command error: !${cmd}`);
    await msg.reply({ message: `❌ Error: ${(err as Error).message}` });
  }
}

async function handlePing(msg: NewMessageEvent['message']): Promise<void> {
  if (!_client) return;
  const before = Date.now();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  await _client.invoke(new Api.Ping({ pingId: Math.floor(Math.random() * 1e12) as any }));
  const latency = Date.now() - before;
  await msg.reply({
    message:
      `🏓 **Pong!**\n` +
      `\`\`\`\n` +
      `MTProto Latency : ${latency} ms\n` +
      `Status          : ${latency < 100 ? '🟢 EXCELLENT' : latency < 300 ? '🟡 GOOD' : '🔴 SLOW'}\n` +
      `Protocol        : MTProto (Telegram RPC)\n` +
      `\`\`\``,
    parseMode: 'markdown',
  });
}

async function handleSpeedtest(msg: NewMessageEvent['message']): Promise<void> {
  const processing = await msg.reply({ message: '🌐 Detecting server location and running speedtest...' });
  try {
    const location = await getServerLocation();

    let downloadMbps = 0, uploadMbps = 0, pingMs = 0;
    try {
      const { stdout } = await execAsync('speedtest-cli --json --timeout 30', { timeout: 45000 });
      const d = JSON.parse(stdout);
      downloadMbps = Math.round(d.download / 1e6 * 10) / 10;
      uploadMbps = Math.round(d.upload / 1e6 * 10) / 10;
      pingMs = Math.round(d.ping * 10) / 10;
    } catch (_) {
      const res1 = await fetch('https://1.1.1.1/cdn-cgi/trace', { signal: AbortSignal.timeout(5000) }).catch(() => null);
      if (res1) {
        const t0 = Date.now();
        await fetch('https://speed.cloudflare.com/__down?bytes=10000000', { signal: AbortSignal.timeout(15000) }).catch(() => null);
        const elapsed = (Date.now() - t0) / 1000;
        downloadMbps = Math.round((10 * 8) / elapsed * 10) / 10;
      }
    }

    if (processing) await _client?.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
    await msg.reply({
      message:
        `⚡ **Network Speed Test Results**\n\n` +
        `📍 **Server Location:** ${location}\n\n` +
        `\`\`\`\n` +
        `Download  : ${downloadMbps > 0 ? downloadMbps + ' Mbps' : 'N/A'}\n` +
        `Upload    : ${uploadMbps > 0 ? uploadMbps + ' Mbps' : 'N/A'}\n` +
        `Ping      : ${pingMs > 0 ? pingMs + ' ms' : 'N/A'}\n` +
        `Provider  : VPS / Cloud\n` +
        `\`\`\`\n\n` +
        `📌 Location detected from actual server IP via ipinfo.io`,
      parseMode: 'markdown',
    });
  } catch (err) {
    await msg.reply({ message: `❌ Speedtest error: ${(err as Error).message}` });
  }
}

async function handleSysinfo(msg: NewMessageEvent['message']): Promise<void> {
  if (!_client) return;
  const processing = await msg.reply({ message: '🔍 Gathering real system metrics...' });
  try {
    const uptimeSeconds = Math.floor(os.uptime());
    const imageBuffer = await generateSysinfoImage(uptimeSeconds);
    const cpuPercent = await getRealCpuPercent();
    const mem = getMemoryInfo();
    const disk = getDiskInfo();
    const cpuModel = getCpuModel();
    const cpuCores = getCpuCores();
    const cpuSpeed = getCpuSpeedFormatted();
    const osName = getOsName();
    const location = await getServerLocation();
    const hrs = Math.floor(uptimeSeconds / 3600);
    const mins = Math.floor((uptimeSeconds % 3600) / 60);
    const secs = uptimeSeconds % 60;

    const caption =
      `🖥️ **SYSTEM INFORMATION** (Live Data)\n\n` +
      `**OS:** ${osName}\n` +
      `**CPU:** ${cpuModel} (${cpuCores} cores @ ${cpuSpeed})\n` +
      `**CPU Load:** ${cpuPercent}%\n` +
      `**RAM:** ${mem.usedGB} GB / ${mem.totalGB} GB (${mem.usedPercent}%)\n` +
      `**Disk:** ${disk.usedGB} GB / ${disk.totalGB} GB (${disk.usedPercent}%)\n` +
      `**Location:** ${location}\n` +
      `**Uptime:** ${hrs}h ${mins}m ${secs}s\n` +
      `**Node.js:** ${process.version}\n\n` +
      `⚡ _All metrics are live from the real VPS — no simulation._`;

    if (processing) await _client.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
    await _client.sendFile(msg.peerId!, {
      file: imageBuffer,
      caption,
      parseMode: 'markdown',
      attributes: [new Api.DocumentAttributeFilename({ fileName: 'sysinfo.png' })],
    });
  } catch (err) {
    await msg.reply({ message: `❌ Sysinfo error: ${(err as Error).message}` });
  }
}

async function handleHelp(msg: NewMessageEvent['message']): Promise<void> {
  await msg.reply({
    message:
      `📖 **TADAKEDAR COMMANDS**\n\n` +
      `**System:**\n` +
      `• \`!ping\` — Real MTProto latency\n` +
      `• \`!speedtest\` — Network speed + geo\n` +
      `• \`!sysinfo\` — Live VPS system info\n` +
      `• \`!reboot\` — Restart bot process\n\n` +
      `**AI:**\n` +
      `• \`!ai <query>\` — Ask Groq AI\n` +
      `• \`!gf <msg>\` / \`!sara <msg>\` — Sara (girlfriend AI)\n` +
      `• \`!scan [caption]\` — Analyze replied image\n\n` +
      `**Chat Tools:**\n` +
      `• \`!purge <n>\` — Delete last N messages\n` +
      `• \`!id\` — Show chat/user IDs\n` +
      `• \`!afk [reason]\` — Toggle AFK mode\n\n` +
      `**Admin:**\n` +
      `• \`!promote @user\` / \`!demote @user\`\n` +
      `• \`!agents\` — List admins\n` +
      `• \`!eval <code>\` — Evaluate JS\n` +
      `• \`!sh <cmd>\` — Run shell command\n\n` +
      `**Files:**\n` +
      `• \`!download <url>\` — Download file\n` +
      `• \`!upload <path>\` — Upload file\n\n` +
      `**Backup:**\n` +
      `• \`!setbackup <key>=<value>\` — Store to Firebase\n` +
      `• \`!backup\` — Show backup data`,
    parseMode: 'markdown',
  });
}

async function handleAi(msg: NewMessageEvent['message'], query: string): Promise<void> {
  if (!query) { await msg.reply({ message: '❓ Usage: `!ai <your question>`', parseMode: 'markdown' }); return; }
  const processing = await msg.reply({ message: '🤖 Thinking...' });
  const response = await askGroq(query);
  if (processing) await _client?.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
  await msg.reply({ message: `🤖 **AI Response:**\n\n${response}`, parseMode: 'markdown' });
}

async function handleGf(msg: NewMessageEvent['message'], query: string): Promise<void> {
  if (!query) { await msg.reply({ message: '💕 Say something to Sara!', parseMode: 'markdown' }); return; }
  const processing = await msg.reply({ message: '💭 Sara is typing...' });
  const response = await askGemini(query, GF_SYSTEM_PROMPT);
  if (processing) await _client?.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
  await msg.reply({ message: `💕 **Sara:** ${response}`, parseMode: 'markdown' });
}

async function handleAfk(msg: NewMessageEvent['message'], args: string[]): Promise<void> {
  if (_afkMode) {
    _afkMode = false;
    _afkReason = '';
    _afkFrom = undefined;
    await msg.reply({ message: '✅ AFK mode disabled. Welcome back!' });
  } else {
    _afkMode = true;
    _afkReason = args.join(' ');
    _afkFrom = (msg.fromId as Api.PeerUser)?.userId?.toString();
    await msg.reply({ message: `🌙 AFK mode enabled${_afkReason ? ': ' + _afkReason : ''}` });
  }
}

async function handlePurge(msg: NewMessageEvent['message'], args: string[]): Promise<void> {
  if (!_client) return;
  const n = parseInt(args[0] ?? '10', 10);
  if (isNaN(n) || n < 1 || n > 200) { await msg.reply({ message: '❓ Usage: `!purge <1-200>`', parseMode: 'markdown' }); return; }
  const msgs = await _client.getMessages(msg.peerId!, { limit: n });
  const ids = msgs.map(m => m.id);
  await _client.deleteMessages(msg.peerId!, ids, { revoke: true });
  const note = await msg.reply({ message: `🗑️ Deleted ${ids.length} messages.` });
  if (note) setTimeout(() => { _client?.deleteMessages(msg.peerId!, [note.id], { revoke: true }).catch(() => {}); }, 3000);
}

async function handleId(msg: NewMessageEvent['message']): Promise<void> {
  const chatId = msg.peerId?.toString();
  const userId = (msg.fromId as Api.PeerUser)?.userId?.toString();
  await msg.reply({
    message:
      `🔍 **ID Info:**\n\n` +
      `**Chat ID:** \`${chatId}\`\n` +
      `**Your ID:** \`${userId}\`\n` +
      `**Message ID:** \`${msg.id}\``,
    parseMode: 'markdown',
  });
}

async function handleScan(msg: NewMessageEvent['message'], prompt: string): Promise<void> {
  const replied = await msg.getReplyMessage();
  if (!replied || !replied.media) { await msg.reply({ message: '❓ Reply to an image and use `!scan [question]`', parseMode: 'markdown' }); return; }
  if (!_client) return;
  const processing = await msg.reply({ message: '🔍 Analyzing image...' });
  const buffer = await _client.downloadMedia(replied.media, {}) as Buffer | null;
  if (!buffer) { await msg.reply({ message: '❌ Could not download image.' }); return; }
  const base64 = buffer.toString('base64');
  const mimeType = (replied.media as Api.MessageMediaPhoto).photo ? 'image/jpeg' : 'image/png';
  const analysis = await analyzeImageWithGemini(base64, mimeType, prompt || 'Describe this image in detail.');
  if (processing) await _client.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
  await msg.reply({ message: `🔍 **Image Analysis:**\n\n${analysis}`, parseMode: 'markdown' });
}

async function handleEval(msg: NewMessageEvent['message'], code: string): Promise<void> {
  if (!code) { await msg.reply({ message: '❓ Usage: `!eval <js code>`', parseMode: 'markdown' }); return; }
  try {
    // eslint-disable-next-line no-eval
    const result = await eval(code);
    const out = typeof result === 'object' ? JSON.stringify(result, null, 2) : String(result);
    await msg.reply({ message: `✅ **Result:**\n\`\`\`\n${out.substring(0, 3000)}\n\`\`\``, parseMode: 'markdown' });
  } catch (err) {
    await msg.reply({ message: `❌ **Error:**\n\`\`\`\n${(err as Error).message}\n\`\`\``, parseMode: 'markdown' });
  }
}

async function handleSh(msg: NewMessageEvent['message'], cmd: string): Promise<void> {
  if (!cmd) { await msg.reply({ message: '❓ Usage: `!sh <command>`', parseMode: 'markdown' }); return; }
  const processing = await msg.reply({ message: '⚙️ Running...' });
  try {
    const { stdout, stderr } = await execAsync(cmd, { timeout: 30000 });
    const output = (stdout + stderr).substring(0, 3000);
    if (processing) await _client?.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
    await msg.reply({ message: `💻 **Shell Output:**\n\`\`\`\n${output || '(no output)'}\n\`\`\``, parseMode: 'markdown' });
  } catch (err) {
    await msg.reply({ message: `❌ **Error:**\n\`\`\`\n${(err as Error).message}\n\`\`\``, parseMode: 'markdown' });
  }
}

async function handleReboot(msg: NewMessageEvent['message'], hard: boolean): Promise<void> {
  await msg.reply({ message: hard ? '🔴 Hard rebooting...' : '🔄 Rebooting bot...' });
  setTimeout(() => process.exit(0), 1000);
}

async function handlePromoteDemote(msg: NewMessageEvent['message'], args: string[], promote: boolean): Promise<void> {
  if (!_client) return;
  const target = args[0]?.replace('@', '');
  if (!target) { await msg.reply({ message: `❓ Usage: \`!${promote ? 'promote' : 'demote'} @username\``, parseMode: 'markdown' }); return; }
  try {
    const user = await _client.getEntity(target);
    await _client.invoke(new Api.channels.EditAdmin({
      channel: msg.peerId!,
      userId: user,
      adminRights: new Api.ChatAdminRights({
        changeInfo: promote, postMessages: promote, editMessages: promote,
        deleteMessages: promote, banUsers: promote, inviteUsers: promote,
        pinMessages: promote, addAdmins: false, manageCall: promote,
        other: promote,
      }),
      rank: promote ? 'Admin' : '',
    }));
    await msg.reply({ message: `✅ @${target} ${promote ? 'promoted to admin' : 'demoted to member'}.` });
  } catch (err) {
    await msg.reply({ message: `❌ Failed: ${(err as Error).message}` });
  }
}

async function handleAgents(msg: NewMessageEvent['message']): Promise<void> {
  if (!_client) return;
  try {
    const full = await _client.invoke(new Api.channels.GetFullChannel({ channel: msg.peerId! }));
    const participants = await _client.getParticipants(msg.peerId!, { filter: new Api.ChannelParticipantsAdmins() });
    const lines = participants.map(p => {
      const u = p as Api.User;
      return `• ${u.firstName ?? ''} ${u.lastName ?? ''} (@${u.username ?? u.id})`.trim();
    });
    await msg.reply({ message: `👑 **Admins:**\n\n${lines.join('\n')}`, parseMode: 'markdown' });
  } catch (err) {
    await msg.reply({ message: `❌ ${(err as Error).message}` });
  }
}

async function handleBackup(msg: NewMessageEvent['message']): Promise<void> {
  if (!isFirebaseConfigured()) { await msg.reply({ message: '❌ Firebase not configured.' }); return; }
  const data = await dbGet<Record<string, unknown>>('backup');
  if (!data) { await msg.reply({ message: '📭 No backup data stored yet. Use `!setbackup key=value`', parseMode: 'markdown' }); return; }
  const lines = Object.entries(data).map(([k, v]) => `• **${k}:** \`${v}\``);
  await msg.reply({ message: `💾 **Backup Data:**\n\n${lines.join('\n')}`, parseMode: 'markdown' });
}

async function handleSetBackup(msg: NewMessageEvent['message'], rest: string): Promise<void> {
  if (!isFirebaseConfigured()) { await msg.reply({ message: '❌ Firebase not configured.' }); return; }
  const eq = rest.indexOf('=');
  if (eq === -1) { await msg.reply({ message: '❓ Usage: `!setbackup key=value`', parseMode: 'markdown' }); return; }
  const key = rest.slice(0, eq).trim();
  const value = rest.slice(eq + 1).trim();
  const existing = await dbGet<Record<string, unknown>>('backup') ?? {};
  existing[key] = value;
  await dbSet('backup', existing);
  await msg.reply({ message: `✅ Saved **${key}** to Firebase backup.`, parseMode: 'markdown' });
}

async function handleDownload(msg: NewMessageEvent['message'], url: string): Promise<void> {
  if (!_client || !url) { await msg.reply({ message: '❓ Usage: `!download <url>`', parseMode: 'markdown' }); return; }
  const processing = await msg.reply({ message: `📥 Downloading: \`${url.substring(0, 80)}\`...`, parseMode: 'markdown' });
  const tmpDir = '/tmp/tadakeda_dl';
  if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });
  const fileName = path.basename(new URL(url).pathname) || 'file';
  const outPath = path.join(tmpDir, fileName);
  try {
    const { stdout, stderr } = await execAsync(`wget -q -O "${outPath}" "${url}"`, { timeout: 60000 });
    const size = fs.statSync(outPath).size;
    if (processing) await _client.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
    await _client.sendFile(msg.peerId!, {
      file: outPath,
      caption: `📁 **${fileName}**\nSize: ${(size / 1024).toFixed(1)} KB`,
      parseMode: 'markdown',
    });
    fs.unlinkSync(outPath);
  } catch (err) {
    await msg.reply({ message: `❌ Download failed: ${(err as Error).message}` });
  }
}

async function handleUpload(msg: NewMessageEvent['message'], args: string[]): Promise<void> {
  const filePath = args[0];
  if (!filePath || !_client) { await msg.reply({ message: '❓ Usage: `!upload <path>`', parseMode: 'markdown' }); return; }
  if (!fs.existsSync(filePath)) { await msg.reply({ message: `❌ File not found: \`${filePath}\``, parseMode: 'markdown' }); return; }
  const processing = await msg.reply({ message: '📤 Uploading...' });
  const size = fs.statSync(filePath).size;
  await _client.sendFile(msg.peerId!, {
    file: filePath,
    caption: `📤 **${path.basename(filePath)}**\nSize: ${(size / 1024).toFixed(1)} KB`,
    parseMode: 'markdown',
  });
  if (processing) await _client.deleteMessages(msg.peerId?.toString() ?? '', [processing.id], { revoke: true }).catch(() => {});
}
