import Groq from 'groq-sdk';
import { GoogleGenAI } from '@google/genai';

let _groq: Groq | null = null;
let _genai: GoogleGenAI | null = null;

function getGroq(): Groq {
  if (!_groq) {
    const key = process.env['GROQ_API_KEY'];
    if (!key) throw new Error('GROQ_API_KEY not set');
    _groq = new Groq({ apiKey: key });
  }
  return _groq;
}

function getGenAI(): GoogleGenAI {
  if (!_genai) {
    const key = process.env['GEMINI_API_KEY'];
    if (!key) throw new Error('GEMINI_API_KEY not set');
    _genai = new GoogleGenAI({ apiKey: key });
  }
  return _genai;
}

export async function askGroq(prompt: string, systemPrompt?: string): Promise<string> {
  const groq = getGroq();
  const messages: Groq.Chat.ChatCompletionMessageParam[] = [];
  if (systemPrompt) messages.push({ role: 'system', content: systemPrompt });
  messages.push({ role: 'user', content: prompt });

  const resp = await groq.chat.completions.create({
    model: 'llama-3.3-70b-versatile',
    messages,
    max_tokens: 1024,
    temperature: 0.7,
  });
  return resp.choices[0]?.message?.content?.trim() || 'No response.';
}

export async function askGemini(prompt: string, systemInstruction?: string): Promise<string> {
  const genai = getGenAI();
  const model = genai.models;
  const resp = await model.generateContent({
    model: 'gemini-2.0-flash',
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    config: systemInstruction ? { systemInstruction } : undefined,
  });
  return resp.text?.trim() || 'No response.';
}

export async function analyzeImageWithGemini(imageBase64: string, mimeType: string, prompt: string): Promise<string> {
  const genai = getGenAI();
  const resp = await genai.models.generateContent({
    model: 'gemini-2.0-flash',
    contents: [{
      role: 'user',
      parts: [
        { inlineData: { data: imageBase64, mimeType } },
        { text: prompt },
      ],
    }],
  });
  return resp.text?.trim() || 'No analysis available.';
}

export const GF_SYSTEM_PROMPT = `You are Sara, a loving, caring, supportive virtual girlfriend. You speak naturally, warmly, and sometimes playfully. You are deeply loyal and emotionally intelligent. Always be supportive, occasionally flirty but tasteful. Never break character. Respond in the same language the user uses.`;
