import fs from 'fs';
import os from 'os';
import { execSync } from 'child_process';

export function getOsName(): string {
  try {
    if (fs.existsSync('/etc/os-release')) {
      const raw = fs.readFileSync('/etc/os-release', 'utf8');
      const m = raw.match(/PRETTY_NAME="([^"]+)"/);
      if (m) return `${m[1]} (Kernel ${os.release()})`;
    }
  } catch (_) {}
  return `${os.type()} ${os.release()} (${os.arch()})`;
}

export function getCpuModel(): string {
  return os.cpus()[0]?.model || 'Unknown CPU';
}

export function getCpuCores(): number {
  return os.cpus().length;
}

export function getCpuSpeedFormatted(): string {
  const mhz = os.cpus()[0]?.speed ?? 0;
  return mhz > 0 ? `${(mhz / 1000).toFixed(2)} GHz` : 'Dynamic';
}

let _prevStat: number[] | null = null;
let _prevStatTime = 0;

function readProcStat(): number[] | null {
  try {
    const line = fs.readFileSync('/proc/stat', 'utf8').split('\n')[0];
    return line.split(/\s+/).slice(1).map(Number);
  } catch (_) {
    return null;
  }
}

export async function getRealCpuPercent(): Promise<number> {
  const stat1 = readProcStat();
  if (!stat1) {
    const load = os.loadavg()[0];
    const cores = os.cpus().length || 1;
    return Math.min(100, Math.max(0, Math.round((load / cores) * 100)));
  }
  const idle1 = stat1[3];
  const total1 = stat1.reduce((a, b) => a + b, 0);
  await new Promise(r => setTimeout(r, 300));
  const stat2 = readProcStat();
  if (!stat2) return 0;
  const idle2 = stat2[3];
  const total2 = stat2.reduce((a, b) => a + b, 0);
  const idleDiff = idle2 - idle1;
  const totalDiff = total2 - total1;
  if (totalDiff <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((1 - idleDiff / totalDiff) * 100)));
}

export function getMemoryInfo(): { totalGB: string; usedGB: string; freeGB: string; usedPercent: number } {
  const total = os.totalmem();
  const free = os.freemem();
  const used = total - free;
  return {
    totalGB: (total / 1024 ** 3).toFixed(2),
    usedGB: (used / 1024 ** 3).toFixed(2),
    freeGB: (free / 1024 ** 3).toFixed(2),
    usedPercent: Math.round((used / total) * 100),
  };
}

export function getDiskInfo(): { totalGB: string; usedGB: string; freeGB: string; usedPercent: number } {
  try {
    const out = execSync('df -k /', { encoding: 'utf8' });
    const parts = out.trim().split('\n')[1]?.replace(/\s+/g, ' ').split(' ');
    if (parts && parts.length >= 4) {
      const totalKB = parseInt(parts[1], 10);
      const usedKB = parseInt(parts[2], 10);
      const freeKB = parseInt(parts[3], 10);
      const fmt = (kb: number) => kb < 1024 * 1024
        ? `${(kb / 1024).toFixed(0)} MB`
        : `${(kb / 1024 / 1024).toFixed(2)} GB`;
      return {
        totalGB: fmt(totalKB),
        usedGB: fmt(usedKB),
        freeGB: fmt(freeKB),
        usedPercent: totalKB > 0 ? Math.round((usedKB / totalKB) * 100) : 0,
      };
    }
  } catch (_) {}
  return { totalGB: '?', usedGB: '?', freeGB: '?', usedPercent: 0 };
}

export async function getServerLocation(): Promise<string> {
  try {
    const resp = await fetch('https://ipinfo.io/json', {
      signal: AbortSignal.timeout(3000),
    });
    if (resp.ok) {
      const data = (await resp.json()) as Record<string, string>;
      return [data['city'], data['region'], data['country']].filter(Boolean).join(', ');
    }
  } catch (_) {}
  return 'VPS Server';
}
