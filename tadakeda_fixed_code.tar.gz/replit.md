# Tadakedar Bot Dashboard

A real Telegram userbot with a live web dashboard. The bot runs via MTProto (gramjs) and exposes actual VPS system metrics — no fake data, no simulated autoscaler.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server + bot (port from $PORT)
- `pnpm --filter @workspace/tadakeda-dashboard run dev` — run the React dashboard
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-server run build` — rebuild api-server (esbuild CJS bundle)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 (`artifacts/api-server`)
- Bot: gramjs (`telegram` v2.26.22) — MTProto userbot
- Dashboard: React + Vite + Tailwind (`artifacts/tadakeda-dashboard`)
- AI: Groq (llama-3.3-70b) + Google Gemini 2.0 Flash
- Canvas: `@napi-rs/canvas` for sysinfo image generation
- DB (optional): Firebase Realtime Database for backup commands

## Where things live

- `artifacts/api-server/src/bot/telegram.ts` — main bot logic (commands, event handler)
- `artifacts/api-server/src/bot/sysinfo-real.ts` — real CPU/memory/disk reading
- `artifacts/api-server/src/bot/sysinfo-image.ts` — cyberpunk sysinfo image (canvas)
- `artifacts/api-server/src/bot/ai.ts` — Groq + Gemini AI wrappers
- `artifacts/api-server/src/bot/firebase-db.ts` — Firebase admin CRUD
- `artifacts/api-server/src/routes/bot.ts` — REST API for dashboard
- `artifacts/tadakeda-dashboard/src/App.tsx` — React dashboard

## Bot Commands

- `!ping` — Real MTProto latency via `Api.Ping` RPC
- `!speedtest` — Network speed + real geo location via ipinfo.io
- `!sysinfo` — Live VPS system info image (real /proc/stat CPU, real mem, real OS)
- `!ai <query>` — Groq AI (llama-3.3-70b)
- `!gf / !sara <msg>` — Sara girlfriend persona (Gemini)
- `!scan` — Analyze replied image with Gemini Vision
- `!purge <n>` — Delete last N messages
- `!id` — Show chat/user IDs
- `!afk [reason]` — Toggle AFK mode
- `!promote/!demote @user` — Admin management
- `!agents` — List group admins
- `!eval <code>` — Evaluate JS
- `!sh <cmd>` — Run shell command
- `!download <url>` — Download and upload file
- `!upload <path>` — Upload file to Telegram
- `!setbackup <key=value>` — Store to Firebase
- `!backup` — Show Firebase backup data
- `!reboot / !hardreboot` — Restart bot process

## Architecture decisions

- Bot runs inside the API server (same process, initialized after HTTP listen)
- `@napi-rs/canvas` and `telegram` are externalized in esbuild (native modules)
- CPU is read from `/proc/stat` twice 300ms apart for real system-wide CPU%
- Ping uses `client.invoke(new Api.Ping(...))` for real MTProto RTT
- Speedtest detects location via `https://ipinfo.io/json` (real server IP)
- All hardcoded fake specs removed: no EPYC/H100, no autoscaler, no traffic simulation
- Firebase is optional — commands degrade gracefully if not configured

## Environment Variables (set via Replit env vars)

- `TELEGRAM_API_ID` — from my.telegram.org
- `TELEGRAM_API_HASH` — from my.telegram.org
- `TELEGRAM_SESSION_STRING` — gramjs session string
- `SUPREME_LEADER_ID` — Telegram user ID allowed to run commands
- `GROQ_API_KEY` — Groq Cloud API key
- `GEMINI_API_KEY` — Google Gemini API key
- `FIREBASE_PROJECT_ID` / `FIREBASE_CLIENT_EMAIL` / `FIREBASE_PRIVATE_KEY` / `FIREBASE_DATABASE_URL` — optional, for `!backup` commands

## User preferences

- No fake/simulated data anywhere — all metrics from real OS sources
- Keep all original bot commands
- Dashboard should show real live data

## Gotchas

- `telegram` must be in `external` list in `build.mjs` — it cannot be bundled
- `@napi-rs/canvas` must be in `external` list — native bindings
- Bot init happens after HTTP listen (`initBot()` in index.ts) — non-fatal if credentials missing
- Container root overlay filesystem is small (4MB) — this is correct, not a bug

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
